package atonkish.reinfbarrel.gametest;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_4529;
import net.minecraft.class_6303;
import atonkish.reinfbarrel.gametest.testcase.AdvancementTests;
import atonkish.reinfbarrel.gametest.testcase.InventoryTests;
import atonkish.reinfbarrel.gametest.testcase.LootTableTests;
import atonkish.reinfbarrel.gametest.testcase.OpenTests;
import atonkish.reinfbarrel.gametest.testcase.PiglinTests;
import atonkish.reinfbarrel.gametest.testcase.PointOfInterestTests;
import atonkish.reinfbarrel.gametest.testcase.RecipeTests;

public class ReinforcedBarrelsModGameTest {
    @class_6303
    public Collection<class_4529> registerTests() {
        Collection<class_4529> testFunctions = new ArrayList<>();

        if (System.getProperty(this.getClass().getPackageName()) == null) {
            return testFunctions;
        }

        testFunctions.addAll(AdvancementTests.TEST_FUNCTIONS);
        testFunctions.addAll(InventoryTests.TEST_FUNCTIONS);
        testFunctions.addAll(LootTableTests.TEST_FUNCTIONS);
        testFunctions.addAll(OpenTests.TEST_FUNCTIONS);
        testFunctions.addAll(PiglinTests.TEST_FUNCTIONS);
        testFunctions.addAll(PointOfInterestTests.TEST_FUNCTIONS);
        testFunctions.addAll(RecipeTests.TEST_FUNCTIONS);

        return testFunctions;
    }
}
