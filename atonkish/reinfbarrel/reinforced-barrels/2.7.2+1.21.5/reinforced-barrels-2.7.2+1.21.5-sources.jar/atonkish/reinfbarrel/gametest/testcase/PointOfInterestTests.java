package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3852;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.gametest.util.TestIdentifier;

public class PointOfInterestTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:point_of_interest/default",
            ReinforcedBarrelsMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Copper Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper"))));

            // Iron Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Iron Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron"))));

            // Gold Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Gold Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold"))));

            // Diamond Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Diamond Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond"))));

            // Netherite Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Netherite Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("netherite"))));
        }
    };

    private static TestFunction createTest(String name, class_2248 barrelBlock) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedBarrelsMod.MOD_ID,
                PointOfInterestTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                PointOfInterestTests.TEST_ENVIRONMENT_DEFAULT,
                PointOfInterestTests.TEST_STRUCTURE_EMPTY,
                100,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;

                    context.method_35984(blockPos.method_10077(2).method_10086(1), class_2246.field_10499);
                    context.method_35984(blockPos.method_10077(1).method_10089(1).method_10086(1), class_2246.field_10499);
                    context.method_35984(blockPos.method_10077(1).method_10086(2), class_2246.field_10499);

                    class_1646 villager = context.method_35964(class_1299.field_6077, blockPos.method_10077(1));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        context.method_35984(blockPos, barrelBlock);

                        futurePartialAct1.complete(null);
                    });

                    long tickGetProfession = 100;
                    context.method_35951(tickGetProfession, () -> {
                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_56606(villager.method_7231().comp_3521().method_40230().orElse(null),
                                    class_3852.field_17057,
                                    class_2561.method_30163("villager profession"));
                        } catch (Exception e) {
                            ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                            throw e;
                        }

                        context.method_36036();
                    });
                });
    }
}
