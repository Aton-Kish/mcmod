package atonkish.reinfbarrel.world.poi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_4158;
import net.minecraft.class_6880;
import net.minecraft.class_7477;
import net.minecraft.class_7923;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.mixin.PointOfInterestTypesAccessor;

public class ModPointOfInterestTypes {
  public static void init() {
    Map<class_2680, class_6880<class_4158>> poiStatesToType =
        PointOfInterestTypesAccessor.getPointOfInterestStatesToType();

    class_4158 fishermanPoiType =
        class_7923.field_41128.method_29107(class_7477.field_39283);

    class_6880<class_4158> fishermanEntry =
        class_7923.field_41128.method_47983(fishermanPoiType);

    // NOTE: PointOfInterestType.blockStates is accessible by access widener
    List<class_2680> fishermanBlockStates = new ArrayList<class_2680>(fishermanPoiType.comp_815);

    for (class_2248 block : ModBlocks.REINFORCED_BARREL_MAP.values()) {
      ImmutableList<class_2680> blockStates = block.method_9595().method_11662();

      for (class_2680 blockState : blockStates) {
        poiStatesToType.putIfAbsent(blockState, fishermanEntry);
      }

      fishermanBlockStates.addAll(blockStates);
    }

    // NOTE: PointOfInterestType.blockStates is mutable by access widener
    fishermanPoiType.comp_815 = ImmutableSet.copyOf(fishermanBlockStates);
  }
}
