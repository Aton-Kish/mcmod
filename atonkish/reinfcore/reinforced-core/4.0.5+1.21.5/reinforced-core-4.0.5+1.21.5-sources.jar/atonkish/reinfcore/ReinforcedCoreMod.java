package atonkish.reinfcore;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.impl.gametest.FabricGameTestRunner;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_10660;
import net.minecraft.class_10665;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7655;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;

import atonkish.reinfcore.api.ReinforcedCoreModInitializer;
import atonkish.reinfcore.gametest.TestAnnotationLocator;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.item.ModItemGroups;

public class ReinforcedCoreMod implements ModInitializer {
	public static final String MOD_ID = "reinfcore";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static ReinforcedCoreConfig CONFIG;
	private static TestAnnotationLocator locator = new TestAnnotationLocator(FabricLoader.getInstance());

	@Override
	public void onInitialize() {
		// Auto Config
		AutoConfig.register(ReinforcedCoreConfig.class, GsonConfigSerializer::new);
		CONFIG = AutoConfig.getConfigHolder(ReinforcedCoreConfig.class).getConfig();

		// Items
		ModItemGroups.init();

		// entrypoint: "reinfcore"
		FabricLoader.getInstance()
				.getEntrypoints(MOD_ID, ReinforcedCoreModInitializer.class)
				.forEach(ReinforcedCoreModInitializer::onInitializeReinforcedCore);

		// entrypoint: "reinfcore-gametest"
		this.onInitializeReinforcedCoreGameTest();
	}

	private void onInitializeReinforcedCoreGameTest() {
		if (!(FabricGameTestRunner.ENABLED || FabricLoader.getInstance().isDevelopmentEnvironment())) {
			return;
		}

		for (TestFunction testFunction : locator.getTestFunctions()) {
			LOGGER.debug("Registering test function: {}", testFunction.identifier());
			class_2378.method_10230(class_7923.field_56156, testFunction.identifier(), testFunction.testFunction());
		}
	}

	public static void registerDynamicEntries(List<class_7655.class_9158<?>> registriesList) {
		Map<class_5321<? extends class_2378<?>>, class_2378<?>> registries = new IdentityHashMap<>(registriesList.size());

		for (class_7655.class_9158<?> entry : registriesList) {
			registries.put(entry.comp_2246().method_46765(), entry.comp_2246());
		}

		class_2378<class_10660> testInstances = (class_2378<class_10660>) registries.get(class_7924.field_56161);
		class_2378<class_10665> testEnvironmentDefinitionRegistry = (class_2378<class_10665>) Objects
				.requireNonNull(registries.get(class_7924.field_56160));

		for (TestFunction testFunction : locator.getTestFunctions()) {
			class_10660 testInstance = testFunction.testInstance(testEnvironmentDefinitionRegistry);
			class_2378.method_10230(testInstances, testFunction.identifier(), testInstance);
		}
	}
}
