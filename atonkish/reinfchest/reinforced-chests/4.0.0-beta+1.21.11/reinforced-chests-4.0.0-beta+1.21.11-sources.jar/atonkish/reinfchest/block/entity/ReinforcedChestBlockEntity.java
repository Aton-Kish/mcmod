package atonkish.reinfchest.block.entity;

import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_11565;
import net.minecraft.class_1258;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5561;

public class ReinforcedChestBlockEntity extends class_2595 {
  private final class_5561 stateManager;
  private final ReinforcingMaterial cachedMaterial;

  public ReinforcedChestBlockEntity(
      ReinforcingMaterial material, class_2338 blockPos, class_2680 blockState) {
    super(ModBlockEntityType.REINFORCED_CHEST_MAP.get(material), blockPos, blockState);
    this.method_11281(class_2371.method_10213(material.getSize(), class_1799.field_8037));
    this.stateManager =
        new class_5561() {
          @Override
          protected void method_31681(class_1937 world, class_2338 pos, class_2680 state) {
            ReinforcedChestBlockEntity.method_11050(world, pos, state, class_3417.field_14982);
          }

          @Override
          protected void method_31683(class_1937 world, class_2338 pos, class_2680 state) {
            ReinforcedChestBlockEntity.method_11050(world, pos, state, class_3417.field_14823);
          }

          @Override
          protected void method_31682(
              class_1937 world, class_2338 pos, class_2680 state, int oldViewerCount, int newViewerCount) {
            ReinforcedChestBlockEntity.this.method_11049(
                world, pos, state, oldViewerCount, newViewerCount);
          }

          @Override
          public boolean method_31679(class_1657 player) {
            if (player.field_7512 instanceof ReinforcedStorageScreenHandler) {
              class_1263 inventory =
                  ((ReinforcedStorageScreenHandler) player.field_7512).getInventory();
              return inventory == ReinforcedChestBlockEntity.this
                  || inventory instanceof class_1258
                      && ((class_1258) inventory).method_5405(ReinforcedChestBlockEntity.this);
            }
            return false;
          }
        };
    this.cachedMaterial = material;
  }

  @Override
  public int method_5439() {
    return this.cachedMaterial.getSize();
  }

  @Override
  protected class_2561 method_17823() {
    String namespace = class_2591.method_11033(this.method_11017()).method_12836();
    return class_2561.method_43471(
        "container." + namespace + "." + this.cachedMaterial.getName() + "Chest");
  }

  static void method_11050(class_1937 world, class_2338 pos, class_2680 state, class_3414 soundEvent) {
    class_2745 chestType = (class_2745) state.method_11654(class_2281.field_10770);
    if (chestType != class_2745.field_12574) {
      double d = (double) pos.method_10263() + 0.5D;
      double e = (double) pos.method_10264() + 0.5D;
      double f = (double) pos.method_10260() + 0.5D;
      if (chestType == class_2745.field_12571) {
        class_2350 direction = class_2281.method_9758(state);
        d += (double) direction.method_10148() * 0.5D;
        f += (double) direction.method_10165() * 0.5D;
      }

      world.method_43128(
          (class_1657) null,
          d,
          e,
          f,
          soundEvent,
          class_3419.field_15245,
          0.5F,
          world.field_9229.method_43057() * 0.1F + 0.9F);
    }
  }

  @Override
  public void method_5435(class_11565 user) {
    if (!this.field_11865 && !user.method_72382().method_7325()) {
      this.stateManager.method_31684(
          user.method_72382(),
          this.method_10997(),
          this.method_11016(),
          this.method_11010(),
          user.method_72381());
    }
  }

  @Override
  public void method_5432(class_11565 user) {
    if (!this.field_11865 && !user.method_72382().method_7325()) {
      this.stateManager.method_31685(
          user.method_72382(), this.method_10997(), this.method_11016(), this.method_11010());
    }
  }

  @Override
  protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
    return ReinforcedStorageScreenHandler.createSingleBlockScreen(
        this.cachedMaterial, syncId, playerInventory, this);
  }

  @Override
  public void method_31671() {
    if (!this.field_11865) {
      this.stateManager.method_31686(this.method_10997(), this.method_11016(), this.method_11010());
    }
  }

  public ReinforcingMaterial getMaterial() {
    return this.cachedMaterial;
  }
}
