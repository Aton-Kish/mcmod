package atonkish.reinfchest.block;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_1258;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3445;
import net.minecraft.class_3468;
import net.minecraft.class_3908;
import net.minecraft.class_4732;
import net.minecraft.class_4970;
import org.jetbrains.annotations.Nullable;
import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfchest.block.entity.ReinforcedChestBlockEntity;
import atonkish.reinfchest.stat.ModStats;

public class ReinforcedChestBlock extends class_2281 {
    private static final Map<ReinforcingMaterial, class_4732.class_3923<class_2595, Optional<class_3908>>> NAME_RETRIEVER_MAP = new LinkedHashMap<>();
    private final ReinforcingMaterial material;

    protected ReinforcedChestBlock(ReinforcingMaterial material,
            class_3414 openSound,
            class_3414 closeSound,
            Supplier<class_2591<? extends class_2595>> supplier,
            class_4970.class_2251 settings) {
        super(supplier, openSound, closeSound, settings);
        this.material = material;

        registerMaterialNameRetriever(material);
    }

    protected static class_4732.class_3923<class_2595, Optional<class_3908>> registerMaterialNameRetriever(
            ReinforcingMaterial material) {
        if (!NAME_RETRIEVER_MAP.containsKey(material)) {
            class_4732.class_3923<class_2595, Optional<class_3908>> nameRetriever = new class_4732.class_3923<class_2595, Optional<class_3908>>() {
                public Optional<class_3908> getFromBoth(class_2595 chestBlockEntity,
                        class_2595 chestBlockEntity2) {
                    final class_1263 inventory = new class_1258(chestBlockEntity, chestBlockEntity2);
                    return Optional.of(new class_3908() {
                        @Nullable
                        public class_1703 createMenu(int i, class_1661 playerInventory,
                                class_1657 playerEntity) {
                            if (chestBlockEntity.method_17489(playerEntity)
                                    && chestBlockEntity2.method_17489(playerEntity)) {
                                chestBlockEntity.method_54873(playerInventory.field_7546);
                                chestBlockEntity2.method_54873(playerInventory.field_7546);
                                return ReinforcedStorageScreenHandler.createDoubleBlockScreen(material, i,
                                        playerInventory, inventory);
                            } else {
                                return null;
                            }
                        }

                        public class_2561 method_5476() {
                            if (chestBlockEntity.method_16914()) {
                                return chestBlockEntity.method_5476();
                            } else {
                                String namespace = class_2591.method_11033(chestBlockEntity.method_11017()).method_12836();
                                return (class_2561) (chestBlockEntity2.method_16914() ? chestBlockEntity2.method_5476()
                                        : class_2561.method_43471(
                                                "container." + namespace + "." + material.getName() + "ChestDouble"));
                            }
                        }
                    });
                }

                public Optional<class_3908> getFrom(class_2595 chestBlockEntity) {
                    return Optional.of(chestBlockEntity);
                }

                public Optional<class_3908> method_24174() {
                    return Optional.empty();
                }
            };
            NAME_RETRIEVER_MAP.put(material, nameRetriever);
        }

        return NAME_RETRIEVER_MAP.get(material);
    }

    @Override
    protected class_3445<class_2960> method_9755() {
        return class_3468.field_15419.method_14956(ModStats.OPEN_REINFORCED_CHEST_MAP.get(this.material));
    }

    @Override
    @Nullable
    public class_3908 method_17454(class_2680 state, class_1937 world, class_2338 pos) {
        return ((Optional<class_3908>) this.method_24167(state, world, pos, false)
                .apply(NAME_RETRIEVER_MAP.get(this.material))).orElse((class_3908) null);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ReinforcedChestBlockEntity(this.material, pos, state);
    }

    public ReinforcingMaterial getMaterial() {
        return this.material;
    }
}
