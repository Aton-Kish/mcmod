package atonkish.reinfshulker.block.entity;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.mixin.BlockEntityTypeAccessor;
import atonkish.reinfshulker.mixin.BlockEntityTypeInvoker;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedShulkerBoxBlockEntity>> REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedShulkerBoxBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            String id = material.getName() + "_shulker_box";
            Collection<class_2248> blocks = ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).values();
            class_2591<ReinforcedShulkerBoxBlockEntity> blockEntityType = BlockEntityTypeInvoker.create(
                    class_2960.method_60655(namespace, id).toString(),
                    (blockPos, blockState) -> new ReinforcedShulkerBoxBlockEntity(material, blockPos, blockState),
                    blocks.toArray(new class_2248[0]));
            REINFORCED_SHULKER_BOX_MAP.put(material, blockEntityType);

            ((BlockEntityTypeAccessor) class_2591.field_11896).getBlocks().addAll(blocks);
        }

        return REINFORCED_SHULKER_BOX_MAP.get(material);
    }
}
