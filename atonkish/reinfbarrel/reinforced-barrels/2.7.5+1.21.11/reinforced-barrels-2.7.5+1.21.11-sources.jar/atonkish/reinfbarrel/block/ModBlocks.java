package atonkish.reinfbarrel.block;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import atonkish.reinfcore.util.ReinforcingMaterial;

public class ModBlocks {
  public static final Map<ReinforcingMaterial, class_2248> REINFORCED_BARREL_MAP = new LinkedHashMap<>();
  public static final Map<ReinforcingMaterial, class_2248.Settings> REINFORCED_BARREL_SETTINGS_MAP =
      new LinkedHashMap<>();

  public static class_2248 registerMaterial(
      String namespace, ReinforcingMaterial material, class_2248.Settings settings) {
    if (!REINFORCED_BARREL_SETTINGS_MAP.containsKey(material)) {
      REINFORCED_BARREL_SETTINGS_MAP.put(material, settings);
    }

    if (!REINFORCED_BARREL_MAP.containsKey(material)) {
      class_2248 block =
          ModBlocks.register(
              class_2960.method_60655(namespace, material.getName() + "_barrel"),
              (abstractBlockSettings) -> new ReinforcedBarrelBlock(material, abstractBlockSettings),
              REINFORCED_BARREL_SETTINGS_MAP.get(material));
      REINFORCED_BARREL_MAP.put(material, block);
    }

    return REINFORCED_BARREL_MAP.get(material);
  }

  private static class_2248 register(
      class_5321<class_2248> key,
      Function<class_4970.class_2251, class_2248> factory,
      class_4970.class_2251 settings) {
    class_2248 block = factory.apply(settings.method_63500(key));
    return class_2378.method_39197(class_7923.field_41175, key, block);
  }

  private static class_2248 register(
      class_2960 id,
      Function<class_4970.class_2251, class_2248> factory,
      class_4970.class_2251 settings) {
    return register(keyOf(id), factory, settings);
  }

  private static class_5321<class_2248> keyOf(class_2960 id) {
    return class_5321.method_29179(class_7924.field_41254, id);
  }
}
