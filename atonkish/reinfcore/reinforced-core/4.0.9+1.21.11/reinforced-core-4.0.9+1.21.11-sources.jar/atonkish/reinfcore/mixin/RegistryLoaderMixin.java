package atonkish.reinfcore.mixin;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_3300;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_7655;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.sugar.Local;

import atonkish.reinfcore.ReinforcedCoreMod;

@Mixin(class_7655.class)
public class RegistryLoaderMixin {
  @Unique private static final AtomicBoolean LOADING_DYNAMIC_REGISTRIES = new AtomicBoolean(false);

  @Inject(
      method =
          "loadFromResource(Lnet/minecraft/resource/ResourceManager;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/registry/DynamicRegistryManager$Immutable;",
      at = @At("HEAD"))
  private static void loadFromResources(
      class_3300 resourceManager,
      List<class_7225.class_7226<?>> registries,
      List<class_7655.class_7657<?>> entries,
      CallbackInfoReturnable<class_5455.class_6890> cir) {
    LOADING_DYNAMIC_REGISTRIES.set(
        entries.stream().anyMatch(entry -> entry.comp_985() == class_7924.field_56161));
  }

  @Inject(
      method =
          "load(Lnet/minecraft/registry/RegistryLoader$RegistryLoadable;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/registry/DynamicRegistryManager$Immutable;",
      at =
          @At(
              value = "INVOKE",
              target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V",
              ordinal = 1))
  private static void beforeFreeze(
      @Coerce Object loadable,
      List<class_7225.class_7226<?>> wrappers,
      List<class_7655.class_7657<?>> entries,
      CallbackInfoReturnable<class_5455.class_6890> cir,
      @Local(ordinal = 2) List<class_7655.class_9158<?>> registriesList) {
    if (LOADING_DYNAMIC_REGISTRIES.getAndSet(false)) {
      ReinforcedCoreMod.registerDynamicEntries(registriesList);
    }
  }
}
