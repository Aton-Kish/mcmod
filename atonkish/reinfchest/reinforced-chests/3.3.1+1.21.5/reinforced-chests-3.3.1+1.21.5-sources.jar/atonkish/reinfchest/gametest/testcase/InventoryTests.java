package atonkish.reinfchest.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_1263;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfchest.ReinforcedChestsMod;
import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.gametest.util.TestIdentifier;

public class InventoryTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:inventory/default",
            ReinforcedChestsMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Chest
            add(InventoryTests.createTestSingleChest(
                    "Single Copper Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    45));
            add(InventoryTests.createTestDoubleChest(
                    "Double Copper Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    90));

            // Iron Chest
            add(InventoryTests.createTestSingleChest(
                    "Single Iron Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    54));
            add(InventoryTests.createTestDoubleChest(
                    "Double Iron Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    108));

            // Gold Chest
            add(InventoryTests.createTestSingleChest(
                    "Single Gold Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    81));
            add(InventoryTests.createTestDoubleChest(
                    "Double Gold Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    162));

            // Diamond Chest
            add(InventoryTests.createTestSingleChest(
                    "Single Diamond Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    108));
            add(InventoryTests.createTestDoubleChest(
                    "Double Diamond Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    216));

            // Netherite Chest
            add(InventoryTests.createTestSingleChest(
                    "Single Netherite Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("netherite")),
                    108));
            add(InventoryTests.createTestDoubleChest(
                    "Double Netherite Chest inventory size",
                    (class_2281) ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("netherite")),
                    216));
        }
    };

    private static TestFunction createTestSingleChest(String name, class_2281 chestBlock, int size) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedChestsMod.MOD_ID,
                InventoryTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                InventoryTests.TEST_ENVIRONMENT_DEFAULT,
                InventoryTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, chestBlock);

                    // Act
                    class_1263 inventory = class_2281.method_17458(chestBlock,
                            context.method_35980(blockPos),
                            context.method_35943(),
                            context.method_36052(blockPos),
                            false);

                    // Assert
                    try {
                        context.method_56606(inventory.method_5439(), size,
                                class_2561.method_30163(String.format("%s single inventory size", chestBlock)));
                    } catch (Exception e) {
                        ReinforcedChestsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }

    private static TestFunction createTestDoubleChest(String name, class_2281 chestBlock, int size) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedChestsMod.MOD_ID,
                InventoryTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                InventoryTests.TEST_ENVIRONMENT_DEFAULT,
                InventoryTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35986(blockPos,
                            chestBlock.method_9564().method_11657(class_2281.field_10770, class_2745.field_12574));
                    context.method_35986(blockPos.method_10089(1),
                            chestBlock.method_9564().method_11657(class_2281.field_10770, class_2745.field_12571));

                    // Act
                    class_1263 inventory = class_2281.method_17458(chestBlock,
                            context.method_35980(blockPos),
                            context.method_35943(),
                            context.method_36052(blockPos),
                            false);

                    // Assert
                    try {
                        context.method_56606(inventory.method_5439(), size,
                                class_2561.method_30163(String.format("%s double inventory size", chestBlock)));
                    } catch (Exception e) {
                        ReinforcedChestsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
