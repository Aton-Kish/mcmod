package atonkish.reinfcore.client.gui.screen.ingame;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import atonkish.reinfcore.ReinforcedCoreMod;
import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcedStorageScreenModel;
import atonkish.reinfcore.util.ReinforcedStorageScreenModels;
import atonkish.reinfcore.util.math.Point2i;

@Environment(EnvType.CLIENT)
public class ReinforcedStorageScreen extends class_465<ReinforcedStorageScreenHandler> {
    private static final int SLOT_SIZE = 18;
    private static final int TEXT_LINE_HEIGHT = 11;
    private static final int PADDING_TOP = 17;
    private static final int PADDING_BOTTOM = 7;
    private static final int PADDING_LEFT = 7;
    private static final int PADDING_RIGHT = 7;
    private static final int GAP_BETWEEN_CONTAINER_INVENTORY_AND_PLAYER_INVENTORY = 14;
    private static final int GAP_BETWEEN_PLAYER_INVENTORY_STORAGE_AND_PLAYER_INVENTORY_HOTBAR = 4;
    private static final int GAP_BETWEEN_CONTAINER_INVENTORY_AND_SCROLL_BAR = 4;

    private static final int SINGLE_SCREEN_DEFAULT_COLS = 9;
    private static final int SCROLL_SCREEN_COLS = 9;

    private static final class_2960 BACKGROUND_TEXTURE = class_2960.method_60656("textures/gui/demo_background.png");
    private static final int BACKGROUND_CORNER = 4;
    private static final int BACKGROUND_X = 0;
    private static final int BACKGROUND_Y = 0;
    private static final int BACKGROUND_WIDTH = 248;
    private static final int BACKGROUND_HEIGHT = 166;

    private static final class_2960 CONTAINER_TEXTURE = class_2960.method_60656("textures/gui/container/generic_54.png");
    private static final int CONTAINER_INVENTORY_X = 7;
    private static final int CONTAINER_INVENTORY_Y = 17;
    private static final int CONTAINER_INVENTORY_COLS = 9;
    private static final int CONTAINER_INVENTORY_ROWS = 6;
    private static final int PLAYER_INVENTORY_X = 7;
    private static final int PLAYER_INVENTORY_Y = 139;
    private static final int PLAYER_INVENTORY_WIDTH = 162;
    private static final int PLAYER_INVENTORY_HEIGHT = 76;

    private static final class_2960 SCROLLBAR_BACKGROUND_TEXTURE = class_2960.method_60656(
            "textures/gui/container/creative_inventory/tab_items.png");
    private static final int SCROLLBAR_BACKGROUND_X = 174;
    private static final int SCROLLBAR_BACKGROUND_Y = 17;
    private static final int SCROLLBAR_BACKGROUND_WIDTH = 14;
    private static final int SCROLLBAR_BACKGROUND_HEIGHT = 112;

    private static final class_2960 SCROLLER_TEXTURE = class_2960.method_60656("container/creative_inventory/scroller");
    private static final class_2960 SCROLLER_DISABLED_TEXTURE = class_2960.method_60656(
            "container/creative_inventory/scroller_disabled");
    private static final int SCROLLER_WIDTH = 12;
    private static final int SCROLLER_HEIGHT = 15;

    private final ReinforcedStorageScreenModel screenModel;
    private final int cols;
    private final int rows;

    private float scrollPosition;
    private boolean scrolling;

    public ReinforcedStorageScreen(ReinforcedStorageScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);

        this.scrollPosition = 0.0f;
        this.scrolling = false;

        this.screenModel = handler.getIsDoubleBlock()
                ? ReinforcedStorageScreenModels.DOUBLE_MAP.get(handler.getMaterial())
                : ReinforcedStorageScreenModels.SINGLE_MAP.get(handler.getMaterial());

        this.cols = handler.getColumns();
        this.rows = handler.getRows();

        this.field_2792 = PADDING_LEFT + this.cols * SLOT_SIZE + PADDING_RIGHT;
        if (this.hasScrollbar()) {
            this.field_2792 += GAP_BETWEEN_CONTAINER_INVENTORY_AND_SCROLL_BAR
                    + SCROLLBAR_BACKGROUND_WIDTH;
        }
        this.field_2779 = PADDING_TOP + this.rows * SLOT_SIZE
                + GAP_BETWEEN_CONTAINER_INVENTORY_AND_PLAYER_INVENTORY + 3 * SLOT_SIZE
                + GAP_BETWEEN_PLAYER_INVENTORY_STORAGE_AND_PLAYER_INVENTORY_HOTBAR + 1 * SLOT_SIZE
                + PADDING_BOTTOM;
        this.field_25267 = PADDING_LEFT + 1;
        this.field_25268 = PADDING_TOP - TEXT_LINE_HEIGHT;
        this.field_25269 = PADDING_LEFT + (this.cols - SINGLE_SCREEN_DEFAULT_COLS) * SLOT_SIZE / 2
                + 1;
        this.field_25270 = this.field_2779 - (TEXT_LINE_HEIGHT + 3 * SLOT_SIZE
                + GAP_BETWEEN_PLAYER_INVENTORY_STORAGE_AND_PLAYER_INVENTORY_HOTBAR + 1 * SLOT_SIZE
                + PADDING_BOTTOM);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        this.drawBackgroundTexture(context);
        this.drawSlotTexture(context);
        if (this.hasScrollbar()) {
            this.drawScrollbarTexture(context);
        }
    }

    private void drawBackgroundTexture(class_332 context) {
        int hnum = (this.field_2792 - BACKGROUND_CORNER * 2)
                / (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2);
        int hrem = (this.field_2792 - BACKGROUND_CORNER * 2)
                % (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2);

        int vnum = (this.field_2779 - BACKGROUND_CORNER * 2)
                / (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2);
        int vrem = (this.field_2779 - BACKGROUND_CORNER * 2)
                % (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2);

        //
        // corner
        //

        // left-top
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776,
                this.field_2800,
                BACKGROUND_X,
                BACKGROUND_Y,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                256,
                256);

        // right-top
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + this.field_2792 - BACKGROUND_CORNER,
                this.field_2800,
                BACKGROUND_WIDTH - BACKGROUND_CORNER,
                BACKGROUND_Y,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                256,
                256);

        // right-top
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776,
                this.field_2800 + this.field_2779 - BACKGROUND_CORNER,
                BACKGROUND_X,
                BACKGROUND_HEIGHT - BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                256,
                256);

        // right-bottom
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + this.field_2792 - BACKGROUND_CORNER,
                this.field_2800 + this.field_2779 - BACKGROUND_CORNER,
                BACKGROUND_WIDTH - BACKGROUND_CORNER,
                BACKGROUND_HEIGHT - BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                256,
                256);

        //
        // edge
        //

        for (int hcnt = 0; hcnt < hnum; ++hcnt) {
            // top
            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776 + BACKGROUND_CORNER + hcnt * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                    this.field_2800,
                    BACKGROUND_CORNER,
                    BACKGROUND_Y,
                    BACKGROUND_WIDTH - BACKGROUND_CORNER * 2,
                    BACKGROUND_CORNER,
                    256,
                    256);

            // bottom
            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776 + BACKGROUND_CORNER + hcnt * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                    this.field_2800 + this.field_2779 - BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    BACKGROUND_HEIGHT - BACKGROUND_CORNER,
                    BACKGROUND_WIDTH - BACKGROUND_CORNER * 2,
                    BACKGROUND_CORNER,
                    256,
                    256);
        }

        for (int vcnt = 0; vcnt < vnum; ++vcnt) {
            // left
            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776,
                    this.field_2800 + BACKGROUND_CORNER + vcnt * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                    BACKGROUND_X,
                    BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2,
                    256,
                    256);

            // right
            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776 + this.field_2792 - BACKGROUND_CORNER,
                    this.field_2800 + BACKGROUND_CORNER + vcnt * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                    BACKGROUND_WIDTH - BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2,
                    256,
                    256);
        }

        // top
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + BACKGROUND_CORNER + hnum * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                this.field_2800,
                BACKGROUND_CORNER,
                BACKGROUND_Y,
                hrem,
                BACKGROUND_CORNER,
                256,
                256);

        // bottom
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + BACKGROUND_CORNER + hnum * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                this.field_2800 + this.field_2779 - BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                BACKGROUND_HEIGHT - BACKGROUND_CORNER,
                hrem,
                BACKGROUND_CORNER,
                256,
                256);

        // left
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776,
                this.field_2800 + BACKGROUND_CORNER + vnum * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                BACKGROUND_X,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                vrem,
                256,
                256);

        // right
        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + this.field_2792 - BACKGROUND_CORNER,
                this.field_2800 + BACKGROUND_CORNER + vnum * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                BACKGROUND_WIDTH - BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                vrem,
                256,
                256);

        //
        // area
        //

        for (int vcnt = 0; vcnt < vnum; ++vcnt) {
            for (int hcnt = 0; hcnt < hnum; ++hcnt) {
                context.method_25290(class_10799.field_56883,
                        field_2801,
                        this.field_2776 + BACKGROUND_CORNER
                                + hcnt * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                        this.field_2800 + BACKGROUND_CORNER
                                + vcnt * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                        BACKGROUND_CORNER,
                        BACKGROUND_CORNER,
                        BACKGROUND_WIDTH - BACKGROUND_CORNER * 2,
                        BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2,
                        256,
                        256);
            }

            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776 + BACKGROUND_CORNER + hnum * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                    this.field_2800 + BACKGROUND_CORNER + vcnt * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                    BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    hrem,
                    BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2,
                    256,
                    256);
        }

        for (int hcnt = 0; hcnt < hnum; ++hcnt) {
            context.method_25290(class_10799.field_56883,
                    field_2801,
                    this.field_2776 + BACKGROUND_CORNER + hcnt * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                    this.field_2800 + BACKGROUND_CORNER + vnum * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                    BACKGROUND_CORNER,
                    BACKGROUND_CORNER,
                    BACKGROUND_WIDTH - BACKGROUND_CORNER * 2,
                    vrem,
                    256,
                    256);
        }

        context.method_25290(class_10799.field_56883,
                field_2801,
                this.field_2776 + BACKGROUND_CORNER + hnum * (BACKGROUND_WIDTH - BACKGROUND_CORNER * 2),
                this.field_2800 + BACKGROUND_CORNER + vnum * (BACKGROUND_HEIGHT - BACKGROUND_CORNER * 2),
                BACKGROUND_CORNER,
                BACKGROUND_CORNER,
                hrem,
                vrem,
                256,
                256);
    }

    private void drawSlotTexture(class_332 context) {
        //
        // container inventory
        //

        Point2i containerInventoryPoint = this.screenModel.getContainerInventoryPoint();

        int hnum = this.cols / CONTAINER_INVENTORY_COLS;
        int hrem = (this.cols % CONTAINER_INVENTORY_COLS) * SLOT_SIZE;

        int vnum = this.rows / CONTAINER_INVENTORY_ROWS;
        int vrem = (this.rows % CONTAINER_INVENTORY_ROWS) * SLOT_SIZE;

        for (int vcnt = 0; vcnt < vnum; ++vcnt) {
            for (int hcnt = 0; hcnt < hnum; ++hcnt) {
                context.method_25290(class_10799.field_56883,
                        CONTAINER_TEXTURE,
                        this.field_2776 + containerInventoryPoint.getX()
                                + hcnt * CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                        this.field_2800 + containerInventoryPoint.getY()
                                + vcnt * CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                        CONTAINER_INVENTORY_X,
                        CONTAINER_INVENTORY_Y,
                        CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                        CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                        256,
                        256);
            }

            context.method_25290(class_10799.field_56883,
                    CONTAINER_TEXTURE,
                    this.field_2776 + containerInventoryPoint.getX()
                            + hnum * CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                    this.field_2800 + containerInventoryPoint.getY()
                            + vcnt * CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                    CONTAINER_INVENTORY_X,
                    CONTAINER_INVENTORY_Y,
                    hrem,
                    CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                    256,
                    256);
        }

        for (int hcnt = 0; hcnt < hnum; ++hcnt) {
            context.method_25290(class_10799.field_56883,
                    CONTAINER_TEXTURE,
                    this.field_2776 + containerInventoryPoint.getX()
                            + hcnt * CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                    this.field_2800 + containerInventoryPoint.getY()
                            + vnum * CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                    CONTAINER_INVENTORY_X,
                    CONTAINER_INVENTORY_Y,
                    CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                    vrem,
                    256,
                    256);
        }

        context.method_25290(class_10799.field_56883,
                CONTAINER_TEXTURE,
                this.field_2776 + containerInventoryPoint.getX() + hnum * CONTAINER_INVENTORY_COLS * SLOT_SIZE,
                this.field_2800 + containerInventoryPoint.getY() + vnum * CONTAINER_INVENTORY_ROWS * SLOT_SIZE,
                CONTAINER_INVENTORY_X,
                CONTAINER_INVENTORY_Y,
                hrem,
                vrem,
                256,
                256);

        //
        // player inventory
        //

        Point2i playerInventoryPoint = this.screenModel.getPlayerInventoryPoint();

        context.method_25290(class_10799.field_56883,
                CONTAINER_TEXTURE,
                this.field_2776 + playerInventoryPoint.getX(),
                this.field_2800 + playerInventoryPoint.getY(),
                PLAYER_INVENTORY_X,
                PLAYER_INVENTORY_Y,
                PLAYER_INVENTORY_WIDTH,
                PLAYER_INVENTORY_HEIGHT,
                256,
                256);
    }

    private void drawScrollbarTexture(class_332 context) {
        //
        // backgraound
        //

        int vnum = (this.rows * SLOT_SIZE - 2) / (SCROLLBAR_BACKGROUND_HEIGHT - 2);
        int vrem = (this.rows * SLOT_SIZE - 2) % (SCROLLBAR_BACKGROUND_HEIGHT - 2);

        context.method_25290(class_10799.field_56883,
                SCROLLBAR_BACKGROUND_TEXTURE,
                this.field_2776 + this.field_2792 - (SCROLLBAR_BACKGROUND_WIDTH + PADDING_RIGHT),
                this.field_2800 + PADDING_TOP,
                SCROLLBAR_BACKGROUND_X,
                SCROLLBAR_BACKGROUND_Y,
                SCROLLBAR_BACKGROUND_WIDTH,
                1,
                256,
                256);

        for (int vcnt = 0; vcnt < vnum; ++vcnt) {
            context.method_25290(class_10799.field_56883,
                    SCROLLBAR_BACKGROUND_TEXTURE,
                    this.field_2776 + this.field_2792 - (SCROLLBAR_BACKGROUND_WIDTH + PADDING_RIGHT),
                    this.field_2800 + PADDING_TOP + 1 + vcnt * (SCROLLBAR_BACKGROUND_HEIGHT - 2),
                    SCROLLBAR_BACKGROUND_X,
                    SCROLLBAR_BACKGROUND_Y + 1,
                    SCROLLBAR_BACKGROUND_WIDTH,
                    SCROLLBAR_BACKGROUND_HEIGHT - 2,
                    256,
                    256);
        }

        context.method_25290(class_10799.field_56883,
                SCROLLBAR_BACKGROUND_TEXTURE,
                this.field_2776 + this.field_2792 - (SCROLLBAR_BACKGROUND_WIDTH + PADDING_RIGHT),
                this.field_2800 + PADDING_TOP + 1 + vnum * (SCROLLBAR_BACKGROUND_HEIGHT - 2),
                SCROLLBAR_BACKGROUND_X,
                SCROLLBAR_BACKGROUND_Y + 1,
                SCROLLBAR_BACKGROUND_WIDTH,
                vrem,
                256,
                256);

        context.method_25290(class_10799.field_56883,
                SCROLLBAR_BACKGROUND_TEXTURE,
                this.field_2776 + this.field_2792 - (SCROLLBAR_BACKGROUND_WIDTH + PADDING_RIGHT),
                this.field_2800 + PADDING_TOP + this.rows * SLOT_SIZE - 1,
                SCROLLBAR_BACKGROUND_X,
                SCROLLBAR_BACKGROUND_Y + SCROLLBAR_BACKGROUND_HEIGHT - 1,
                SCROLLBAR_BACKGROUND_WIDTH,
                1,
                256,
                256);

        //
        // button
        //

        int ymin = this.field_2800 + PADDING_TOP + 1;
        int ymax = ymin + this.rows * SLOT_SIZE;

        class_2960 identifier = this.hasScrollbar() ? SCROLLER_TEXTURE : SCROLLER_DISABLED_TEXTURE;
        context.method_52706(class_10799.field_56883,
                identifier,
                this.field_2776 + PADDING_LEFT + this.cols * SLOT_SIZE
                        + GAP_BETWEEN_CONTAINER_INVENTORY_AND_SCROLL_BAR + 1,
                ymin + (int) ((float) (ymax - ymin - (SCROLLER_HEIGHT + 2)) * this.scrollPosition),
                SCROLLER_WIDTH,
                SCROLLER_HEIGHT);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.hasScrollbar() && button == 0) {
            if (this.isClickInScrollbar(mouseX, mouseY)) {
                this.scrolling = this.hasScrollbar();
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (this.hasScrollbar() && button == 0) {
            this.scrolling = false;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    private boolean hasScrollbar() {
        return this.field_2797.shouldShowScrollbar();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!this.hasScrollbar()) {
            return false;
        }

        int i = class_3532.method_38788(this.field_2797.getInventory().method_5439(), SCROLL_SCREEN_COLS)
                - ReinforcedCoreMod.CONFIG.scrollScreen.rows;
        float f = (float) (verticalAmount / (double) i);
        this.scrollPosition = class_3532.method_15363(this.scrollPosition - f, 0.0f, 1.0f);
        this.field_2797.scrollItems(this.scrollPosition);
        return true;
    }

    protected boolean isClickInScrollbar(double mouseX, double mouseY) {
        int i = this.field_2776 + PADDING_LEFT + this.cols * SLOT_SIZE + GAP_BETWEEN_CONTAINER_INVENTORY_AND_SCROLL_BAR
                + 1;
        int j = this.field_2800 + PADDING_TOP + 1;
        int k = i + SCROLLER_WIDTH + 1;
        int l = j + this.rows * SLOT_SIZE;
        return mouseX >= (double) i && mouseY >= (double) j && mouseX < (double) k && mouseY < (double) l;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.hasScrollbar() && this.scrolling) {
            int i = this.field_2800 + PADDING_TOP + 1;
            int j = i + this.rows * SLOT_SIZE;
            this.scrollPosition = ((float) mouseY - (float) i - (float) SCROLLER_HEIGHT / 2.0f)
                    / ((float) (j - i) - (float) SCROLLER_HEIGHT);
            this.scrollPosition = class_3532.method_15363(this.scrollPosition, 0.0f, 1.0f);
            this.field_2797.scrollItems(this.scrollPosition);
            return true;
        }

        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }
}
