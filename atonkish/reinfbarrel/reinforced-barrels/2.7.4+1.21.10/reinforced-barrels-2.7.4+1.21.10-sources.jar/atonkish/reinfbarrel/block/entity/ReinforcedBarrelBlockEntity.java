package atonkish.reinfbarrel.block.entity;

import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_11565;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2382;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3708;
import net.minecraft.class_3719;
import net.minecraft.class_5561;
import atonkish.reinfbarrel.mixin.BlockEntityAccessor;

public class ReinforcedBarrelBlockEntity extends class_3719 {
    private final class_5561 stateManager;
    private final ReinforcingMaterial cachedMaterial;

    public ReinforcedBarrelBlockEntity(ReinforcingMaterial material, class_2338 pos, class_2680 state) {
        super(pos, state);
        ((BlockEntityAccessor) this).setType(ModBlockEntityType.REINFORCED_BARREL_MAP.get(material));
        this.method_11281(class_2371.method_10213(material.getSize(), class_1799.field_8037));
        this.stateManager = new class_5561() {
            @Override
            protected void method_31681(class_1937 world, class_2338 pos, class_2680 state) {
                ReinforcedBarrelBlockEntity.this.method_17764(state, class_3417.field_17604);
                ReinforcedBarrelBlockEntity.this.method_18318(state, true);
            }

            @Override
            protected void method_31683(class_1937 world, class_2338 pos, class_2680 state) {
                ReinforcedBarrelBlockEntity.this.method_17764(state, class_3417.field_17603);
                ReinforcedBarrelBlockEntity.this.method_18318(state, false);
            }

            @Override
            protected void method_31682(class_1937 world, class_2338 pos, class_2680 state, int oldViewerCount,
                    int newViewerCount) {
            }

            @Override
            public boolean method_31679(class_1657 player) {
                if (player.field_7512 instanceof ReinforcedStorageScreenHandler) {
                    class_1263 inventory = ((ReinforcedStorageScreenHandler) player.field_7512).getInventory();
                    return inventory == ReinforcedBarrelBlockEntity.this;
                } else {
                    return false;
                }
            }
        };
        this.cachedMaterial = material;
    }

    @Override
    public int method_5439() {
        return this.cachedMaterial.getSize();
    }

    @Override
    protected class_2561 method_17823() {
        String namespace = class_2591.method_11033(this.method_11017()).method_12836();
        return class_2561.method_43471("container." + namespace + "." + this.cachedMaterial.getName() + "Barrel");
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return ReinforcedStorageScreenHandler.createSingleBlockScreen(this.cachedMaterial, syncId, playerInventory,
                this);
    }

    @Override
    public void method_5435(class_11565 user) {
        if (!this.field_11865 && !user.method_72382().method_7325()) {
            this.stateManager.method_31684(user.method_72382(), this.method_10997(), this.method_11016(),
                    this.method_11010(), user.method_72381());
        }

    }

    @Override
    public void method_5432(class_11565 user) {
        if (!this.field_11865 && !user.method_72382().method_7325()) {
            this.stateManager.method_31685(user.method_72382(), this.method_10997(), this.method_11016(),
                    this.method_11010());
        }

    }

    @Override
    public void method_20362() {
        if (!this.field_11865) {
            this.stateManager.method_31686(this.method_10997(), this.method_11016(), this.method_11010());
        }

    }

    private void method_18318(class_2680 state, boolean open) {
        this.field_11863.method_8652(this.method_11016(), state.method_11657(class_3708.field_18006, open), class_2248.field_31036);
    }

    private void method_17764(class_2680 state, class_3414 soundEvent) {
        class_2382 vec3i = ((class_2350) state.method_11654(class_3708.field_16320)).method_62675();
        double d = (double) this.field_11867.method_10263() + 0.5D + (double) vec3i.method_10263() / 2.0D;
        double e = (double) this.field_11867.method_10264() + 0.5D + (double) vec3i.method_10264() / 2.0D;
        double f = (double) this.field_11867.method_10260() + 0.5D + (double) vec3i.method_10260() / 2.0D;
        this.field_11863.method_43128((class_1657) null, d, e, f, soundEvent, class_3419.field_15245, 0.5F,
                this.field_11863.field_9229.method_43057() * 0.1F + 0.9F);
    }

    public ReinforcingMaterial getMaterial() {
        return this.cachedMaterial;
    }
}
