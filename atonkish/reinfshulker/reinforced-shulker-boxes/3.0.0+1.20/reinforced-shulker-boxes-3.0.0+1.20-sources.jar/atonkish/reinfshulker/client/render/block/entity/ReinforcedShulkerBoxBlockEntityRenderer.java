package atonkish.reinfshulker.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2480;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_602;
import net.minecraft.class_630;
import net.minecraft.class_827;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxBlockEntityRenderer implements class_827<ReinforcedShulkerBoxBlockEntity> {
    private final class_602<?> model;

    public ReinforcedShulkerBoxBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.model = new class_602<>(ctx.method_32140(class_5602.field_27596));
    }

    @Override
    public void render(ReinforcedShulkerBoxBlockEntity reinforcedShulkerBoxBlockEntity, float tickDelta,
            class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        class_2350 direction = class_2350.field_11036;
        if (reinforcedShulkerBoxBlockEntity.method_11002()) {
            class_2680 blockState = reinforcedShulkerBoxBlockEntity.method_10997()
                    .method_8320(reinforcedShulkerBoxBlockEntity.method_11016());
            if (blockState.method_26204() instanceof class_2480) {
                direction = (class_2350) blockState.method_11654(class_2480.field_11496);
            }
        }

        class_1767 color = reinforcedShulkerBoxBlockEntity.method_11320();
        ReinforcingMaterial material = reinforcedShulkerBoxBlockEntity.getMaterial();
        class_4730 spriteIdentifier2;
        if (color == null) {
            spriteIdentifier2 = ModTexturedRenderLayers.REINFORCED_SHULKER_TEXTURE_ID_MAP.get(material);
        } else {
            spriteIdentifier2 = ModTexturedRenderLayers.COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.get(material)
                    .get(color.method_7789());
        }

        matrices.method_22903();
        matrices.method_22904(0.5D, 0.5D, 0.5D);
        float g = 0.9995F;
        matrices.method_22905(g, g, g);
        matrices.method_22907(direction.method_23224());
        matrices.method_22905(1.0F, -1.0F, -1.0F);
        matrices.method_22904(0.0D, -1.0D, 0.0D);
        class_630 modelPart = this.model.method_2829();
        modelPart.method_2851(0.0F, 24.0F - reinforcedShulkerBoxBlockEntity.method_11312(tickDelta) * 0.5F * 16.0F,
                0.0F);
        modelPart.field_3675 = 270.0F * reinforcedShulkerBoxBlockEntity.method_11312(tickDelta) * 0.017453292F;
        class_4588 vertexConsumer = spriteIdentifier2.method_24145(vertexConsumers,
                class_1921::method_23578);
        this.model.method_2828(matrices, vertexConsumer, light, overlay, 1.0F, 1.0F, 1.0F, 1.0F);
        matrices.method_22909();
    }
}
