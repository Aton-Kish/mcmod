package atonkish.reinfshulker.gametest.util;

import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;

public class VoidScreenHander extends class_1703 {
    public VoidScreenHander() {
        super(null, 0);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        throw new UnsupportedOperationException("not implemented");
    };

    @Override
    public boolean method_7597(class_1657 player) {
        throw new UnsupportedOperationException("not implemented");
    };
}
