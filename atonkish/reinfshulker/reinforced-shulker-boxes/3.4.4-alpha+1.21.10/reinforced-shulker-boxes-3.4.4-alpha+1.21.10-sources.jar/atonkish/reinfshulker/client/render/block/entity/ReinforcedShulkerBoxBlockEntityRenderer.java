package atonkish.reinfshulker.client.render.block.entity;

import java.util.Set;

import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11701;
import net.minecraft.class_11954;
import net.minecraft.class_11970;
import net.minecraft.class_12075;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4730;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_827;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxBlockEntityRenderer
        implements class_827<ReinforcedShulkerBoxBlockEntity, class_11970> {
    private final class_11701 spriteHolder;
    private final ShulkerBoxBlockModel model;

    public ReinforcedShulkerBoxBlockEntityRenderer(class_5614.class_5615 context) {
        this.spriteHolder = context.comp_4541();
        this.model = new ShulkerBoxBlockModel(context.method_32140(class_5602.field_52997));
    }

    public class_11970 method_74335() {
        return new class_11970();
    }

    @Override
    public void updateRenderState(ReinforcedShulkerBoxBlockEntity shulkerBoxBlockEntity,
            class_11970 shulkerBoxBlockEntityRenderState, float tickProgress, class_243 vec3d,
            @Nullable class_11683.class_11792 crumblingOverlayCommand) {
        class_11954.method_74399(shulkerBoxBlockEntity, shulkerBoxBlockEntityRenderState,
                crumblingOverlayCommand);
        shulkerBoxBlockEntityRenderState.field_62736 = (class_2350) shulkerBoxBlockEntity.method_11010()
                .method_61767(class_2480.field_11496, class_2350.field_11036);
        shulkerBoxBlockEntityRenderState.field_62737 = shulkerBoxBlockEntity.method_11320();
        shulkerBoxBlockEntityRenderState.field_62738 = shulkerBoxBlockEntity.method_11312(tickProgress);
    }

    @Override
    public void render(class_11970 shulkerBoxBlockEntityRenderState, class_4587 matrixStack,
            class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState) {
        class_1767 color = shulkerBoxBlockEntityRenderState.field_62737;
        ReinforcingMaterial material = ((ReinforcedShulkerBoxBlock) shulkerBoxBlockEntityRenderState.field_62674
                .method_26204()).getMaterial();
        class_4730 spriteIdentifier = color == null
                ? ModTexturedRenderLayers.REINFORCED_SHULKER_TEXTURE_ID_MAP.get(material)
                : ModTexturedRenderLayers.COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.get(material)
                        .get(color.method_7789());

        this.render(matrixStack, orderedRenderCommandQueue, shulkerBoxBlockEntityRenderState.field_62676,
                class_4608.field_21444, shulkerBoxBlockEntityRenderState.field_62736,
                shulkerBoxBlockEntityRenderState.field_62738, shulkerBoxBlockEntityRenderState.field_62677,
                spriteIdentifier, 0);
    }

    public void render(class_4587 matrixStack, class_11659 orderedRenderCommandQueue, int light,
            int overlay, class_2350 facing,
            float openness, @Nullable class_11683.class_11792 crumblingOverlayCommand,
            class_4730 spriteIdentifier, int i) {
        matrixStack.method_22903();
        this.setTransforms(matrixStack, facing, openness);
        class_1921 renderLayer = spriteIdentifier.method_24146(this.model::method_23500);
        class_1058 sprite = this.spriteHolder.method_73030(spriteIdentifier);
        orderedRenderCommandQueue.method_73490(this.model, openness, matrixStack, renderLayer,
                light, overlay, -1, sprite, i, crumblingOverlayCommand);
        matrixStack.method_22909();
    }

    private void setTransforms(class_4587 matrixStack, class_2350 facing, float openness) {
        matrixStack.method_46416(0.5F, 0.5F, 0.5F);
        float f = 0.9995F;
        matrixStack.method_22905(f, f, f);
        matrixStack.method_22907(facing.method_23224());
        matrixStack.method_22905(1.0F, -1.0F, -1.0F);
        matrixStack.method_46416(0.0F, -1.0F, 0.0F);
        this.model.setAngles(openness);
    }

    public void collectVertices(class_2350 facing, float openness, Set<Vector3f> vertices) {
        class_4587 matrixStack = new class_4587();
        this.setTransforms(matrixStack, facing, openness);
        this.model.method_63512().method_72152(matrixStack, vertices);
    }

    @Environment(EnvType.CLIENT)
    static class ShulkerBoxBlockModel extends class_3879<Float> {
        private final class_630 lid;

        public ShulkerBoxBlockModel(class_630 root) {
            super(root, class_1921::method_23578);
            this.lid = root.method_32086("lid");
        }

        public void setAngles(Float openness) {
            super.method_2819(openness);
            this.lid.method_2851(0.0F, 24.0F - openness * 0.5F * 16.0F, 0.0F);
            this.lid.field_3675 = 270.0F * openness * (float) (Math.PI / 180.0);
        }
    }
}
