package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_167;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_8779;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.gametest.util.MockServerPlayerHelper;
import atonkish.reinfshulker.item.ModItems;

public class AdvancementTests {
    private static final Map<class_1767, class_1792> SHULKER_BOX_MAP = new LinkedHashMap<>() {
        {
            put((class_1767) null, class_1802.field_8545);
            put(class_1767.field_7952, class_1802.field_8722);
            put(class_1767.field_7946, class_1802.field_8380);
            put(class_1767.field_7958, class_1802.field_8050);
            put(class_1767.field_7951, class_1802.field_8829);
            put(class_1767.field_7947, class_1802.field_8271);
            put(class_1767.field_7961, class_1802.field_8548);
            put(class_1767.field_7954, class_1802.field_8520);
            put(class_1767.field_7944, class_1802.field_8627);
            put(class_1767.field_7967, class_1802.field_8451);
            put(class_1767.field_7955, class_1802.field_8213);
            put(class_1767.field_7945, class_1802.field_8816);
            put(class_1767.field_7966, class_1802.field_8350);
            put(class_1767.field_7957, class_1802.field_8584);
            put(class_1767.field_7942, class_1802.field_8461);
            put(class_1767.field_7964, class_1802.field_8676);
            put(class_1767.field_7963, class_1802.field_8268);
        }
    };

    private static final String BATCH_ID = String.format("%s:AdvancementBatch",
            ReinforcedShulkerBoxesMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_1792 item : SHULKER_BOX_MAP.values()) {
                add(AdvancementTests.createTest(
                        String.format("Obtain Copper Shulker Box recipe advancement by having %s",
                                item.method_7848().getString()),
                        item,
                        new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/copper_shulker_box")));
            }
            add(AdvancementTests.createTest(
                    "Obtain Copper Shulker Box recipe advancement by having Copper Ingot",
                    class_1802.field_27022,
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/copper_shulker_box")));
            add(AdvancementTests.createTest(
                    "Obtain Copper Shulker Box recipe advancement by having Copper Chest",
                    atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/copper_shulker_box_from_copper_chest")));

            // Iron Shulker Box
            for (class_1792 item : ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                    .values()) {
                add(AdvancementTests.createTest(
                        String.format("Obtain Iron Shulker Box recipe advancement by having %s",
                                item.method_7848().getString()),
                        item,
                        new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/iron_shulker_box")));
            }
            add(AdvancementTests.createTest(
                    "Obtain Iron Shulker Box recipe advancement by having Iron Ingot",
                    class_1802.field_8620,
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/iron_shulker_box")));
            add(AdvancementTests.createTest(
                    "Obtain Iron Shulker Box recipe advancement by having Iron Chest",
                    atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/iron_shulker_box_from_iron_chest")));

            // Gold Shulker Box
            for (class_1792 item : ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                    .values()) {
                add(AdvancementTests.createTest(
                        String.format("Obtain Gold Shulker Box recipe advancement by having %s",
                                item.method_7848().getString()),
                        item,
                        new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/gold_shulker_box")));
            }
            add(AdvancementTests.createTest(
                    "Obtain Gold Shulker Box recipe advancement by having Gold Ingot",
                    class_1802.field_8695,
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/gold_shulker_box")));
            add(AdvancementTests.createTest(
                    "Obtain Gold Shulker Box recipe advancement by having Gold Chest",
                    atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/gold_shulker_box_from_gold_chest")));

            // Diamond Shulker Box
            for (class_1792 item : ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                    .values()) {
                add(AdvancementTests.createTest(
                        String.format("Obtain Diamond Shulker Box recipe advancement by having %s",
                                item.method_7848().getString()),
                        item,
                        new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/diamond_shulker_box")));
            }
            add(AdvancementTests.createTest(
                    "Obtain Diamond Shulker Box recipe advancement by having Diamond Ingot",
                    class_1802.field_8477,
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID, "recipes/decorations/diamond_shulker_box")));
            add(AdvancementTests.createTest(
                    "Obtain Diamond Shulker Box recipe advancement by having Diamond Chest",
                    atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/diamond_shulker_box_from_diamond_chest")));

            // Netherite Shulker Box
            for (class_1792 item : ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                    .values()) {
                add(AdvancementTests.createTest(
                        String.format("Obtain Netherite Shulker Box recipe advancement by having %s",
                                item.method_7848().getString()),
                        item,
                        new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                                "recipes/decorations/netherite_shulker_box_smithing")));
            }
            add(AdvancementTests.createTest(
                    "Obtain Netherite Shulker Box recipe advancement by having Netherite Ingot",
                    class_1802.field_22020,
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/netherite_shulker_box_smithing")));
            add(AdvancementTests.createTest(
                    "Obtain Netherite Shulker Box recipe advancement by having Netherite Chest",
                    atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                            .get(ReinforcingMaterials.MAP.get("netherite")),
                    new class_2960(ReinforcedShulkerBoxesMod.MOD_ID,
                            "recipes/decorations/netherite_shulker_box_from_netherite_chest")));
        }
    };

    private static class_4529 createTest(String name, class_1792 item, class_2960 advancementId) {
        String testName = String.format("%s %s %s",
                ReinforcedShulkerBoxesMod.MOD_ID,
                AdvancementTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                AdvancementTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3222 player = MockServerPlayerHelper.spawn(context,
                            class_1934.field_9215, class_243.method_24954(class_2338.field_10980));
                    class_8779 entry = context.method_35943().method_8503().method_3851().method_12896(advancementId);
                    class_167 progress = player.method_14236().method_12882(entry);

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    Map<String, Boolean> progressMap = new HashMap<String, Boolean>();
                    String progressMapKeyBeforeHavingItem = "beforeHavingItem";
                    String progressMapKeyAfterHavingItem = "afterHavingItem";

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        progressMap.put(progressMapKeyBeforeHavingItem, progress.method_740());

                        player.method_7270(new class_1799(item));

                        futurePartialAct1.complete(null);
                    });

                    long tickObtained = 1;
                    context.method_35951(tickObtained, () -> {
                        progressMap.put(progressMapKeyAfterHavingItem, progress.method_740());

                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_49994(
                                    progressMap.get(progressMapKeyBeforeHavingItem), String.format(
                                            "Expected that advancement %s has not been done yet, but it has been already done.",
                                            entry));
                            context.method_46226(
                                    progressMap.get(progressMapKeyAfterHavingItem), String.format(
                                            "Expected that advancement %s has been done, but it has not been done yet.",
                                            entry));
                        } catch (Exception e) {
                            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        } finally {
                            MockServerPlayerHelper.destroy(context, player);
                        }

                        context.method_36036();
                    });
                });
    }
}
