package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_5455;
import net.minecraft.class_9694;
import net.minecraft.class_9695;
import net.minecraft.class_9697;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.item.ModItems;

public class RecipeTests {
    private static final String BATCH_ID = String.format("%s:RecipeBatch",
            ReinforcedBarrelsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            {
                class_1799 baseBarrel = new class_1799(class_1802.field_16307);
                class_1799 material = new class_1799(class_1802.field_27022);
                class_1799 barrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper")));

                add(RecipeTests.createTest(
                        "Craft Copper Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Iron Barrel
            {
                class_1799 baseBarrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper")));
                class_1799 material = new class_1799(class_1802.field_8620);
                class_1799 barrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron")));

                add(RecipeTests.createTest(
                        "Craft Iron Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Gold Barrel
            {
                class_1799 baseBarrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron")));
                class_1799 material = new class_1799(class_1802.field_8695);
                class_1799 barrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold")));

                add(RecipeTests.createTest(
                        "Craft Gold Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Diamond Barrel
            {
                class_1799 baseBarrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold")));
                class_1799 material = new class_1799(class_1802.field_8477);
                class_1799 barrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond")));

                add(RecipeTests.createTest(
                        "Craft Diamond Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Netherite Barrel
            {
                class_1799 template = new class_1799(class_1802.field_41946);
                class_1799 baseBarrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond")));
                class_1799 material = new class_1799(class_1802.field_22020);
                class_1799 barrel = new class_1799(
                        ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("netherite")));

                add(RecipeTests.createTest(
                        "Smithing Netherite Barrel",
                        class_3956.field_25388,
                        new class_9697(template, baseBarrel, material),
                        barrel));
            }
        }
    };

    private static <I extends class_9695, T extends class_1860<I>> class_4529 createTest(String name,
            class_3956<T> type, I input, class_1799 expected) {
        String testName = String.format("%s %s %s",
                ReinforcedBarrelsMod.MOD_ID,
                RecipeTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                RecipeTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3218 world = context.method_35943();
                    class_1863 recipeManager = world.method_64577();
                    class_5455 registryManager = world.method_30349();
                    T recipe = recipeManager.method_8132(type, input, world).orElseThrow().comp_1933();

                    // Act
                    class_1799 actual = recipe.method_8116(input, registryManager);

                    // Assert
                    try {
                        context.method_46226(class_1799.method_7973(actual, expected),
                                "Recipe result differs from expected.");
                    } catch (Exception e) {
                        ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
