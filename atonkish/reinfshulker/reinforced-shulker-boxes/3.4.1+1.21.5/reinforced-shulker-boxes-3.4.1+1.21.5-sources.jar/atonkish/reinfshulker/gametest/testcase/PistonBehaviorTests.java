package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2960;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.gametest.util.TestIdentifier;

public class PistonBehaviorTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:piston_behavior/default",
            ReinforcedShulkerBoxesMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP
                    .get(ReinforcingMaterials.MAP.get("copper"))
                    .values()) {
                add(PistonBehaviorTests.createTest(
                        String.format("Piston breaks %s", block.method_9518().getString()), block));
            }

            // Iron Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP
                    .get(ReinforcingMaterials.MAP.get("iron"))
                    .values()) {
                add(PistonBehaviorTests.createTest(
                        String.format("Piston breaks %s", block.method_9518().getString()), block));
            }

            // Gold Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP
                    .get(ReinforcingMaterials.MAP.get("gold"))
                    .values()) {
                add(PistonBehaviorTests.createTest(
                        String.format("Piston breaks %s", block.method_9518().getString()), block));
            }

            // Diamond Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP
                    .get(ReinforcingMaterials.MAP.get("diamond"))
                    .values()) {
                add(PistonBehaviorTests.createTest(
                        String.format("Piston breaks %s", block.method_9518().getString()), block));
            }

            // Netherite Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP
                    .get(ReinforcingMaterials.MAP.get("netherite"))
                    .values()) {
                add(PistonBehaviorTests.createTest(
                        String.format("Piston breaks %s", block.method_9518().getString()), block));
            }
        }
    };

    private static TestFunction createTest(String name, class_2248 shulkerBoxBlock) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedShulkerBoxesMod.MOD_ID,
                PistonBehaviorTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                PistonBehaviorTests.TEST_ENVIRONMENT_DEFAULT,
                PistonBehaviorTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, shulkerBoxBlock);
                    context.method_35984(blockPos.method_10077(1), class_2246.field_10560);

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        context.method_35981(blockPos.method_10077(1).method_10086(1), 1);

                        futurePartialAct1.complete(null);
                    });

                    long tickShulkerBoxBreaking = 2;
                    context.method_35951(tickShulkerBoxBreaking, () -> {
                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_35972(class_2246.field_10124, blockPos);
                            context.method_35969(shulkerBoxBlock.method_8389(), blockPos, 1);
                        } catch (Exception e) {
                            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                            throw e;
                        }

                        context.method_36036();
                    });
                });
    }
}
