
package atonkish.reinfchest.client.render.block.entity;

import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import it.unimi.dsi.fastutil.ints.Int2IntFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_4732.class_3923;
import net.minecraft.class_4732.class_4734;
import net.minecraft.class_4737;
import net.minecraft.class_4739;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_826;
import net.minecraft.class_827;
import net.minecraft.class_9944;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfchest.block.entity.ReinforcedChestBlockEntity;
import atonkish.reinfchest.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedChestBlockEntityRenderer<T extends class_2586 & class_2618> implements class_827<T> {
    private final class_9944 singleChest;
    private final class_9944 doubleChestLeft;
    private final class_9944 doubleChestRight;
    private final boolean christmas = class_826.method_65559();

    public ReinforcedChestBlockEntityRenderer(class_5614.class_5615 context) {
        this.singleChest = new class_9944(context.method_32140(class_5602.field_27689));
        this.doubleChestLeft = new class_9944(context.method_32140(class_5602.field_27551));
        this.doubleChestRight = new class_9944(context.method_32140(class_5602.field_27552));
    }

    @Override
    public void method_3569(T entity, float tickProgress, class_4587 matrices, class_4597 vertexConsumers,
            int light, int overlay, class_243 cameraPos) {
        class_1937 world = entity.method_10997();
        boolean bl = world != null;
        class_2680 blockState = bl
                ? entity.method_11010()
                : (class_2680) class_2246.field_10034.method_9564().method_11657(class_2281.field_10768, class_2350.field_11035);
        class_2745 chestType = blockState.method_28498(class_2281.field_10770)
                ? (class_2745) blockState.method_11654(class_2281.field_10770)
                : class_2745.field_12569;
        if (blockState.method_26204() instanceof class_4739<?> abstractChestBlock) {
            boolean bl2 = chestType != class_2745.field_12569;
            matrices.method_22903();
            float f = ((class_2350) blockState.method_11654(class_2281.field_10768)).method_10144();
            matrices.method_46416(0.5F, 0.5F, 0.5F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-f));
            matrices.method_46416(-0.5F, -0.5F, -0.5F);
            class_4734<? extends class_2595> propertySource;
            if (bl) {
                propertySource = abstractChestBlock.method_24167(blockState, world, entity.method_11016(), true);
            } else {
                propertySource = class_3923::method_24174;
            }

            float g = ((Float2FloatFunction) propertySource.apply(class_2281.method_24166(entity)))
                    .get(tickProgress);
            g = 1.0F - g;
            g = 1.0F - g * g * g;
            int i = ((Int2IntFunction) propertySource.apply(new class_4737<>())).applyAsInt(light);
            ReinforcingMaterial material = ((ReinforcedChestBlockEntity) entity).getMaterial();
            class_4730 spriteIdentifier = ModTexturedRenderLayers.getReinforcedChestTexture(material, entity,
                    chestType, this.christmas);
            class_4588 vertexConsumer = spriteIdentifier.method_24145(vertexConsumers,
                    class_1921::method_23576);
            if (bl2) {
                if (chestType == class_2745.field_12574) {
                    this.render(matrices, vertexConsumer, this.doubleChestLeft, g, i, overlay);
                } else {
                    this.render(matrices, vertexConsumer, this.doubleChestRight, g, i, overlay);
                }
            } else {
                this.render(matrices, vertexConsumer, this.singleChest, g, i, overlay);
            }

            matrices.method_22909();
        }
    }

    private void render(class_4587 matrices, class_4588 vertices, class_9944 model, float animationProgress,
            int light, int overlay) {
        model.method_62069(animationProgress);
        model.method_60879(matrices, vertices, light, overlay);
    }
}
