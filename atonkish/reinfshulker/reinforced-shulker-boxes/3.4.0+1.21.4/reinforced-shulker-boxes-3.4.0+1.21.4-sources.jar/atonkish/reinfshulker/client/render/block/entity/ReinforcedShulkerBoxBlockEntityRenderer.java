package atonkish.reinfshulker.client.render.block.entity;

import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2480;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_827;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxBlockEntityRenderer implements class_827<ReinforcedShulkerBoxBlockEntity> {
    private final ShulkerBoxBlockModel model;

    public ReinforcedShulkerBoxBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.model = new ShulkerBoxBlockModel(ctx.method_32140(class_5602.field_27596));
    }

    @Override
    public void render(ReinforcedShulkerBoxBlockEntity shulkerBoxBlockEntity, float tickDelta, class_4587 matrixStack,
            class_4597 vertexConsumerProvider, int lignt, int overlay) {
        class_2350 direction = class_2350.field_11036;
        if (shulkerBoxBlockEntity.method_11002()) {
            class_2680 blockState = shulkerBoxBlockEntity.method_10997().method_8320(shulkerBoxBlockEntity.method_11016());
            if (blockState.method_26204() instanceof class_2480) {
                direction = (class_2350) blockState.method_11654(class_2480.field_11496);
            }
        }

        class_1767 color = shulkerBoxBlockEntity.method_11320();
        ReinforcingMaterial material = shulkerBoxBlockEntity.getMaterial();
        class_4730 spriteIdentifier;
        if (color == null) {
            spriteIdentifier = ModTexturedRenderLayers.REINFORCED_SHULKER_TEXTURE_ID_MAP.get(material);
        } else {
            spriteIdentifier = ModTexturedRenderLayers.COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.get(material)
                    .get(color.method_7789());
        }

        matrixStack.method_22903();
        matrixStack.method_46416(0.5F, 0.5F, 0.5F);
        float g = 0.9995F;
        matrixStack.method_22905(g, g, g);
        matrixStack.method_22907(direction.method_23224());
        matrixStack.method_22905(1.0F, -1.0F, -1.0F);
        matrixStack.method_46416(0.0F, -1.0F, 0.0F);
        this.model.animateLid(shulkerBoxBlockEntity, tickDelta);
        Objects.requireNonNull(this.model);
        class_4588 vertexConsumer = spriteIdentifier.method_24145(vertexConsumerProvider,
                this.model::method_23500);
        this.model.method_60879(matrixStack, vertexConsumer, lignt, overlay);
        matrixStack.method_22909();
    }

    // NOTE: it was re-implemented because an error occurs at the start of the game
    // when attempting to access ShulkerBoxBlockModel using accesswidener.
    class ShulkerBoxBlockModel extends class_3879 {
        private final class_630 lid;

        public ShulkerBoxBlockModel(class_630 root) {
            super(root, class_1921::method_23578);
            this.lid = root.method_32086("lid");
        }

        public void animateLid(class_2627 blockEntity, float delta) {
            this.lid.method_2851(0.0F, 24.0F - blockEntity.method_11312(delta) * 0.5F * 16.0F, 0.0F);
            this.lid.field_3675 = 270.0F * blockEntity.method_11312(delta) * 0.017453292F;
        }
    }
}
