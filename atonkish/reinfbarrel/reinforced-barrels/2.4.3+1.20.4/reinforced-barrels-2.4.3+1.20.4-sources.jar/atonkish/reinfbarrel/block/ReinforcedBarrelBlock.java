package atonkish.reinfbarrel.block;

import org.jetbrains.annotations.Nullable;

import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3708;
import net.minecraft.class_3719;
import net.minecraft.class_3965;
import net.minecraft.class_4838;
import net.minecraft.class_4970;
import atonkish.reinfbarrel.block.entity.ReinforcedBarrelBlockEntity;
import atonkish.reinfbarrel.stat.ModStats;

public class ReinforcedBarrelBlock extends class_3708 {
    private final ReinforcingMaterial material;

    public ReinforcedBarrelBlock(ReinforcingMaterial material, class_4970.class_2251 settings) {
        super(settings);
        this.material = material;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand,
            class_3965 hit) {
        if (world.field_9236) {
            return class_1269.field_5812;
        } else {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof class_3719) {
                player.method_17355((class_3719) blockEntity);
                player.method_7281(ModStats.OPEN_REINFORCED_BARREL_MAP.get(this.material));
                class_4838.method_24733(player, true);
            }

            return class_1269.field_21466;
        }
    }

    @Override
    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ReinforcedBarrelBlockEntity(this.material, pos, state);
    }
}
