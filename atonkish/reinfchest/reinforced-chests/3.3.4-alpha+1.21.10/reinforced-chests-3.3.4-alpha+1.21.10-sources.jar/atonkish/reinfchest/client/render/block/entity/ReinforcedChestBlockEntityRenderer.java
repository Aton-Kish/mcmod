
package atonkish.reinfchest.client.render.block.entity;

import org.jetbrains.annotations.Nullable;

import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import it.unimi.dsi.fastutil.ints.Int2IntFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11701;
import net.minecraft.class_11954;
import net.minecraft.class_11959;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4730;
import net.minecraft.class_4732;
import net.minecraft.class_4737;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_826;
import net.minecraft.class_827;
import net.minecraft.class_9944;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfchest.block.ReinforcedChestBlock;
import atonkish.reinfchest.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedChestBlockEntityRenderer<T extends class_2586 & class_2618>
        implements class_827<T, class_11959> {
    private final class_11701 materials;
    private final class_9944 singleChest;
    private final class_9944 doubleChestLeft;
    private final class_9944 doubleChestRight;
    private final boolean christmas;

    public ReinforcedChestBlockEntityRenderer(class_5614.class_5615 context) {
        this.materials = context.comp_4541();
        this.christmas = class_826.method_65559();
        this.singleChest = new class_9944(context.method_32140(class_5602.field_27689));
        this.doubleChestLeft = new class_9944(context.method_32140(class_5602.field_27551));
        this.doubleChestRight = new class_9944(context.method_32140(class_5602.field_27552));
    }

    public class_11959 method_74335() {
        return new class_11959();
    }

    @Override
    public void updateRenderState(T blockEntity, class_11959 chestBlockEntityRenderState, float f,
            class_243 vec3d, @Nullable class_11683.class_11792 crumblingOverlayCommand) {
        class_4732.class_4734<? extends class_2595> propertySource = class_4732.class_3923::method_24174;

        class_11954.method_74399(blockEntity, chestBlockEntityRenderState,
                crumblingOverlayCommand);
        boolean bl = blockEntity.method_10997() != null;
        class_2680 blockState = bl
                ? blockEntity.method_11010()
                : (class_2680) class_2246.field_10034.method_9564().method_11657(class_2281.field_10768, class_2350.field_11035);
        chestBlockEntityRenderState.field_62693 = blockState.method_28498(class_2281.field_10770)
                ? (class_2745) blockState.method_11654(class_2281.field_10770)
                : class_2745.field_12569;
        chestBlockEntityRenderState.field_62695 = ((class_2350) blockState.method_11654(class_2281.field_10768))
                .method_10144();
        chestBlockEntityRenderState.field_62696 = this.getVariant(blockEntity, this.christmas);
        if (bl) {
            class_2248 block = blockState.method_26204();
            if (block instanceof ReinforcedChestBlock) {
                ReinforcedChestBlock chestBlock = (ReinforcedChestBlock) block;
                propertySource = chestBlock.method_24167(blockState, blockEntity.method_10997(),
                        blockEntity.method_11016(), true);
            }
        }

        chestBlockEntityRenderState.field_62694 = ((Float2FloatFunction) propertySource
                .apply(class_2281.method_24166((class_2618) blockEntity))).get(f);
        if (chestBlockEntityRenderState.field_62693 != class_2745.field_12569) {
            chestBlockEntityRenderState.field_62676 = ((Int2IntFunction) propertySource
                    .apply(new class_4737<>()))
                    .applyAsInt(chestBlockEntityRenderState.field_62676);
        }

    }

    public void render(class_11959 chestBlockEntityRenderState, class_4587 matrixStack,
            class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState) {
        matrixStack.method_22903();
        matrixStack.method_46416(0.5F, 0.5F, 0.5F);
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-chestBlockEntityRenderState.field_62695));
        matrixStack.method_46416(-0.5F, -0.5F, -0.5F);
        float f = chestBlockEntityRenderState.field_62694;
        f = 1.0F - f;
        f = 1.0F - f * f * f;
        ReinforcingMaterial material = ((ReinforcedChestBlock) chestBlockEntityRenderState.field_62674.method_26204())
                .getMaterial();
        class_4730 spriteIdentifier = ModTexturedRenderLayers.getReinforcedChestTextureId(material,
                chestBlockEntityRenderState.field_62696,
                chestBlockEntityRenderState.field_62693);
        class_1921 renderLayer = spriteIdentifier.method_24146(class_1921::method_23576);
        class_1058 sprite = this.materials.method_73030(spriteIdentifier);
        if (chestBlockEntityRenderState.field_62693 != class_2745.field_12569) {
            if (chestBlockEntityRenderState.field_62693 == class_2745.field_12574) {
                orderedRenderCommandQueue.method_73490(this.doubleChestLeft, f, matrixStack, renderLayer,
                        chestBlockEntityRenderState.field_62676, class_4608.field_21444, -1, sprite, 0,
                        chestBlockEntityRenderState.field_62677);
            } else {
                orderedRenderCommandQueue.method_73490(this.doubleChestRight, f, matrixStack, renderLayer,
                        chestBlockEntityRenderState.field_62676, class_4608.field_21444, -1, sprite, 0,
                        chestBlockEntityRenderState.field_62677);
            }
        } else {
            orderedRenderCommandQueue.method_73490(this.singleChest, f, matrixStack, renderLayer,
                    chestBlockEntityRenderState.field_62676, class_4608.field_21444, -1, sprite, 0,
                    chestBlockEntityRenderState.field_62677);
        }

        matrixStack.method_22909();
    }

    private class_11959.class_11960 getVariant(class_2586 blockEntity, boolean christmas) {
        if (christmas) {
            return class_11959.class_11960.field_62698;
        } else {
            return class_11959.class_11960.field_62704;
        }
    }
}
