package atonkish.reinfshulker.client.render.block.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5599;
import net.minecraft.class_5602;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_827;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxBlockEntityRenderer implements class_827<ReinforcedShulkerBoxBlockEntity> {
    private final ShulkerBoxBlockModel model;

    public ReinforcedShulkerBoxBlockEntityRenderer(class_5614.class_5615 ctx) {
        this(ctx.method_32142());
    }

    public ReinforcedShulkerBoxBlockEntityRenderer(class_5599 models) {
        this.model = new ShulkerBoxBlockModel(models.method_32072(class_5602.field_52997));
    }

    @Override
    public void render(ReinforcedShulkerBoxBlockEntity shulkerBoxBlockEntity, float tickDelta, class_4587 matrixStack,
            class_4597 vertexConsumerProvider, int light, int overlay, class_243 vec3d) {
        class_2350 direction = (class_2350) shulkerBoxBlockEntity.method_11010().method_61767(class_2480.field_11496,
                class_2350.field_11036);
        class_1767 color = shulkerBoxBlockEntity.method_11320();
        ReinforcingMaterial material = shulkerBoxBlockEntity.getMaterial();
        class_4730 spriteIdentifier;
        if (color == null) {
            spriteIdentifier = ModTexturedRenderLayers.REINFORCED_SHULKER_TEXTURE_ID_MAP.get(material);
        } else {
            spriteIdentifier = ModTexturedRenderLayers.COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.get(material)
                    .get(color.method_7789());
        }

        float openness = shulkerBoxBlockEntity.method_11312(tickDelta);
        this.render(matrixStack, vertexConsumerProvider, light, overlay, direction, openness, spriteIdentifier);
    }

    public void render(
            class_4587 matrixStack, class_4597 vertexConsumerProvider, int light, int overlay,
            class_2350 facing, float openness, class_4730 textureId) {
        matrixStack.method_22903();
        matrixStack.method_46416(0.5F, 0.5F, 0.5F);
        float f = 0.9995F;
        matrixStack.method_22905(f, f, f);
        matrixStack.method_22907(facing.method_23224());
        matrixStack.method_22905(1.0F, -1.0F, -1.0F);
        matrixStack.method_46416(0.0F, -1.0F, 0.0F);
        this.model.animateLid(openness);
        class_4588 vertexConsumer = textureId.method_24145(vertexConsumerProvider, this.model::method_23500);
        this.model.method_60879(matrixStack, vertexConsumer, light, overlay);
        matrixStack.method_22909();
    }

    @Environment(EnvType.CLIENT)
    static class ShulkerBoxBlockModel extends class_3879 {
        private final class_630 lid;

        public ShulkerBoxBlockModel(class_630 root) {
            super(root, class_1921::method_23578);
            this.lid = root.method_32086("lid");
        }

        public void animateLid(float openness) {
            this.lid.method_2851(0.0F, 24.0F - openness * 0.5F * 16.0F, 0.0F);
            this.lid.field_3675 = 270.0F * openness * (float) (Math.PI / 180.0);
        }
    }
}
