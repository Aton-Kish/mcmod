package atonkish.reinfchest.gametest;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_4529;
import net.minecraft.class_6303;
import atonkish.reinfchest.gametest.testcase.AdvancementTests;
import atonkish.reinfchest.gametest.testcase.InventoryTests;
import atonkish.reinfchest.gametest.testcase.LootTableTests;
import atonkish.reinfchest.gametest.testcase.OpenTests;
import atonkish.reinfchest.gametest.testcase.PiglinTests;
import atonkish.reinfchest.gametest.testcase.RecipeTests;

public class ReinforcedChestsModGameTest {
    @class_6303
    public Collection<class_4529> registerTests() {
        Collection<class_4529> testFunctions = new ArrayList<>();

        if (System.getProperty(this.getClass().getPackageName()) == null) {
            return testFunctions;
        }

        testFunctions.addAll(AdvancementTests.TEST_FUNCTIONS);
        testFunctions.addAll(InventoryTests.TEST_FUNCTIONS);
        testFunctions.addAll(LootTableTests.TEST_FUNCTIONS);
        testFunctions.addAll(OpenTests.TEST_FUNCTIONS);
        testFunctions.addAll(PiglinTests.TEST_FUNCTIONS);
        testFunctions.addAll(RecipeTests.TEST_FUNCTIONS);

        return testFunctions;
    }
}
