package atonkish.reinfshulker.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import net.minecraft.class_1799;
import net.minecraft.class_1871;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_8566;

@Mixin(class_1871.class)
public class ShulkerBoxColoringRecipeMixin {
    @Inject(at = @At("HEAD"), method = "matches", cancellable = true)
    public void matches(class_8566 recipeInputInventory, class_1937 world,
            CallbackInfoReturnable<Boolean> infoReturnable) {
        for (int k = 0; k < recipeInputInventory.method_5439(); ++k) {
            class_1799 itemStack = recipeInputInventory.method_5438(k);
            if (class_2248.method_9503(itemStack.method_7909()) instanceof ReinforcedShulkerBoxBlock) {
                infoReturnable.setReturnValue(false);
            }
        }
    }
}
