package atonkish.reinfchest.block;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfchest.block.entity.ModBlockEntityType;

public class ModBlocks {
    public static final Map<ReinforcingMaterial, class_2248> REINFORCED_CHEST_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, class_2248.Settings> REINFORCED_CHEST_SETTINGS_MAP = new LinkedHashMap<>();

    public static class_2248 registerMaterial(String namespace, ReinforcingMaterial material, class_2248.Settings settings) {
        if (!REINFORCED_CHEST_SETTINGS_MAP.containsKey(material)) {
            REINFORCED_CHEST_SETTINGS_MAP.put(material, settings);
        }

        if (!REINFORCED_CHEST_MAP.containsKey(material)) {
            class_2248 block = ModBlocks.register(namespace, material.getName() + "_chest",
                    new ReinforcedChestBlock(material, REINFORCED_CHEST_SETTINGS_MAP.get(material), () -> {
                        return ModBlockEntityType.REINFORCED_CHEST_MAP.get(material);
                    }));
            REINFORCED_CHEST_MAP.put(material, block);
        }

        return REINFORCED_CHEST_MAP.get(material);
    }

    private static class_2248 register(String namespace, String id, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, new class_2960(namespace, id), block);
    }
}
