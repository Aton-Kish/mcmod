package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1268;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import net.minecraft.class_3468;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.gametest.util.MockServerPlayerHelper;
import atonkish.reinfshulker.gametest.util.TestIdentifier;
import atonkish.reinfshulker.item.ModItems;
import atonkish.reinfshulker.stat.ModStats;

public class CauldronBehaviorTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:cauldron_behavior/default",
            ReinforcedShulkerBoxesMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_1767 color : class_1767.values()) {
                ReinforcedShulkerBoxBlock shulkerBoxBlock = (ReinforcedShulkerBoxBlock) ModBlocks.REINFORCED_SHULKER_BOX_MAP
                        .get(ReinforcingMaterials.MAP.get("copper"))
                        .get(color);

                add(CauldronBehaviorTests.createTest(
                        String.format("Clean %s", shulkerBoxBlock.method_9518().getString()),
                        shulkerBoxBlock));
            }

            // Iron Shulker Box
            for (class_1767 color : class_1767.values()) {
                ReinforcedShulkerBoxBlock shulkerBoxBlock = (ReinforcedShulkerBoxBlock) ModBlocks.REINFORCED_SHULKER_BOX_MAP
                        .get(ReinforcingMaterials.MAP.get("iron"))
                        .get(color);

                add(CauldronBehaviorTests.createTest(
                        String.format("Clean %s", shulkerBoxBlock.method_9518().getString()),
                        shulkerBoxBlock));
            }

            // Gold Shulker Box
            for (class_1767 color : class_1767.values()) {
                ReinforcedShulkerBoxBlock shulkerBoxBlock = (ReinforcedShulkerBoxBlock) ModBlocks.REINFORCED_SHULKER_BOX_MAP
                        .get(ReinforcingMaterials.MAP.get("gold"))
                        .get(color);

                add(CauldronBehaviorTests.createTest(
                        String.format("Clean %s", shulkerBoxBlock.method_9518().getString()),
                        shulkerBoxBlock));
            }

            // Diamond Shulker Box
            for (class_1767 color : class_1767.values()) {
                ReinforcedShulkerBoxBlock shulkerBoxBlock = (ReinforcedShulkerBoxBlock) ModBlocks.REINFORCED_SHULKER_BOX_MAP
                        .get(ReinforcingMaterials.MAP.get("diamond"))
                        .get(color);

                add(CauldronBehaviorTests.createTest(
                        String.format("Clean %s", shulkerBoxBlock.method_9518().getString()),
                        shulkerBoxBlock));
            }

            // Netherite Shulker Box
            for (class_1767 color : class_1767.values()) {
                ReinforcedShulkerBoxBlock shulkerBoxBlock = (ReinforcedShulkerBoxBlock) ModBlocks.REINFORCED_SHULKER_BOX_MAP
                        .get(ReinforcingMaterials.MAP.get("netherite"))
                        .get(color);

                add(CauldronBehaviorTests.createTest(
                        String.format("Clean %s", shulkerBoxBlock.method_9518().getString()),
                        shulkerBoxBlock));
            }
        }
    };

    private static TestFunction createTest(String name, ReinforcedShulkerBoxBlock shulkerBoxBlock) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedShulkerBoxesMod.MOD_ID,
                CauldronBehaviorTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                CauldronBehaviorTests.TEST_ENVIRONMENT_DEFAULT,
                CauldronBehaviorTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35986(blockPos,
                            class_2246.field_27097.method_9564().method_11657(class_2741.field_12513, 3));

                    class_3222 player = MockServerPlayerHelper.spawn(context,
                            class_1934.field_9215,
                            class_243.method_24954(blockPos.method_10077(4)));
                    player.method_6122(class_1268.field_5808, new class_1799(shulkerBoxBlock.method_8389()));

                    class_3445<class_2960> stat = class_3468.field_15419
                            .method_14956(ModStats.CLEAN_REINFORCED_SHULKER_BOX_MAP
                                    .get(shulkerBoxBlock.getMaterial()));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    Map<String, Integer> statMap = new HashMap<String, Integer>();
                    String statMapKeyBeforeCleaning = "beforeCleaning";
                    String statMapKeyAfterCleaning = "afterCleaning";

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        statMap.put(statMapKeyBeforeCleaning, player.method_14248().method_15025(stat));

                        context.method_36034(blockPos, player);

                        futurePartialAct1.complete(null);
                    });

                    long tickShulkerBoxCleaning = 1;
                    context.method_35951(tickShulkerBoxCleaning, () -> {
                        statMap.put(statMapKeyAfterCleaning, player.method_14248().method_15025(stat));

                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_56606(player.method_6047().method_7909(),
                                    ModItems.REINFORCED_SHULKER_BOX_MAP
                                            .get(shulkerBoxBlock.getMaterial())
                                            .get((class_1767) null),
                                    class_2561.method_30163("main hand item"));
                            context.method_56606(context.method_35980(blockPos).method_11654(class_2741.field_12513),
                                    2,
                                    class_2561.method_30163("fluid level"));
                            context.method_56606(
                                    statMap.get(statMapKeyAfterCleaning) - statMap.get(statMapKeyBeforeCleaning),
                                    1,
                                    class_2561.method_30163(String.format("diff %s value", stat.method_1225())));
                        } catch (Exception e) {
                            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                            throw e;
                        } finally {
                            MockServerPlayerHelper.destroy(context, player);
                        }

                        context.method_36036();
                    });
                });
    }
}
