package atonkish.reinfcore.api;

import atonkish.reinfcore.screen.ModScreenHandlerType;
import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcedStorageScreenModel;
import atonkish.reinfcore.util.ReinforcedStorageScreenModels;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfcore.util.ReinforcingMaterials;
import net.minecraft.class_1792;
import net.minecraft.class_3917;

public class ReinforcedCoreRegistry {
    public static ReinforcingMaterial registerReinforcingMaterial(String name, int size, class_1792 ingredient) {
        return ReinforcingMaterials.register(name, size, ingredient);
    }

    public static ReinforcedStorageScreenModel registerMaterialSingleBlockScreenModel(
            ReinforcingMaterial material) {
        return ReinforcedStorageScreenModels.registerMaterialSingleBlock(material);
    }

    public static ReinforcedStorageScreenModel registerMaterialDoubleBlockScreenModel(
            ReinforcingMaterial material) {
        return ReinforcedStorageScreenModels.registerMaterialDoubleBlock(material);
    }

    public static class_3917<ReinforcedStorageScreenHandler> registerMaterialSingleBlockScreenHandler(
            ReinforcingMaterial material) {
        return ModScreenHandlerType.registerMaterialSingleBlock(material);
    }

    public static class_3917<ReinforcedStorageScreenHandler> registerMaterialDoubleBlockScreenHandler(
            ReinforcingMaterial material) {
        return ModScreenHandlerType.registerMaterialDoubleBlock(material);
    }

    public static class_3917<ReinforcedStorageScreenHandler> registerMaterialShulkerBoxScreenHandler(
            ReinforcingMaterial material) {
        return ModScreenHandlerType.registerMaterialShulkerBox(material);
    }
}
