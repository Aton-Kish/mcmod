package atonkish.reinfshulker.integration.shulkerboxtooltip;

import com.misterpemodder.shulkerboxtooltip.api.ShulkerBoxTooltipApi;
import com.misterpemodder.shulkerboxtooltip.api.provider.PreviewProvider;
import com.misterpemodder.shulkerboxtooltip.api.provider.PreviewProviderRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfshulker.block.entity.ModBlockEntityType;
import atonkish.reinfshulker.item.ModItems;

public class ShulkerBoxTooltip implements ShulkerBoxTooltipApi {
    private static void register(PreviewProviderRegistry registry, String namespace, String id,
            PreviewProvider provider, class_1792... items) {
        registry.register(class_2960.method_60655(namespace, id), provider, items);
    }

    @Override
    public void registerProviders(PreviewProviderRegistry registry) {
        for (ReinforcingMaterial material : ReinforcingMaterials.MAP.values()) {
            String namespace = class_2591.method_11033(ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(material))
                    .method_12836();
            String id = material.getName() + "_shulker_box";
            class_1792[] items = ModItems.REINFORCED_SHULKER_BOX_MAP.get(material).values().toArray(new class_1792[0]);
            register(registry, namespace, id, new ReinforcedShulkerBoxPreviewProvider(material), items);
        }
    }
}
