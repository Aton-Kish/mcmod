package atonkish.reinfshulker;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5616;
import net.minecraft.class_811;
import atonkish.reinfcore.api.ReinforcedCoreClientModInitializer;
import atonkish.reinfcore.api.ReinforcedCoreClientRegistry;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.api.ReinforcedShulkerBoxesClientModInitializer;
import atonkish.reinfshulker.api.ReinforcedShulkerBoxesClientRegistry;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.block.entity.ModBlockEntityType;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.client.render.block.entity.ReinforcedShulkerBoxBlockEntityRenderer;
import atonkish.reinfshulker.util.ReinforcingMaterialSettings;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxesClientMod implements ReinforcedCoreClientModInitializer {
	@Override
	public void onInitializeReinforcedCoreClient() {
		// init Reinforced Core
		initializeReinforcedCoreClient();

		// init Reinforced Shulker Boxes
		initializeReinforcedShulkerBoxesClient();

		// entrypoint: "reinfshulker-client"
		FabricLoader.getInstance()
				.getEntrypoints(String.format("%s-client", ReinforcedShulkerBoxesMod.MOD_ID),
						ReinforcedShulkerBoxesClientModInitializer.class)
				.forEach(ReinforcedShulkerBoxesClientModInitializer::onInitializeReinforcedShulkerBoxesClient);
	}

	private static void initializeReinforcedCoreClient() {
		for (ReinforcingMaterialSettings materialSettings : ReinforcingMaterialSettings.values()) {
			ReinforcingMaterial material = materialSettings.getMaterial();

			// Reinforced Storage Screen
			ReinforcedCoreClientRegistry.registerMaterialShulkerBoxScreen(material);
		}
	}

	private static void initializeReinforcedShulkerBoxesClient() {
		for (ReinforcingMaterialSettings materialSettings : ReinforcingMaterialSettings.values()) {
			ReinforcingMaterial material = materialSettings.getMaterial();

			// Textured Render Layers
			ReinforcedShulkerBoxesClientRegistry.registerMaterialDefaultSprite(ReinforcedShulkerBoxesMod.MOD_ID,
					material);
			ReinforcedShulkerBoxesClientRegistry.registerMaterialColoringSprites(ReinforcedShulkerBoxesMod.MOD_ID,
					material);

			// Block Entity Renderer
			class_5616
					.method_32144(ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(material),
							ReinforcedShulkerBoxBlockEntityRenderer::new);

			// Item Renderer
			for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).values()) {
				BuiltinItemRendererRegistry.INSTANCE.register(block, (class_1799 stack, class_811 mode,
						class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) -> {
					class_2586 blockEntity = new ReinforcedShulkerBoxBlockEntity(material, class_2338.field_10980,
							block.method_9564());
					class_310.method_1551().method_31975().method_23077(blockEntity, matrices,
							vertexConsumers, light, overlay);
				});
			}
		}
	}
}
