package atonkish.reinfcore.util;

import net.minecraft.class_1792;

public class ReinforcingMaterial {
    private final String name;
    private final int size;
    private final class_1792 ingredient;

    public ReinforcingMaterial(String name, int size, class_1792 ingredient) {
        this.name = name;
        this.size = size;
        this.ingredient = ingredient;
    }

    public String toString() {
        return this.name;
    }

    public String getName() {
        return this.name;
    }

    public int getSize() {
        return this.size;
    }

    public class_1792 getIngredient() {
        return this.ingredient;
    }
}
