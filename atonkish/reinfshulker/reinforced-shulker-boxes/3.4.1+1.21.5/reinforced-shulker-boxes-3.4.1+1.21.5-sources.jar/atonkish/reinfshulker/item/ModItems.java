package atonkish.reinfshulker.item;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import atonkish.reinfcore.item.ModItemGroup;
import atonkish.reinfcore.item.ModItemGroups;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.ModBlocks;

public class ModItems {
    public static final Map<ReinforcingMaterial, Map<class_1767, class_1792>> REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, Map<class_1767, class_1792.class_1793>> REINFORCED_SHULKER_BOX_SETTINGS_MAP = new LinkedHashMap<>();

    public static class_1792 registerMaterialDyeColor(ReinforcingMaterial material, class_1767 color,
            class_1792.class_1793 settings) {
        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).containsKey(color)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).put(color, settings);
        }

        if (!REINFORCED_SHULKER_BOX_MAP.get(material).containsKey(color)) {
            class_1792 item = ModItems.register(ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).get(color),
                    REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).get(color));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_41059).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(ModItemGroups.REINFORCED_STORAGE).register(content -> content.method_45421(item));
            REINFORCED_SHULKER_BOX_MAP.get(material).put(color, item);
        }

        return REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
    }

    public static void registerMaterialDyeColorItemGroupIcon(ReinforcingMaterial material, class_1767 color) {
        class_1792 item = REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
        ModItemGroup.setIcon(class_7923.field_44687.method_29107(ModItemGroups.REINFORCED_STORAGE), item);
    }

    private static class_5321<class_1792> keyOf(class_5321<class_2248> blockKey) {
        return class_5321.method_29179(class_7924.field_41197, blockKey.method_29177());
    }

    public static class_1792 register(class_2248 block, class_1792.class_1793 settings) {
        return register(block, class_1747::new, settings);
    }

    private static class_1792 register(class_2248 block, BiFunction<class_2248, class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        return register(
                keyOf(block.method_40142().method_40237()),
                itemSettings -> (class_1792) factory.apply(block, itemSettings), settings.method_63685());
    }

    private static class_1792 register(class_5321<class_1792> key, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        class_1792 item = factory.apply(settings.method_63686(key));
        if (item instanceof class_1747 blockItem) {
            blockItem.method_7713(class_1792.field_8003, item);
        }

        return class_2378.method_39197(class_7923.field_41178, key, item);
    }
}
