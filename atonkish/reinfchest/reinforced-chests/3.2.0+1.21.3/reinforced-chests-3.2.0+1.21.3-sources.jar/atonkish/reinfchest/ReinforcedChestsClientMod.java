package atonkish.reinfchest;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5616;
import net.minecraft.class_811;
import atonkish.reinfcore.api.ReinforcedCoreClientModInitializer;
import atonkish.reinfcore.api.ReinforcedCoreClientRegistry;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfchest.api.ReinforcedChestsClientModInitializer;
import atonkish.reinfchest.api.ReinforcedChestsClientRegistry;
import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.block.ReinforcedChestBlock;
import atonkish.reinfchest.block.entity.ModBlockEntityType;
import atonkish.reinfchest.block.entity.ReinforcedChestBlockEntity;
import atonkish.reinfchest.client.render.block.entity.ReinforcedChestBlockEntityRenderer;
import atonkish.reinfchest.util.ReinforcingMaterialSettings;

@Environment(EnvType.CLIENT)
public class ReinforcedChestsClientMod implements ReinforcedCoreClientModInitializer {
	@Override
	public void onInitializeReinforcedCoreClient() {
		// init Reinforced Core
		initializeReinforcedCoreClient();

		// init Reinforced Chests
		initializeReinforcedChestsClient();

		// entrypoint: "reinfchest-client"
		FabricLoader.getInstance()
				.getEntrypoints(String.format("%s-client", ReinforcedChestsMod.MOD_ID),
						ReinforcedChestsClientModInitializer.class)
				.forEach(ReinforcedChestsClientModInitializer::onInitializeReinforcedChestsClient);
	}

	private static void initializeReinforcedCoreClient() {
		for (ReinforcingMaterialSettings materialSettings : ReinforcingMaterialSettings.values()) {
			ReinforcingMaterial material = materialSettings.getMaterial();

			// Reinforced Storage Screen
			ReinforcedCoreClientRegistry.registerMaterialSingleBlockScreen(material);
			ReinforcedCoreClientRegistry.registerMaterialDoubleBlockScreen(material);
		}
	}

	private static void initializeReinforcedChestsClient() {
		for (ReinforcingMaterialSettings materialSettings : ReinforcingMaterialSettings.values()) {
			ReinforcingMaterial material = materialSettings.getMaterial();

			// Textured Render Layers
			ReinforcedChestsClientRegistry.registerMaterialSingleSprite(ReinforcedChestsMod.MOD_ID, material);
			ReinforcedChestsClientRegistry.registerMaterialLeftSprite(ReinforcedChestsMod.MOD_ID, material);
			ReinforcedChestsClientRegistry.registerMaterialRightSprite(ReinforcedChestsMod.MOD_ID, material);

			// Block Entity Renderer
			class_5616
					.method_32144(ModBlockEntityType.REINFORCED_CHEST_MAP.get(material),
							ReinforcedChestBlockEntityRenderer::new);

			// Item Renderer
			class_2248 block = ModBlocks.REINFORCED_CHEST_MAP.get(material);
			BuiltinItemRendererRegistry.INSTANCE.register(block,
					(class_1799 stack, class_811 mode, class_4587 matrices,
							class_4597 vertexConsumers, int light, int overlay) -> {
						class_2586 blockEntity = new ReinforcedChestBlockEntity(material, class_2338.field_10980,
								block.method_9564().method_11657(ReinforcedChestBlock.field_10768, class_2350.field_11035));
						class_310.method_1551().method_31975().method_23077(blockEntity,
								matrices,
								vertexConsumers, light, overlay);
					});
		}
	}
}
