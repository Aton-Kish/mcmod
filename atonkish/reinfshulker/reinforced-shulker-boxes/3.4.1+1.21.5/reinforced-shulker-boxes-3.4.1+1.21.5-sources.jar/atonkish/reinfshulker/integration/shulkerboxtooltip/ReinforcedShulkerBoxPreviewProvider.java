package atonkish.reinfshulker.integration.shulkerboxtooltip;

import com.misterpemodder.shulkerboxtooltip.api.PreviewContext;
import com.misterpemodder.shulkerboxtooltip.api.color.ColorKey;
import com.misterpemodder.shulkerboxtooltip.api.provider.BlockEntityPreviewProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;

public class ReinforcedShulkerBoxPreviewProvider extends BlockEntityPreviewProvider {
    protected final int maxRowSize;
    private final ReinforcingMaterial material;

    public ReinforcedShulkerBoxPreviewProvider(ReinforcingMaterial material) {
        super(material.getSize(), true);

        int size = material.getSize();
        this.maxRowSize = size <= 81 ? 9 : size / 9;

        this.material = material;
    }

    @Override
    public boolean showTooltipHints(PreviewContext context) {
        return true;
    }

    @Override
    @Environment(EnvType.CLIENT)
    public ColorKey getWindowColorKey(PreviewContext context) {
        class_1767 dye = ((ReinforcedShulkerBoxBlock) class_2248.method_9503(context.stack().method_7909())).method_10528();

        if (dye == null)
            return ColorKey.SHULKER_BOX;
        return switch (dye) {
            case field_7946 -> ColorKey.ORANGE_SHULKER_BOX;
            case field_7958 -> ColorKey.MAGENTA_SHULKER_BOX;
            case field_7951 -> ColorKey.LIGHT_BLUE_SHULKER_BOX;
            case field_7947 -> ColorKey.YELLOW_SHULKER_BOX;
            case field_7961 -> ColorKey.LIME_SHULKER_BOX;
            case field_7954 -> ColorKey.PINK_SHULKER_BOX;
            case field_7944 -> ColorKey.GRAY_SHULKER_BOX;
            case field_7967 -> ColorKey.LIGHT_GRAY_SHULKER_BOX;
            case field_7955 -> ColorKey.CYAN_SHULKER_BOX;
            case field_7945 -> ColorKey.PURPLE_SHULKER_BOX;
            case field_7966 -> ColorKey.BLUE_SHULKER_BOX;
            case field_7957 -> ColorKey.BROWN_SHULKER_BOX;
            case field_7942 -> ColorKey.GREEN_SHULKER_BOX;
            case field_7964 -> ColorKey.RED_SHULKER_BOX;
            case field_7963 -> ColorKey.BLACK_SHULKER_BOX;
            default -> ColorKey.WHITE_SHULKER_BOX;
        };
    }

    @Override
    public int getMaxRowSize(PreviewContext context) {
        return this.maxRowSize;
    }

    public ReinforcingMaterial getMaterial() {
        return this.material;
    }
}
