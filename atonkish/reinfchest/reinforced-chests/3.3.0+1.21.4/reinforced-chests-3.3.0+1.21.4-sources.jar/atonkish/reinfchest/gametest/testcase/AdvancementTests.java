package atonkish.reinfchest.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_167;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_8779;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfchest.ReinforcedChestsMod;
import atonkish.reinfchest.gametest.util.MockServerPlayerHelper;
import atonkish.reinfchest.item.ModItems;

public class AdvancementTests {
    private static final String BATCH_ID = String.format("%s:AdvancementBatch",
            ReinforcedChestsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Chest
            add(AdvancementTests.createTest(
                    "Obtain Copper Chest recipe advancement by having Chest",
                    class_1802.field_8106,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/copper_chest")));
            add(AdvancementTests.createTest(
                    "Obtain Copper Chest recipe advancement by having Copper Ingot",
                    class_1802.field_27022,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/copper_chest")));

            // Iron Chest
            add(AdvancementTests.createTest(
                    "Obtain Iron Chest recipe advancement by having Copper Chest",
                    ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/iron_chest")));
            add(AdvancementTests.createTest(
                    "Obtain Iron Chest recipe advancement by having Iron Ingot",
                    class_1802.field_8620,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/iron_chest")));

            // Gold Chest
            add(AdvancementTests.createTest(
                    "Obtain Gold Chest recipe advancement by having Iron Chest",
                    ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/gold_chest")));
            add(AdvancementTests.createTest(
                    "Obtain Gold Chest recipe advancement by having Gold Ingot",
                    class_1802.field_8695,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/gold_chest")));

            // Diamond Chest
            add(AdvancementTests.createTest(
                    "Obtain Diamond Chest recipe advancement by having Gold Chest",
                    ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/diamond_chest")));
            add(AdvancementTests.createTest(
                    "Obtain Diamond Chest recipe advancement by having Diamond",
                    class_1802.field_8477,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/diamond_chest")));

            // Netherite Chest
            add(AdvancementTests.createTest(
                    "Obtain Netherite Chest recipe advancement by having Diamond Chest",
                    ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/netherite_chest_smithing")));
            add(AdvancementTests.createTest(
                    "Obtain Netherite Chest recipe advancement by having Netherite Ingot",
                    class_1802.field_22020,
                    class_2960.method_60655(ReinforcedChestsMod.MOD_ID, "recipes/decorations/netherite_chest_smithing")));
        }
    };

    private static class_4529 createTest(String name, class_1792 item, class_2960 advancementId) {
        String testName = String.format("%s %s %s",
                ReinforcedChestsMod.MOD_ID,
                AdvancementTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                AdvancementTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3222 player = MockServerPlayerHelper.spawn(context,
                            class_1934.field_9215, class_243.method_24954(class_2338.field_10980));
                    class_8779 entry = context.method_35943().method_8503().method_3851()
                            .method_12896(advancementId);
                    class_167 progress = player.method_14236().method_12882(entry);

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    Map<String, Boolean> progressMap = new HashMap<String, Boolean>();
                    String progressMapKeyBeforeHavingItem = "beforeHavingItem";
                    String progressMapKeyAfterHavingItem = "afterHavingItem";

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        progressMap.put(progressMapKeyBeforeHavingItem, progress.method_740());

                        player.method_7270(new class_1799(item));

                        futurePartialAct1.complete(null);
                    });

                    long tickObtained = 1;
                    context.method_35951(tickObtained, () -> {
                        progressMap.put(progressMapKeyAfterHavingItem, progress.method_740());

                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_49994(progressMap.get(progressMapKeyBeforeHavingItem), String.format(
                                    "Expected that advancement %s has not been done yet, but it has been already done.",
                                    entry));
                            context.method_46226(progressMap.get(progressMapKeyAfterHavingItem), String.format(
                                    "Expected that advancement %s has been done, but it has not been done yet.",
                                    entry));
                        } catch (Exception e) {
                            ReinforcedChestsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        } finally {
                            MockServerPlayerHelper.destroy(context, player);
                        }

                        context.method_36036();
                    });
                });
    }
}
