package atonkish.reinfchest.api;

import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.block.entity.ModBlockEntityType;
import atonkish.reinfchest.block.entity.ReinforcedChestBlockEntity;
import atonkish.reinfchest.item.ModItems;
import atonkish.reinfchest.stat.ModStats;

public class ReinforcedChestsRegistry {
    public static class_2960 registerMaterialOpenStat(String namespace, ReinforcingMaterial material) {
        return ModStats.registerMaterialOpen(namespace, material);
    }

    public static class_2248 registerMaterialBlock(String namespace, ReinforcingMaterial material, class_2248.Settings settings) {
        return ModBlocks.registerMaterial(namespace, material, settings);
    }

    public static class_2591<ReinforcedChestBlockEntity> registerMaterialBlockEntityType(
            String namespace, ReinforcingMaterial material) {
        return ModBlockEntityType.registerMaterial(namespace, material);
    }

    public static class_1792 registerMaterialItem(String namespace, ReinforcingMaterial material, class_1792.class_1793 settings) {
        return ModItems.registerMaterial(material, settings);
    }

    public static void registerMaterialItemGroupIcon(String namespace, ReinforcingMaterial material) {
        ModItems.registerMaterialItemGroupIcon(material);
    }
}
