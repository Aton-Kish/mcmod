package atonkish.reinfchest.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfchest.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedChestsClientRegistry {
    @Deprecated
    public static class_2960 registerMaterialAtlasTexture(String namespace, ReinforcingMaterial material) {
        return class_4722.field_21709;
    }

    @Deprecated
    public static class_1921 registerMaterialRenderLayer(String namespace, ReinforcingMaterial material) {
        return class_4722.method_24072();
    }

    public static class_4730 registerMaterialSingleSprite(String namespace, ReinforcingMaterial material) {
        return ModTexturedRenderLayers.registerMaterialSingleSprite(namespace, material);
    }

    public static class_4730 registerMaterialLeftSprite(String namespace, ReinforcingMaterial material) {
        return ModTexturedRenderLayers.registerMaterialLeftSprite(namespace, material);
    }

    public static class_4730 registerMaterialRightSprite(String namespace, ReinforcingMaterial material) {
        return ModTexturedRenderLayers.registerMaterialRightSprite(namespace, material);
    }
}
