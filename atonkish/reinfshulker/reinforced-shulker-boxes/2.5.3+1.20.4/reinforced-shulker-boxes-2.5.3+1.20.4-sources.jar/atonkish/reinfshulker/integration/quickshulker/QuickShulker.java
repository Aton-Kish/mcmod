package atonkish.reinfshulker.integration.quickshulker;

import java.util.function.BiConsumer;

import net.kyrptonaught.quickshulker.api.ItemStackInventory;
import net.kyrptonaught.quickshulker.api.QuickOpenableRegistry;
import net.kyrptonaught.quickshulker.api.RegisterQuickShulker;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_747;
import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.block.entity.ModBlockEntityType;

public class QuickShulker implements RegisterQuickShulker {
    private static BiConsumer<class_1657, class_1799> REINFORCED_SHULKER_BOX_CONSUMER;

    @Override
    public void registerProviders() {
        new QuickOpenableRegistry.Builder()
                .setItem(ReinforcedShulkerBoxBlock.class)
                // TODO: re-enable the bundling feature
                // if https://github.com/kyrptonaught/shulkerutils/pull/1 is merged.
                .supportsBundleing(false)
                .setOpenAction(REINFORCED_SHULKER_BOX_CONSUMER)
                .register();
    }

    static {
        REINFORCED_SHULKER_BOX_CONSUMER = (class_1657 player, class_1799 stack) -> {
            ReinforcedShulkerBoxBlock block = (ReinforcedShulkerBoxBlock) ((class_1747) stack.method_7909()).method_7711();
            ReinforcingMaterial material = block.getMaterial();
            ItemStackInventory inventory = new ItemStackInventory(stack, material.getSize());
            String namespace = class_2591.method_11033(ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(material))
                    .method_12836();

            class_1270 screenHandlerFactory = (int syncId, class_1661 playerInventory,
                    class_1657 playerEntity) -> ReinforcedStorageScreenHandler.createShulkerBoxScreen(material,
                            syncId, playerInventory, inventory);
            class_2561 text = stack.method_7938() ? stack.method_7964()
                    : class_2561.method_43471("container." + namespace + "." + material.getName() + "ShulkerBox");

            player.method_17355(new class_747(screenHandlerFactory, text));
        };
    }
}
