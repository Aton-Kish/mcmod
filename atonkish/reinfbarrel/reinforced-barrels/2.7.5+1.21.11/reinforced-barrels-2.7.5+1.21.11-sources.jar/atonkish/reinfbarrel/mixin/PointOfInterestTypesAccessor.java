package atonkish.reinfbarrel.mixin;

import java.util.Map;
import net.minecraft.class_2680;
import net.minecraft.class_4158;
import net.minecraft.class_6880;
import net.minecraft.class_7477;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7477.class)
public interface PointOfInterestTypesAccessor {
  @Accessor("POI_STATES_TO_TYPE")
  static Map<class_2680, class_6880<class_4158>> getPointOfInterestStatesToType() {
    throw new UnsupportedOperationException();
  }
}
