package atonkish.reinfchest.block.entity;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.mixin.BlockEntityTypeAccessor;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedChestBlockEntity>> REINFORCED_CHEST_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedChestBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_CHEST_MAP.containsKey(material)) {
            String id = material.getName() + "_chest";
            class_2248 block = ModBlocks.REINFORCED_CHEST_MAP.get(material);
            class_2591.class_2592<ReinforcedChestBlockEntity> builder = class_2591.class_2592.method_20528(
                    ModBlockEntityType.createBlockEntityTypeFactory(material), block);
            class_2591<ReinforcedChestBlockEntity> blockEntityType = ModBlockEntityType.create(
                    namespace, id, builder);
            REINFORCED_CHEST_MAP.put(material, blockEntityType);

            ((BlockEntityTypeAccessor) class_2591.field_11914).getBlocks().add(block);
        }

        return REINFORCED_CHEST_MAP.get(material);
    }

    private static class_2591<ReinforcedChestBlockEntity> create(String namespace, String id,
            class_2591.class_2592<ReinforcedChestBlockEntity> builder) {
        return class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(namespace, id), builder.method_11034(null));
    }

    private static class_2591.class_5559<ReinforcedChestBlockEntity> createBlockEntityTypeFactory(
            ReinforcingMaterial material) {
        return (class_2338 blockPos, class_2680 blockState) -> new ReinforcedChestBlockEntity(material, blockPos,
                blockState);
    }
}
