package atonkish.reinfbarrel.block.entity;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.mixin.BlockEntityTypeAccessor;
import atonkish.reinfbarrel.mixin.BlockEntityTypeInvoker;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedBarrelBlockEntity>> REINFORCED_BARREL_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedBarrelBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_BARREL_MAP.containsKey(material)) {
            String id = material.getName() + "_barrel";
            class_2248 block = ModBlocks.REINFORCED_BARREL_MAP.get(material);
            class_2591<ReinforcedBarrelBlockEntity> blockEntityType = BlockEntityTypeInvoker.create(
                    class_2960.method_60655(namespace, id).toString(),
                    (blockPos, blockState) -> new ReinforcedBarrelBlockEntity(material, blockPos, blockState),
                    block);
            REINFORCED_BARREL_MAP.put(material, blockEntityType);

            ((BlockEntityTypeAccessor) class_2591.field_16411).getBlocks().add(block);
        }

        return REINFORCED_BARREL_MAP.get(material);
    }
}
