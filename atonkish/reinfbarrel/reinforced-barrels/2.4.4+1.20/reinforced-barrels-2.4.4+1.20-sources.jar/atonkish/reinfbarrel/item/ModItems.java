package atonkish.reinfbarrel.item;

import java.util.LinkedHashMap;
import java.util.Map;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import atonkish.reinfcore.item.ModItemGroup;
import atonkish.reinfcore.item.ModItemGroups;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfbarrel.block.ModBlocks;

public class ModItems {
    public static final Map<ReinforcingMaterial, class_1792> REINFORCED_BARREL_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, class_1792.class_1793> REINFORCED_BARREL_SETTINGS_MAP = new LinkedHashMap<>();

    public static class_1792 registerMaterial(ReinforcingMaterial material, class_1792.class_1793 settings) {
        if (!REINFORCED_BARREL_SETTINGS_MAP.containsKey(material)) {
            REINFORCED_BARREL_SETTINGS_MAP.put(material, settings);
        }

        if (!REINFORCED_BARREL_MAP.containsKey(material)) {
            class_1792 item = ModItems.register(
                    new class_1747(ModBlocks.REINFORCED_BARREL_MAP.get(material),
                            REINFORCED_BARREL_SETTINGS_MAP.get(material)));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(ModItemGroups.REINFORCED_STORAGE).register(content -> content.method_45421(item));
            REINFORCED_BARREL_MAP.put(material, item);
        }

        return REINFORCED_BARREL_MAP.get(material);
    }

    public static void registerMaterialItemGroupIcon(ReinforcingMaterial material) {
        class_1792 item = REINFORCED_BARREL_MAP.get(material);
        ModItemGroup.setIcon(class_7923.field_44687.method_29107(ModItemGroups.REINFORCED_STORAGE), item);
    }

    private static class_1792 register(class_1747 item) {
        return ModItems.register(item.method_7711(), (class_1792) item);
    }

    protected static class_1792 register(class_2248 block, class_1792 item) {
        return ModItems.register(class_7923.field_41175.method_10221(block), item);
    }

    private static class_1792 register(class_2960 id, class_1792 item) {
        if (item instanceof class_1747) {
            ((class_1747) item).method_7713(class_1792.field_8003, item);
        }

        return class_2378.method_10230(class_7923.field_41178, id, item);
    }
}
