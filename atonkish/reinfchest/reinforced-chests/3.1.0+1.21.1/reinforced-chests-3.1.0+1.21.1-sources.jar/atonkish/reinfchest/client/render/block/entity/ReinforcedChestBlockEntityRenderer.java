
package atonkish.reinfchest.client.render.block.entity;

import it.unimi.dsi.fastutil.ints.Int2IntFunction;

import java.util.Calendar;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_4732;
import net.minecraft.class_4737;
import net.minecraft.class_4739;
import net.minecraft.class_5602;
import net.minecraft.class_5607;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_826;
import net.minecraft.class_827;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfchest.block.entity.ReinforcedChestBlockEntity;
import atonkish.reinfchest.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedChestBlockEntityRenderer<T extends class_2586> implements class_827<T> {
    private static final String BASE = "bottom";
    private static final String LID = "lid";
    private static final String LATCH = "lock";
    private final class_630 singleChestLid;
    private final class_630 singleChestBase;
    private final class_630 singleChestLatch;
    private final class_630 doubleChestRightLid;
    private final class_630 doubleChestRightBase;
    private final class_630 doubleChestRightLatch;
    private final class_630 doubleChestLeftLid;
    private final class_630 doubleChestLeftBase;
    private final class_630 doubleChestLeftLatch;
    private boolean christmas;

    public ReinforcedChestBlockEntityRenderer(class_5614.class_5615 ctx) {
        Calendar calendar = Calendar.getInstance();
        if (calendar.get(2) + 1 == 12 && calendar.get(5) >= 24 && calendar.get(5) <= 26) {
            this.christmas = true;
        }

        class_630 modelPart = ctx.method_32140(class_5602.field_27689);
        this.singleChestBase = modelPart.method_32086(BASE);
        this.singleChestLid = modelPart.method_32086(LID);
        this.singleChestLatch = modelPart.method_32086(LATCH);
        class_630 modelPart2 = ctx.method_32140(class_5602.field_27551);
        this.doubleChestLeftBase = modelPart2.method_32086(BASE);
        this.doubleChestLeftLid = modelPart2.method_32086(LID);
        this.doubleChestLeftLatch = modelPart2.method_32086(LATCH);
        class_630 modelPart3 = ctx.method_32140(class_5602.field_27552);
        this.doubleChestRightBase = modelPart3.method_32086(BASE);
        this.doubleChestRightLid = modelPart3.method_32086(LID);
        this.doubleChestRightLatch = modelPart3.method_32086(LATCH);
    }

    public static class_5607 getSingleTexturedModelData() {
        return class_826.method_32147();
    }

    public static class_5607 getRightDoubleTexturedModelData() {
        return class_826.method_32148();
    }

    public static class_5607 getLeftDoubleTexturedModelData() {
        return class_826.method_32149();
    }

    @Override
    public void method_3569(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers,
            int light, int overlay) {
        class_1937 world = ((class_2586) entity).method_10997();
        boolean bl = world != null;
        class_2680 blockState = bl
                ? ((class_2586) entity).method_11010()
                : (class_2680) class_2246.field_10034.method_9564().method_11657(class_2281.field_10768, class_2350.field_11035);
        class_2745 chestType = blockState.method_28498(class_2281.field_10770)
                ? blockState.method_11654(class_2281.field_10770)
                : class_2745.field_12569;
        class_2248 block = blockState.method_26204();
        if (!(block instanceof class_4739)) {
            return;
        }
        ReinforcingMaterial material = ((ReinforcedChestBlockEntity) entity).getMaterial();
        class_4739<?> abstractChestBlock = (class_4739<?>) block;
        boolean bl2 = chestType != class_2745.field_12569;
        matrices.method_22903();
        float f = blockState.method_11654(class_2281.field_10768).method_10144();
        matrices.method_46416(0.5f, 0.5f, 0.5f);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-f));
        matrices.method_46416(-0.5f, -0.5f, -0.5f);
        class_4732.class_4734<? extends class_2595> propertySource = bl
                ? abstractChestBlock.method_24167(blockState, world, ((class_2586) entity).method_11016(), true)
                : class_4732.class_3923::method_24174;
        float g = propertySource.apply(class_2281.method_24166((class_2618) entity)).get(tickDelta);
        g = 1.0f - g;
        g = 1.0f - g * g * g;
        int i = ((Int2IntFunction) propertySource.apply(new class_4737<>())).applyAsInt(light);
        class_4730 spriteIdentifier = ModTexturedRenderLayers.getReinforcedChestTexture(material, entity,
                chestType, this.christmas);
        class_4588 vertexConsumer = spriteIdentifier.method_24145(vertexConsumers,
                class_1921::method_23576);
        if (bl2) {
            if (chestType == class_2745.field_12574) {
                this.render(matrices, vertexConsumer, this.doubleChestLeftLid, this.doubleChestLeftLatch,
                        this.doubleChestLeftBase, g, i, overlay);
            } else {
                this.render(matrices, vertexConsumer, this.doubleChestRightLid, this.doubleChestRightLatch,
                        this.doubleChestRightBase, g, i, overlay);
            }
        } else {
            this.render(matrices, vertexConsumer, this.singleChestLid, this.singleChestLatch, this.singleChestBase, g,
                    i, overlay);
        }
        matrices.method_22909();
    }

    private void render(class_4587 matrices, class_4588 vertices, class_630 lid, class_630 latch, class_630 base,
            float openFactor, int light, int overlay) {
        latch.field_3654 = lid.field_3654 = -(openFactor * 1.5707964f);
        lid.method_22698(matrices, vertices, light, overlay);
        latch.method_22698(matrices, vertices, light, overlay);
        base.method_22698(matrices, vertices, light, overlay);
    }
}
