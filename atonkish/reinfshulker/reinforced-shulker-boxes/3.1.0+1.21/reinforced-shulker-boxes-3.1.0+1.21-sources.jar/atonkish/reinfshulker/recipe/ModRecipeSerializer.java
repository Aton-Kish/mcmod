package atonkish.reinfshulker.recipe;

import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModRecipeSerializer {
    public static final class_1865<ReinforcedShulkerBoxCraftingRecipe> REINFORCED_SHULKER_BOX;
    public static final class_1866<ReinforcedShulkerBoxColoringRecipe> REINFORCED_SHULKER_BOX_COLORING;

    public static void init() {
    }

    private static <S extends class_1865<T>, T extends class_1860<?>> S register(String id, S serializer) {
        class_2960 identifier = class_2960.method_60655(ReinforcedShulkerBoxesMod.MOD_ID, id);
        return class_2378.method_10230(class_7923.field_41189, identifier, serializer);
    }

    static {
        REINFORCED_SHULKER_BOX = register("crafting_special_reinforcedshulkerbox",
                new ReinforcedShulkerBoxCraftingRecipe.Serializer());
        REINFORCED_SHULKER_BOX_COLORING = register("crafting_special_reinforcedshulkerboxcoloring",
                new class_1866<>(ReinforcedShulkerBoxColoringRecipe::new));
    }
}
