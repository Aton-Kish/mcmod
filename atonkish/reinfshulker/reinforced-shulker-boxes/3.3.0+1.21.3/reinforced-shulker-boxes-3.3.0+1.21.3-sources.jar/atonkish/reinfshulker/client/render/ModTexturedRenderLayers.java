package atonkish.reinfshulker.client.render;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1767;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import atonkish.reinfcore.util.ReinforcingMaterial;

@Environment(EnvType.CLIENT)
public class ModTexturedRenderLayers {
    public static final Map<ReinforcingMaterial, class_4730> REINFORCED_SHULKER_TEXTURE_ID_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, List<class_4730>> COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP = new LinkedHashMap<>();

    public static class_4730 registerMaterialDefaultSprite(String namespace, ReinforcingMaterial material) {
        if (!REINFORCED_SHULKER_TEXTURE_ID_MAP.containsKey(material)) {
            class_4730 identifier = new class_4730(class_4722.field_21704,
                    class_2960.method_60655(namespace, "entity/reinforced_shulker/" + material.getName() + "/shulker"));
            REINFORCED_SHULKER_TEXTURE_ID_MAP.put(material, identifier);
        }

        return REINFORCED_SHULKER_TEXTURE_ID_MAP.get(material);
    }

    public static List<class_4730> registerMaterialColoringSprites(String namespace,
            ReinforcingMaterial material) {
        if (!COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.containsKey(material)) {
            List<class_4730> identifiers = Stream.of(class_1767.values()).map((color) -> {
                return new class_4730(class_4722.field_21704,
                        class_2960.method_60655(namespace,
                                "entity/reinforced_shulker/" + material.getName() + "/shulker_" + color.method_7792()));
            }).collect(ImmutableList.toImmutableList());
            COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.put(material, identifiers);
        }

        return COLORED_REINFORCED_SHULKER_BOXES_TEXTURES_MAP.get(material);
    }
}
