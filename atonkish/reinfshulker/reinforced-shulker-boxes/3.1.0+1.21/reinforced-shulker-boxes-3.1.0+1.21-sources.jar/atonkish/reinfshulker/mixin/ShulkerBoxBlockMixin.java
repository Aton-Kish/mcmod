package atonkish.reinfshulker.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_2627;
import net.minecraft.class_2680;

@Mixin(class_2480.class)
public class ShulkerBoxBlockMixin {
    @Inject(method = "onBreak", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;applyComponentsFrom(Lnet/minecraft/component/ComponentMap;)V"), locals = LocalCapture.CAPTURE_FAILHARD)
    public void onBreak(class_1937 world, class_2338 pos, class_2680 state, class_1657 player,
            CallbackInfoReturnable<class_2680> cir, class_2586 blockEntity,
            class_2627 shulkerBoxBlockEntity, class_1799 itemStack) {
        if (blockEntity instanceof ReinforcedShulkerBoxBlockEntity) {
            ReinforcedShulkerBoxBlockEntity entity = (ReinforcedShulkerBoxBlockEntity) blockEntity;
            ((ItemStackAccessor) (Object) itemStack)
                    .setItem(ReinforcedShulkerBoxBlock.get(entity.getMaterial(), entity.method_11320()).method_8389());
        }
    }
}
