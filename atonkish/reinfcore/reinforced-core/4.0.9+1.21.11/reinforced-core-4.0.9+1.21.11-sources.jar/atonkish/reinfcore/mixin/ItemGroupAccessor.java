package atonkish.reinfcore.mixin;

import net.minecraft.class_1761;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1761.class)
public interface ItemGroupAccessor {
  @Mutable
  @Accessor("icon")
  public void setIcon(class_1799 itemStack);
}
