package atonkish.reinfshulker.mixin;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2586.class)
public interface BlockEntityAccessor {
  @Mutable
  @Accessor("type")
  public void setType(class_2591<?> type);
}
