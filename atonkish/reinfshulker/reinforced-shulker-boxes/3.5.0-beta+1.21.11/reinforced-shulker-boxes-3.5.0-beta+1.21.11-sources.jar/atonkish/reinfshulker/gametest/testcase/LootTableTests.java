package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2846;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.gametest.util.MockServerPlayerHelper;
import atonkish.reinfshulker.gametest.util.TestIdentifier;

public class LootTableTests {
  private static final String TEST_ENVIRONMENT_DEFAULT =
      String.format("%s:loot_table/default", ReinforcedShulkerBoxesMod.MOD_ID);
  private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

  public static final Collection<TestFunction> TEST_FUNCTIONS =
      new ArrayList<>() {
        {
          // Copper Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("copper"))
                  .values()) {
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                    block,
                    class_1802.field_22024,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                    block,
                    class_1802.field_22025,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s without tools", block.method_9518().getString()),
                    block,
                    class_1802.field_8162,
                    true));
          }

          // Iron Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("iron"))
                  .values()) {
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                    block,
                    class_1802.field_22024,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                    block,
                    class_1802.field_22025,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s without tools", block.method_9518().getString()),
                    block,
                    class_1802.field_8162,
                    true));
          }

          // Gold Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("gold"))
                  .values()) {
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                    block,
                    class_1802.field_22024,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                    block,
                    class_1802.field_22025,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s without tools", block.method_9518().getString()),
                    block,
                    class_1802.field_8162,
                    true));
          }

          // Diamond Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("diamond"))
                  .values()) {
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                    block,
                    class_1802.field_22024,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                    block,
                    class_1802.field_22025,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s without tools", block.method_9518().getString()),
                    block,
                    class_1802.field_8162,
                    true));
          }

          // Netherite Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("netherite"))
                  .values()) {
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                    block,
                    class_1802.field_22024,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                    block,
                    class_1802.field_22025,
                    true));
            add(
                LootTableTests.createTest(
                    String.format("Break %s without tools", block.method_9518().getString()),
                    block,
                    class_1802.field_8162,
                    true));
          }
        }
      };

  private static TestFunction createTest(
      String name, class_2248 shulkerBoxBlock, class_1792 tool, boolean shouldDrop) {
    class_2960 testIdentifier =
        TestIdentifier.of(ReinforcedShulkerBoxesMod.MOD_ID, LootTableTests.class, name);

    return new TestFunction(
        testIdentifier,
        LootTableTests.TEST_ENVIRONMENT_DEFAULT,
        LootTableTests.TEST_STRUCTURE_EMPTY,
        100,
        0,
        true,
        class_2470.field_11467,
        false,
        1,
        1,
        false,
        (context) -> {
          // Arrange
          class_2338 blockPos = class_2338.field_10980;
          context.method_35984(blockPos, shulkerBoxBlock);

          class_3222 player =
              MockServerPlayerHelper.spawn(context, class_1934.field_9215, class_243.method_24954(blockPos.method_10077(4)));
          player.method_6122(class_1268.field_5808, new class_1799(tool));

          // Act
          CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
          CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

          long tickOrigin = 0;
          context.method_35951(
              tickOrigin,
              () -> {
                player.field_13974.method_14263(
                    context.method_36052(blockPos),
                    class_2846.class_2847.field_12968,
                    class_2350.field_11043,
                    context.method_35943().method_31605(),
                    0);

                futurePartialAct1.complete(null);
              });

          long tickBlockBreaking =
              (long)
                  Math.ceil(
                      1.0D
                          / context
                              .method_35980(blockPos)
                              .method_26165(player, context.method_35943(), blockPos));
          context.method_35951(
              tickBlockBreaking,
              () -> {
                player.field_13974.method_14263(
                    context.method_36052(blockPos),
                    class_2846.class_2847.field_12973,
                    class_2350.field_11043,
                    context.method_35943().method_31605(),
                    0);

                futurePartialAct2.complete(null);
              });

          ReinforcedShulkerBoxesMod.LOGGER.info(
              "[{}] {} can be mined in {} ticks by {}",
              testIdentifier,
              shulkerBoxBlock.method_9518().getString(),
              tickBlockBreaking,
              tool.method_63680().getString());

          // Assert
          CompletableFuture.allOf(futurePartialAct1, futurePartialAct2)
              .thenRun(
                  () -> {
                    try {
                      context.method_35972(class_2246.field_10124, blockPos);
                      context.method_35970(
                          shulkerBoxBlock.method_8389(), blockPos, 1, shouldDrop ? 1 : 0);
                    } catch (Exception e) {
                      ReinforcedShulkerBoxesMod.LOGGER.error(
                          "[{}] {}", testIdentifier, e.getMessage());
                      throw e;
                    } finally {
                      MockServerPlayerHelper.destroy(context, player);
                    }

                    context.method_36036();
                  });
        });
  }
}
