package atonkish.reinfcore.util;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1792;

public class ReinforcingMaterials {
    public static final Map<String, ReinforcingMaterial> MAP = new LinkedHashMap<>();

    public static ReinforcingMaterial register(String name, int size, class_1792 ingredient) {
        if (!MAP.containsKey(name)) {
            ReinforcingMaterial material = new ReinforcingMaterial(name, size, ingredient);
            MAP.put(name, material);
        }

        return MAP.get(name);
    }
}
