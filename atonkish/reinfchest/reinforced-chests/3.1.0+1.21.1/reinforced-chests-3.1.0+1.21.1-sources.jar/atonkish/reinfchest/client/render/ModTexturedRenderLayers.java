package atonkish.reinfchest.client.render;

import java.util.LinkedHashMap;
import java.util.Map;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2586;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import atonkish.reinfcore.util.ReinforcingMaterial;

@Environment(EnvType.CLIENT)
public class ModTexturedRenderLayers {
    public static final Map<ReinforcingMaterial, class_4730> REINFORCED_CHEST_SINGLE_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, class_4730> REINFORCED_CHEST_LEFT_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, class_4730> REINFORCED_CHEST_RIGHT_MAP = new LinkedHashMap<>();

    public static class_4730 registerMaterialSingleSprite(String namespace, ReinforcingMaterial material) {
        if (!REINFORCED_CHEST_SINGLE_MAP.containsKey(material)) {
            class_4730 identifier = getReinforcedChestTextureId(namespace, material, "single");
            REINFORCED_CHEST_SINGLE_MAP.put(material, identifier);
        }

        return REINFORCED_CHEST_SINGLE_MAP.get(material);
    }

    public static class_4730 registerMaterialLeftSprite(String namespace, ReinforcingMaterial material) {
        if (!REINFORCED_CHEST_LEFT_MAP.containsKey(material)) {
            class_4730 identifier = getReinforcedChestTextureId(namespace, material, "left");
            REINFORCED_CHEST_LEFT_MAP.put(material, identifier);
        }

        return REINFORCED_CHEST_LEFT_MAP.get(material);
    }

    public static class_4730 registerMaterialRightSprite(String namespace, ReinforcingMaterial material) {
        if (!REINFORCED_CHEST_RIGHT_MAP.containsKey(material)) {
            class_4730 identifier = getReinforcedChestTextureId(namespace, material, "right");
            REINFORCED_CHEST_RIGHT_MAP.put(material, identifier);
        }

        return REINFORCED_CHEST_RIGHT_MAP.get(material);
    }

    private static class_4730 getReinforcedChestTextureId(String namespace, ReinforcingMaterial material,
            String variant) {
        class_2960 textureId = class_2960.method_60655(namespace,
                "entity/reinforced_chest/" + material.getName() + "/" + variant);
        return new class_4730(class_4722.field_21709, textureId);
    }

    public static class_4730 getReinforcedChestTexture(ReinforcingMaterial material, class_2586 blockEntity,
            class_2745 type, boolean christmas) {
        if (christmas) {
            return getReinforcedChestTexture(type, class_4722.field_21717, class_4722.field_21718,
                    class_4722.field_21719);
        } else {
            class_4730 single = REINFORCED_CHEST_SINGLE_MAP.get(material);
            class_4730 left = REINFORCED_CHEST_LEFT_MAP.get(material);
            class_4730 right = REINFORCED_CHEST_RIGHT_MAP.get(material);
            return getReinforcedChestTexture(type, single, left, right);
        }
    }

    private static class_4730 getReinforcedChestTexture(class_2745 type, class_4730 single,
            class_4730 left, class_4730 right) {
        switch (type) {
            case field_12574:
                return left;
            case field_12571:
                return right;
            case field_12569:
            default:
                return single;
        }
    }
}
