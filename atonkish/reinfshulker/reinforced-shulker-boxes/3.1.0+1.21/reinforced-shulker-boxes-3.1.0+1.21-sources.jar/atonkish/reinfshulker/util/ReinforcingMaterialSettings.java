package atonkish.reinfshulker.util;

import atonkish.reinfcore.api.ReinforcedCoreRegistry;
import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2627;
import net.minecraft.class_2766;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;

public enum ReinforcingMaterialSettings {
    COPPER(ReinforcedCoreRegistry.registerReinforcingMaterial("copper", 45, class_1802.field_27022),
            class_4970.class_2251
                    .method_9637()
                    .method_9629(2.0F, 6.0F)
                    .method_9626(class_2498.field_27204),
            new class_1792.class_1793()),
    IRON(ReinforcedCoreRegistry.registerReinforcingMaterial("iron", 54, class_1802.field_8620),
            class_4970.class_2251
                    .method_9637()
                    .method_51368(class_2766.field_18284)
                    .method_9629(2.0F, 6.0F)
                    .method_9626(class_2498.field_11533),
            new class_1792.class_1793()),
    GOLD(ReinforcedCoreRegistry.registerReinforcingMaterial("gold", 81, class_1802.field_8695),
            class_4970.class_2251
                    .method_9637()
                    .method_51368(class_2766.field_12644)
                    .method_9629(2.0F, 6.0F)
                    .method_9626(class_2498.field_11533),
            new class_1792.class_1793()),
    DIAMOND(ReinforcedCoreRegistry.registerReinforcingMaterial("diamond", 108, class_1802.field_8477),
            class_4970.class_2251
                    .method_9637()
                    .method_9629(2.0F, 6.0F)
                    .method_9626(class_2498.field_11533),
            new class_1792.class_1793()),
    NETHERITE(ReinforcedCoreRegistry.registerReinforcingMaterial("netherite", 108, class_1802.field_22020),
            class_4970.class_2251
                    .method_9637()
                    .method_9629(2.0F, 1200.0F)
                    .method_9626(class_2498.field_22150),
            new class_1792.class_1793().method_24359());

    private final ReinforcingMaterial material;
    private final class_2248.Settings blockSettings;
    private final class_1792.class_1793 itemSettings;

    private ReinforcingMaterialSettings(ReinforcingMaterial material, class_2248.Settings blockSettings,
            class_1792.class_1793 itemSettings) {
        class_4970.class_4973 contextPredicate = (state, world, pos) -> {
            class_2586 blockEntity = world.method_8321(pos);
            if (!(blockEntity instanceof class_2627)) {
                return true;
            }
            class_2627 shulkerBoxBlockEntity = (class_2627) blockEntity;
            return shulkerBoxBlockEntity.method_27093();
        };

        this.material = material;
        this.blockSettings = blockSettings.method_51369().method_9624().method_22488()
                .method_26243(contextPredicate).method_26245(contextPredicate)
                .method_50012(class_3619.field_15971).method_26236(class_2246::method_26113);
        this.itemSettings = itemSettings.method_7889(1);
    }

    public ReinforcingMaterial getMaterial() {
        return this.material;
    }

    public class_2248.Settings getBlockSettings() {
        return this.blockSettings.method_31710(class_3620.field_16014);
    }

    public class_2248.Settings getColorBlockSettings(class_1767 color) {
        class_3620 mapColor = switch (color) {
            case field_7945 -> class_3620.field_16029;
            default -> color.method_7794();
        };

        return this.blockSettings.method_31710(mapColor);
    }

    public class_1792.class_1793 getItemSettings() {
        return this.itemSettings;
    }
}
