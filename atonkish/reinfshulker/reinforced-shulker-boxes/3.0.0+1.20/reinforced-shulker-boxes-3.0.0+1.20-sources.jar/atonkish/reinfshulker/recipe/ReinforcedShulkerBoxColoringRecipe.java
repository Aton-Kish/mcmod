package atonkish.reinfshulker.recipe;

import org.jetbrains.annotations.Nullable;

import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

public class ReinforcedShulkerBoxColoringRecipe extends class_1852 {
    public ReinforcedShulkerBoxColoringRecipe(class_7710 craftingRecipeCategory) {
        super(craftingRecipeCategory);
    }

    @Override
    public boolean matches(class_8566 recipeInputInventory, class_1937 world) {
        int i = 0;
        int j = 0;

        for (int k = 0; k < recipeInputInventory.method_5439(); ++k) {
            class_1799 itemStack = recipeInputInventory.method_5438(k);
            if (itemStack.method_7960()) {
                continue;
            }

            if (class_2248.method_9503(itemStack.method_7909()) instanceof ReinforcedShulkerBoxBlock) {
                ++i;
            } else if (itemStack.method_7909() instanceof class_1769) {
                ++j;
            } else {
                return false;
            }

            if (j <= 1 && i <= 1) {
                continue;
            }

            return false;
        }

        return i == 1 && j == 1;
    }

    @Override
    public class_1799 craft(class_8566 recipeInputInventory, class_7225.class_7874 wrapperLookup) {
        class_1799 itemStack = class_1799.field_8037;
        class_1769 dyeItem = (class_1769) class_1802.field_8446;

        @Nullable
        ReinforcingMaterial material = null;

        for (int i = 0; i < recipeInputInventory.method_5439(); ++i) {
            class_1799 itemStack2 = recipeInputInventory.method_5438(i);
            if (itemStack2.method_7960()) {
                continue;
            }

            class_1792 item = itemStack2.method_7909();
            class_2248 block = class_2248.method_9503(item);
            if (block instanceof ReinforcedShulkerBoxBlock) {
                itemStack = itemStack2;
                material = ((ReinforcedShulkerBoxBlock) block).getMaterial();
                continue;
            }

            if (!(item instanceof class_1769)) {
                continue;
            }

            dyeItem = (class_1769) item;
        }

        class_2248 block = ReinforcedShulkerBoxBlock.get(material, dyeItem.method_7802());
        return itemStack.method_56701(block, 1);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializer.REINFORCED_SHULKER_BOX_COLORING;
    }
}
