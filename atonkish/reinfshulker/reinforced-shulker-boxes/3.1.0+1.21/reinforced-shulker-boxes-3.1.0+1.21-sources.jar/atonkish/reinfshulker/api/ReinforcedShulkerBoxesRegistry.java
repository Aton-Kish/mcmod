package atonkish.reinfshulker.api;

import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.block.entity.ModBlockEntityType;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.item.ModItems;
import atonkish.reinfshulker.stat.ModStats;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;

public class ReinforcedShulkerBoxesRegistry {
    public static class_2960 registerMaterialCleanStat(String namespace, ReinforcingMaterial material) {
        return ModStats.registerMaterialClean(namespace, material);
    }

    public static class_2960 registerMaterialOpenStat(String namespace, ReinforcingMaterial material) {
        return ModStats.registerMaterialOpen(namespace, material);
    }

    public static class_2248 registerMaterialDyeColorBlock(String namespace, ReinforcingMaterial material, class_1767 color,
            class_2248.Settings settings) {
        return ModBlocks.registerMaterialDyeColor(namespace, material, color, settings);
    }

    public static class_2591<ReinforcedShulkerBoxBlockEntity> registerMaterialBlockEntityType(String namespace,
            ReinforcingMaterial material) {
        return ModBlockEntityType.registerMaterial(namespace, material);
    }

    public static class_1792 registerMaterialDyeColorItem(String namespace, ReinforcingMaterial material, class_1767 color,
            class_1792.class_1793 settings) {
        return ModItems.registerMaterialDyeColor(material, color, settings);
    }

    public static void registerMaterialDyeColorItemGroupIcon(String namespace, ReinforcingMaterial material,
            class_1767 color) {
        ModItems.registerMaterialDyeColorItemGroupIcon(material, color);
    }
}
