package atonkish.reinfshulker.block;

import org.jetbrains.annotations.Nullable;

import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.entity.ModBlockEntityType;
import atonkish.reinfshulker.block.entity.ReinforcedShulkerBoxBlockEntity;
import atonkish.reinfshulker.stat.ModStats;
import net.minecraft.class_1269;
import net.minecraft.class_1606;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4838;
import net.minecraft.class_4970;
import net.minecraft.class_5558;

public class ReinforcedShulkerBoxBlock extends class_2480 {
  private final ReinforcingMaterial material;

  public ReinforcedShulkerBoxBlock(
      ReinforcingMaterial material, @Nullable class_1767 color, class_4970.class_2251 settings) {
    super(color, settings);
    this.material = material;
  }

  @Override
  public class_2586 method_10123(class_2338 pos, class_2680 state) {
    return new ReinforcedShulkerBoxBlockEntity(this.material, this.method_10528(), pos, state);
  }

  @Override
  @Nullable public <T extends class_2586> class_5558<T> method_31645(
      class_1937 world, class_2680 state, class_2591<T> type) {
    return ReinforcedShulkerBoxBlock.method_31618(
        type,
        ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(this.material),
        ReinforcedShulkerBoxBlockEntity::method_31694);
  }

  @Override
  public class_1269 method_55766(
      class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
    if (world instanceof class_3218 serverWorld) {
      class_2586 blockEntity = world.method_8321(pos);
      if (blockEntity instanceof class_2627 shulkerBoxBlockEntity) {
        if (method_33383(state, world, pos, shulkerBoxBlockEntity)) {
          player.method_17355(shulkerBoxBlockEntity);
          player.method_7281(ModStats.OPEN_REINFORCED_SHULKER_BOX_MAP.get(this.material));
          class_4838.method_24733(serverWorld, player, true);
        }
      }
    }

    return class_1269.field_5812;
  }

  private static boolean method_33383(
      class_2680 state, class_1937 world, class_2338 pos, class_2627 entity) {
    if (entity.method_11313() != class_2627.class_2628.field_12065) {
      return true;
    } else {
      class_238 box =
          class_1606.method_33347(
                  1.0F, (class_2350) state.method_11654(field_11496), 0.0F, 0.5F, pos.method_61082())
              .method_1011(1.0E-6D);
      return world.method_18026(box);
    }
  }

  public static class_2248 get(ReinforcingMaterial material, @Nullable class_1767 color) {
    return ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
  }

  public ReinforcingMaterial getMaterial() {
    return this.material;
  }

  public static class_1799 getItemStack(ReinforcingMaterial material, @Nullable class_1767 color) {
    return new class_1799(get(material, color));
  }
}
