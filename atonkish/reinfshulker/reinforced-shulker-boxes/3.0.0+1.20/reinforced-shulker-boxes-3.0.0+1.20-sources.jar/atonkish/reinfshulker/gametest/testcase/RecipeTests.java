package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1715;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_5455;
import net.minecraft.class_8566;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.gametest.util.VoidScreenHander;
import atonkish.reinfshulker.item.ModItems;

public class RecipeTests {
    private static final Map<class_1767, class_1792> SHULKER_BOX_MAP = new LinkedHashMap<>() {
        {
            put((class_1767) null, class_1802.field_8545);
            put(class_1767.field_7952, class_1802.field_8722);
            put(class_1767.field_7946, class_1802.field_8380);
            put(class_1767.field_7958, class_1802.field_8050);
            put(class_1767.field_7951, class_1802.field_8829);
            put(class_1767.field_7947, class_1802.field_8271);
            put(class_1767.field_7961, class_1802.field_8548);
            put(class_1767.field_7954, class_1802.field_8520);
            put(class_1767.field_7944, class_1802.field_8627);
            put(class_1767.field_7967, class_1802.field_8451);
            put(class_1767.field_7955, class_1802.field_8213);
            put(class_1767.field_7945, class_1802.field_8816);
            put(class_1767.field_7966, class_1802.field_8350);
            put(class_1767.field_7957, class_1802.field_8584);
            put(class_1767.field_7942, class_1802.field_8461);
            put(class_1767.field_7964, class_1802.field_8676);
            put(class_1767.field_7963, class_1802.field_8268);
        }
    };

    private static final String BATCH_ID = String.format("%s:RecipeBatch",
            ReinforcedShulkerBoxesMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_1767 color : SHULKER_BOX_MAP.keySet()) {
                class_1799 baseShulkerBox = new class_1799(SHULKER_BOX_MAP.get(color));
                baseShulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                class_1799 material = new class_1799(class_1802.field_27022);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper")).get(color));
                shulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                add(RecipeTests.createTest(
                        String.format("Craft %s", baseShulkerBox.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseShulkerBox, material,
                                material, material, material),
                        shulkerBox));
            }

            for (class_1767 baseColor : SHULKER_BOX_MAP.keySet()) {
                for (class_1767 dyeColor : class_1767.values()) {
                    class_1799 baseShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                                    .get(baseColor));
                    baseShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                    class_1799 dye = new class_1799(class_1769.method_7803(dyeColor));
                    class_1799 dyedShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                                    .get(dyeColor));
                    dyedShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                    add(RecipeTests.createTest(
                            String.format("Coloring from %s to %s",
                                    baseShulkerBox.method_7909().method_7848().getString(),
                                    dyedShulkerBox.method_7909().method_7848().getString()),
                            class_3956.field_17545,
                            RecipeTests.create3x3CraftingInventory(
                                    baseShulkerBox, dye, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037),
                            dyedShulkerBox));
                }
            }

            {
                class_1799 chest = new class_1799(
                        atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                                .get(ReinforcingMaterials.MAP.get("copper")));
                class_1799 shell = new class_1799(class_1802.field_8815);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                                .get((class_1767) null));

                add(RecipeTests.createTest(
                        String.format("Craft %s from %s",
                                shulkerBox.method_7909().method_7848().getString(),
                                chest.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                shell, class_1799.field_8037, class_1799.field_8037,
                                chest, class_1799.field_8037, class_1799.field_8037,
                                shell, class_1799.field_8037, class_1799.field_8037),
                        shulkerBox));
            }

            // Iron Shulker Box
            for (class_1767 color : SHULKER_BOX_MAP.keySet()) {
                class_1799 baseShulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper")).get(color));
                baseShulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                class_1799 material = new class_1799(class_1802.field_8620);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron")).get(color));
                shulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                add(RecipeTests.createTest(
                        String.format("Craft %s", baseShulkerBox.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseShulkerBox, material,
                                material, material, material),
                        shulkerBox));
            }

            for (class_1767 baseColor : SHULKER_BOX_MAP.keySet()) {
                for (class_1767 dyeColor : class_1767.values()) {
                    class_1799 baseShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                                    .get(baseColor));
                    baseShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                    class_1799 dye = new class_1799(class_1769.method_7803(dyeColor));
                    class_1799 dyedShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                                    .get(dyeColor));
                    dyedShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                    add(RecipeTests.createTest(
                            String.format("Coloring from %s to %s",
                                    baseShulkerBox.method_7909().method_7848().getString(),
                                    dyedShulkerBox.method_7909().method_7848().getString()),
                            class_3956.field_17545,
                            RecipeTests.create3x3CraftingInventory(
                                    baseShulkerBox, dye, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037),
                            dyedShulkerBox));
                }
            }

            {
                class_1799 chest = new class_1799(
                        atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                                .get(ReinforcingMaterials.MAP.get("iron")));
                class_1799 shell = new class_1799(class_1802.field_8815);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                                .get((class_1767) null));

                add(RecipeTests.createTest(
                        String.format("Craft %s from %s",
                                shulkerBox.method_7909().method_7848().getString(),
                                chest.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                shell, class_1799.field_8037, class_1799.field_8037,
                                chest, class_1799.field_8037, class_1799.field_8037,
                                shell, class_1799.field_8037, class_1799.field_8037),
                        shulkerBox));
            }

            // Gold Shulker Box
            for (class_1767 color : SHULKER_BOX_MAP.keySet()) {
                class_1799 baseShulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron")).get(color));
                baseShulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                class_1799 material = new class_1799(class_1802.field_8695);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold")).get(color));
                shulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                add(RecipeTests.createTest(
                        String.format("Craft %s", baseShulkerBox.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseShulkerBox, material,
                                material, material, material),
                        shulkerBox));
            }

            for (class_1767 baseColor : SHULKER_BOX_MAP.keySet()) {
                for (class_1767 dyeColor : class_1767.values()) {
                    class_1799 baseShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                                    .get(baseColor));
                    baseShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                    class_1799 dye = new class_1799(class_1769.method_7803(dyeColor));
                    class_1799 dyedShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                                    .get(dyeColor));
                    dyedShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                    add(RecipeTests.createTest(
                            String.format("Coloring from %s to %s",
                                    baseShulkerBox.method_7909().method_7848().getString(),
                                    dyedShulkerBox.method_7909().method_7848().getString()),
                            class_3956.field_17545,
                            RecipeTests.create3x3CraftingInventory(
                                    baseShulkerBox, dye, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037),
                            dyedShulkerBox));
                }
            }

            {
                class_1799 chest = new class_1799(
                        atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                                .get(ReinforcingMaterials.MAP.get("gold")));
                class_1799 shell = new class_1799(class_1802.field_8815);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                                .get((class_1767) null));

                add(RecipeTests.createTest(
                        String.format("Craft %s from %s",
                                shulkerBox.method_7909().method_7848().getString(),
                                chest.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                shell, class_1799.field_8037, class_1799.field_8037,
                                chest, class_1799.field_8037, class_1799.field_8037,
                                shell, class_1799.field_8037, class_1799.field_8037),
                        shulkerBox));
            }

            // Diamond Shulker Box
            for (class_1767 color : SHULKER_BOX_MAP.keySet()) {
                class_1799 baseShulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold")).get(color));
                baseShulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                class_1799 material = new class_1799(class_1802.field_8477);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond")).get(color));
                shulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                add(RecipeTests.createTest(
                        String.format("Craft %s", baseShulkerBox.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseShulkerBox, material,
                                material, material, material),
                        shulkerBox));
            }

            for (class_1767 baseColor : SHULKER_BOX_MAP.keySet()) {
                for (class_1767 dyeColor : class_1767.values()) {
                    class_1799 baseShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                                    .get(baseColor));
                    baseShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                    class_1799 dye = new class_1799(class_1769.method_7803(dyeColor));
                    class_1799 dyedShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                                    .get(dyeColor));
                    dyedShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                    add(RecipeTests.createTest(
                            String.format("Coloring from %s to %s",
                                    baseShulkerBox.method_7909().method_7848().getString(),
                                    dyedShulkerBox.method_7909().method_7848().getString()),
                            class_3956.field_17545,
                            RecipeTests.create3x3CraftingInventory(
                                    baseShulkerBox, dye, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037),
                            dyedShulkerBox));
                }
            }

            {
                class_1799 chest = new class_1799(
                        atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                                .get(ReinforcingMaterials.MAP.get("diamond")));
                class_1799 shell = new class_1799(class_1802.field_8815);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                                .get((class_1767) null));

                add(RecipeTests.createTest(
                        String.format("Craft %s from %s",
                                shulkerBox.method_7909().method_7848().getString(),
                                chest.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                shell, class_1799.field_8037, class_1799.field_8037,
                                chest, class_1799.field_8037, class_1799.field_8037,
                                shell, class_1799.field_8037, class_1799.field_8037),
                        shulkerBox));
            }

            // Netherite Shulker Box
            for (class_1767 color : SHULKER_BOX_MAP.keySet()) {
                class_1799 template = new class_1799(class_1802.field_41946);
                class_1799 baseShulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond")).get(color));
                baseShulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                class_1799 material = new class_1799(class_1802.field_22020);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite")).get(color));
                shulkerBox.method_57379(class_9334.field_49622,
                        class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                add(RecipeTests.createTest(
                        String.format("Smithing %s", baseShulkerBox.method_7909().method_7848().getString()),
                        class_3956.field_25388,
                        new class_1277(template, baseShulkerBox, material),
                        shulkerBox));
            }

            for (class_1767 baseColor : SHULKER_BOX_MAP.keySet()) {
                for (class_1767 dyeColor : class_1767.values()) {
                    class_1799 baseShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                                    .get(baseColor));
                    baseShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));
                    class_1799 dye = new class_1799(class_1769.method_7803(dyeColor));
                    class_1799 dyedShulkerBox = new class_1799(
                            ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                                    .get(dyeColor));
                    dyedShulkerBox.method_57379(class_9334.field_49622,
                            class_9288.method_57493(List.of(new class_1799(class_1802.field_8831))));

                    add(RecipeTests.createTest(
                            String.format("Coloring from %s to %s",
                                    baseShulkerBox.method_7909().method_7848().getString(),
                                    dyedShulkerBox.method_7909().method_7848().getString()),
                            class_3956.field_17545,
                            RecipeTests.create3x3CraftingInventory(
                                    baseShulkerBox, dye, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037,
                                    class_1799.field_8037, class_1799.field_8037, class_1799.field_8037),
                            dyedShulkerBox));
                }
            }

            {
                class_1799 chest = new class_1799(
                        atonkish.reinfchest.item.ModItems.REINFORCED_CHEST_MAP
                                .get(ReinforcingMaterials.MAP.get("netherite")));
                class_1799 shell = new class_1799(class_1802.field_8815);
                class_1799 shulkerBox = new class_1799(
                        ModItems.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                                .get((class_1767) null));

                add(RecipeTests.createTest(
                        String.format("Craft %s from %s",
                                shulkerBox.method_7909().method_7848().getString(),
                                chest.method_7909().method_7848().getString()),
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                shell, class_1799.field_8037, class_1799.field_8037,
                                chest, class_1799.field_8037, class_1799.field_8037,
                                shell, class_1799.field_8037, class_1799.field_8037),
                        shulkerBox));
            }
        }
    };

    private static <C extends class_1263, T extends class_1860<C>> class_4529 createTest(
            String name, class_3956<T> type, C inventory, class_1799 expected) {
        String testName = String.format("%s %s %s",
                ReinforcedShulkerBoxesMod.MOD_ID,
                RecipeTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                RecipeTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3218 world = context.method_35943();
                    class_1863 recipeManager = world.method_8433();
                    class_5455 registryManager = world.method_30349();
                    T recipe = recipeManager.method_8132(type, inventory, world).orElseThrow().comp_1933();

                    // Act
                    class_1799 actual = recipe.method_8116(inventory, registryManager);

                    // Assert
                    try {
                        context.method_46226(class_1799.method_7973(actual, expected),
                                "Recipe result differs from expected.");
                    } catch (Exception e) {
                        ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }

    private static class_8566 create3x3CraftingInventory(
            class_1799 stack1, class_1799 stack2, class_1799 stack3,
            class_1799 stack4, class_1799 stack5, class_1799 stack6,
            class_1799 stack7, class_1799 stack8, class_1799 stack9) {
        class_8566 inventory = new class_1715(new VoidScreenHander(), 3, 3);
        inventory.method_5447(0, stack1);
        inventory.method_5447(1, stack2);
        inventory.method_5447(2, stack3);
        inventory.method_5447(3, stack4);
        inventory.method_5447(4, stack5);
        inventory.method_5447(5, stack6);
        inventory.method_5447(6, stack7);
        inventory.method_5447(7, stack8);
        inventory.method_5447(8, stack9);
        return inventory;
    }
}
