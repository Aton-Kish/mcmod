package atonkish.reinfchest.mixin.datafixer.schema;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1208;
import net.minecraft.class_1238;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import atonkish.reinfchest.ReinforcedChestsMod;

@Mixin(class_1238.class)
public class Schema1460Mixin {
  @Inject(at = @At("RETURN"), method = "registerBlockEntities", cancellable = true)
  private void registerBlockEntities(
      Schema schema, CallbackInfoReturnable<Map<String, Supplier<TypeTemplate>>> cir) {
    Map<String, Supplier<TypeTemplate>> map = cir.getReturnValue();

    // TODO: materials should be able to be resolved dynamically.
    for (String material : List.of("copper", "iron", "gold", "diamond", "netherite")) {
      schema.register(
          map,
          String.format("%s:%s_chest", ReinforcedChestsMod.MOD_ID, material),
          () -> {
            return DSL.optionalFields("Items", DSL.list(class_1208.field_5712.in(schema)));
          });
    }
  }
}
