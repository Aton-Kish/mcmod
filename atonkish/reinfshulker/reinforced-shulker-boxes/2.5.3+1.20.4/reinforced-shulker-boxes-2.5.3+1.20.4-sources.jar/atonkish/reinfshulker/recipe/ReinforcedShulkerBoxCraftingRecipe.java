package atonkish.reinfshulker.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_5455;
import net.minecraft.class_5699;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.class_8957;

public class ReinforcedShulkerBoxCraftingRecipe extends class_1869 {
    final class_8957 raw;

    public ReinforcedShulkerBoxCraftingRecipe(String group, class_7710 category, class_8957 raw,
            class_1799 result, boolean showNotification) {
        super(group, category, raw, result, showNotification);
        this.raw = raw;
    }

    public ReinforcedShulkerBoxCraftingRecipe(String group, class_7710 category, class_8957 raw,
            class_1799 result) {
        this(group, category, raw, result, true);
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializer.REINFORCED_SHULKER_BOX;
    }

    private class_8957 getRaw() {
        return this.raw;
    }

    @Override
    public class_1799 method_17727(class_8566 recipeInputInventory, class_5455 dynamicRegistryManager) {
        class_1799 itemStack = this.method_8110(dynamicRegistryManager).method_7972();
        class_2487 nbtCompound = recipeInputInventory.method_5438(4).method_7969();

        if (nbtCompound != null) {
            itemStack.method_7980(nbtCompound.method_10553());
        }

        return itemStack;
    }

    public static class Serializer implements class_1865<ReinforcedShulkerBoxCraftingRecipe> {
        public static final Codec<ReinforcedShulkerBoxCraftingRecipe> CODEC = RecordCodecBuilder.create((instance) -> {
            return instance
                    .group(class_5699.method_53049(Codec.STRING, "group", "").forGetter((recipe) -> {
                        return recipe.method_8112();
                    }), class_7710.field_40252.fieldOf("category").orElse(class_7710.field_40251)
                            .forGetter((recipe) -> {
                                return recipe.method_45441();
                            }), class_8957.field_47321.forGetter((recipe) -> {
                                return recipe.getRaw();
                            }), class_1799.field_47309.fieldOf("result").forGetter((recipe) -> {
                                return recipe.method_8110(null);
                            }), class_5699.method_53049(Codec.BOOL, "show_notification", true)
                                    .forGetter((recipe) -> {
                                        return recipe.method_49188();
                                    }))
                    .apply(instance, ReinforcedShulkerBoxCraftingRecipe::new);
        });

        public Codec<ReinforcedShulkerBoxCraftingRecipe> method_53736() {
            return CODEC;
        }

        public ReinforcedShulkerBoxCraftingRecipe method_8122(class_2540 packetByteBuf) {
            String string = packetByteBuf.method_19772();
            class_7710 craftingRecipeCategory = (class_7710) packetByteBuf
                    .method_10818(class_7710.class);
            class_8957 rawShapedRecipe = class_8957.method_55090(packetByteBuf);
            class_1799 itemStack = packetByteBuf.method_10819();
            boolean bl = packetByteBuf.readBoolean();
            return new ReinforcedShulkerBoxCraftingRecipe(string, craftingRecipeCategory, rawShapedRecipe, itemStack,
                    bl);
        }

        public void write(class_2540 packetByteBuf, ReinforcedShulkerBoxCraftingRecipe recipe) {
            packetByteBuf.method_10814(recipe.method_8112());
            packetByteBuf.method_10817(recipe.method_45441());
            recipe.getRaw().method_55087(packetByteBuf);
            packetByteBuf.method_10793(recipe.method_8110(null));
            packetByteBuf.method_52964(recipe.method_49188());
        }
    }
}
