package atonkish.reinfshulker.block.cauldron;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;

import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_156;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_5556;
import net.minecraft.class_5620;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.item.ModItems;
import atonkish.reinfshulker.stat.ModStats;

public class ModCauldronBehavior {
    public static final Map<class_1792, class_5620> CLEAN_REINFORCED_SHULKER_BOX_MAP;
    private static final class_5620 CLEAN_REINFORCED_SHULKER_BOX;

    public static void init() {
    }

    static Object2ObjectOpenHashMap<class_1792, class_5620> createMap() {
        return class_156.method_654(new Object2ObjectOpenHashMap<>(), (map) -> {
            map.defaultReturnValue((state, world, pos, player, hand, stack) -> {
                return class_1269.field_5811;
            });
        });
    }

    static {
        CLEAN_REINFORCED_SHULKER_BOX = (state, world, pos, player, hand, stack) -> {
            class_2248 block = class_2248.method_9503(stack.method_7909());
            if (!(block instanceof ReinforcedShulkerBoxBlock)) {
                return class_1269.field_5811;
            } else {
                if (!world.field_9236) {
                    ReinforcingMaterial material = ((ReinforcedShulkerBoxBlock) block).getMaterial();
                    class_1799 itemStack = new class_1799(
                            ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).get((class_1767) null));
                    if (stack.method_7985()) {
                        itemStack.method_7980(stack.method_7969().method_10553());
                    }

                    player.method_6122(hand, itemStack);
                    player.method_7281(ModStats.CLEAN_REINFORCED_SHULKER_BOX_MAP.get(material));
                    class_5556.method_31650(state, world, pos);
                }

                return class_1269.method_29236(world.field_9236);
            }
        };

        CLEAN_REINFORCED_SHULKER_BOX_MAP = createMap();
        for (Map<class_1767, class_1792> materialShulkerBoxMap : ModItems.REINFORCED_SHULKER_BOX_MAP.values()) {
            for (class_1767 color : class_1767.values()) {
                CLEAN_REINFORCED_SHULKER_BOX_MAP.put(materialShulkerBoxMap.get(color), CLEAN_REINFORCED_SHULKER_BOX);
            }
        }
    }
}
