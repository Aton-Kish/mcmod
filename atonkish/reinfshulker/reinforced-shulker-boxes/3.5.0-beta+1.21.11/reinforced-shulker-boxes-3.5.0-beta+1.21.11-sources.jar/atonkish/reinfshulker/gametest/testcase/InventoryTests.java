package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2627;
import net.minecraft.class_2960;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.gametest.util.TestIdentifier;

public class InventoryTests {
  private static final String TEST_ENVIRONMENT_DEFAULT =
      String.format("%s:inventory/default", ReinforcedShulkerBoxesMod.MOD_ID);
  private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

  public static final Collection<TestFunction> TEST_FUNCTIONS =
      new ArrayList<>() {
        {
          // Copper Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("copper"))
                  .values()) {
            add(
                InventoryTests.createTest(
                    String.format("%s inventory size", block.method_9518().getString()), block, 45));
          }

          // Iron Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("iron"))
                  .values()) {
            add(
                InventoryTests.createTest(
                    String.format("%s inventory size", block.method_9518().getString()), block, 54));
          }

          // Gold Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("gold"))
                  .values()) {
            add(
                InventoryTests.createTest(
                    String.format("%s inventory size", block.method_9518().getString()), block, 81));
          }

          // Diamond Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("diamond"))
                  .values()) {
            add(
                InventoryTests.createTest(
                    String.format("%s inventory size", block.method_9518().getString()), block, 108));
          }

          // Netherite Shulker Box
          for (class_2248 block :
              ModBlocks.REINFORCED_SHULKER_BOX_MAP
                  .get(ReinforcingMaterials.MAP.get("netherite"))
                  .values()) {
            add(
                InventoryTests.createTest(
                    String.format("%s inventory size", block.method_9518().getString()), block, 108));
          }
        }
      };

  private static TestFunction createTest(String name, class_2248 shulkerBoxBlock, int size) {
    class_2960 testIdentifier =
        TestIdentifier.of(ReinforcedShulkerBoxesMod.MOD_ID, InventoryTests.class, name);

    return new TestFunction(
        testIdentifier,
        InventoryTests.TEST_ENVIRONMENT_DEFAULT,
        InventoryTests.TEST_STRUCTURE_EMPTY,
        20,
        0,
        true,
        class_2470.field_11467,
        false,
        1,
        1,
        false,
        (context) -> {
          // Arrange
          class_2338 blockPos = class_2338.field_10980;
          context.method_35984(blockPos, shulkerBoxBlock);

          // Act
          class_2627 entity =
              context.method_36014(blockPos, class_2627.class);

          // Assert
          try {
            context.method_56606(
                entity.method_5439(),
                size,
                class_2561.method_30163(String.format("%s inventory size", shulkerBoxBlock.method_9518().getString())));
          } catch (Exception e) {
            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
            throw e;
          }

          context.method_36036();
        });
  }
}
