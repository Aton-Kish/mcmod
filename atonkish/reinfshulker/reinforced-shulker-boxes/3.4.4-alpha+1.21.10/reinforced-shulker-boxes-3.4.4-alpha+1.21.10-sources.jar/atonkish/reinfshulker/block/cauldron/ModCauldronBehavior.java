package atonkish.reinfshulker.block.cauldron;

import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_5556;
import net.minecraft.class_5620;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.block.ReinforcedShulkerBoxBlock;
import atonkish.reinfshulker.item.ModItems;
import atonkish.reinfshulker.stat.ModStats;

public class ModCauldronBehavior {
    private static final class_5620 CLEAN_REINFORCED_SHULKER_BOX;

    public static void init() {
        Map<class_1792, class_5620> map = class_5620.field_27776.comp_1982();
        for (Map<class_1767, class_1792> materialShulkerBoxMap : ModItems.REINFORCED_SHULKER_BOX_MAP.values()) {
            for (class_1767 color : class_1767.values()) {
                map.put(materialShulkerBoxMap.get(color), CLEAN_REINFORCED_SHULKER_BOX);
            }
        }
    }

    static {
        CLEAN_REINFORCED_SHULKER_BOX = (state, world, pos, player, hand, stack) -> {
            class_2248 block = class_2248.method_9503(stack.method_7909());
            if (!(block instanceof ReinforcedShulkerBoxBlock)) {
                return class_1269.field_52423;
            } else {
                if (!world.method_8608()) {
                    ReinforcingMaterial material = ((ReinforcedShulkerBoxBlock) block).getMaterial();
                    player.method_6122(hand, stack.method_56701(
                            ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).get((class_1767) null), 1));
                    player.method_7281(ModStats.CLEAN_REINFORCED_SHULKER_BOX_MAP.get(material));
                    class_5556.method_31650(state, world, pos);
                }

                return class_1269.field_5812;
            }
        };
    }
}
