package atonkish.reinfcore.gametest;

import java.util.function.Consumer;
import net.minecraft.class_10657;
import net.minecraft.class_10660;
import net.minecraft.class_10664;
import net.minecraft.class_10665;
import net.minecraft.class_2378;
import net.minecraft.class_2470;
import net.minecraft.class_2960;
import net.minecraft.class_4516;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public record TestFunction(
        class_2960 identifier,
        String environment,
        String structure,
        int maxTicks,
        int setupTicks,
        boolean required,
        class_2470 rotation,
        boolean manualOnly,
        int maxAttempts,
        int requiredSuccesses,
        boolean skyAccess,
        Consumer<class_4516> testFunction) {
    public class_10664<class_6880<class_10665>> testData(
            class_2378<class_10665> testEnvironmentDefinitionRegistry) {
        class_6880<class_10665> testEnvironment = testEnvironmentDefinitionRegistry
                .method_46747(class_5321.method_29179(class_7924.field_56160, class_2960.method_60654(this.environment())));

        return new class_10664<>(
                testEnvironment,
                class_2960.method_60654(this.structure()),
                this.maxTicks(),
                this.setupTicks(),
                this.required(),
                this.rotation(),
                this.manualOnly(),
                this.maxAttempts(),
                this.requiredSuccesses(),
                this.skyAccess());
    }

    public class_10660 testInstance(class_2378<class_10665> testEnvironmentDefinitionRegistry) {
        return new class_10657(
                class_5321.method_29179(class_7924.field_56157, this.identifier()),
                this.testData(testEnvironmentDefinitionRegistry));
    }
}
