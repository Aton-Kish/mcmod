package atonkish.reinfshulker.mixin;

import java.util.ArrayList;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_2989;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import com.google.gson.JsonElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;

@Mixin(class_2989.class)
public class ServerAdvancementLoaderMixin {
    @Inject(method = "apply", at = @At("HEAD"))
    private void removeMissingIdentifier(Map<class_2960, JsonElement> map, class_3300 resourceManager,
            class_3695 profiler, CallbackInfo info) {
        if (ReinforcedShulkerBoxesMod.IS_REINFCHEST_LOADED) {
            return;
        }

        ArrayList<class_2960> missingIdentifiers = new ArrayList<>();
        for (class_2960 id : map.keySet()) {
            if (!id.method_12836().equals(ReinforcedShulkerBoxesMod.MOD_ID)) {
                continue;
            }

            if (id.method_12832().contains("chest")) {
                missingIdentifiers.add(id);
            }
        }

        missingIdentifiers.forEach(map::remove);
    }

}
