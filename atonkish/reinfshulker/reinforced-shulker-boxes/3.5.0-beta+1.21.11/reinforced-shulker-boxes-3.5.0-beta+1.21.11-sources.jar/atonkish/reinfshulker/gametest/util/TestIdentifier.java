package atonkish.reinfshulker.gametest.util;

import java.util.Locale;
import net.minecraft.class_2960;

public class TestIdentifier {
  public static class_2960 of(String namespace, Class<?> testClass, String name) {
    return class_2960.method_60655(
        namespace,
        camelToSnake(String.format("%s/%s", testClass.getSimpleName(), name).replace(" ", "_")));
  }

  private static String camelToSnake(String input) {
    return input.replaceAll("([a-z])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
  }
}
