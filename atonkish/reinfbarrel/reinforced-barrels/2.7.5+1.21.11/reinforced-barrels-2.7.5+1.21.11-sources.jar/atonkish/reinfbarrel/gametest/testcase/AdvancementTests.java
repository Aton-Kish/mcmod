package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_167;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.gametest.util.MockServerPlayerHelper;
import atonkish.reinfbarrel.gametest.util.TestIdentifier;
import atonkish.reinfbarrel.item.ModItems;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

public class AdvancementTests {
  private static final String TEST_ENVIRONMENT_DEFAULT =
      String.format("%s:advancement/default", ReinforcedBarrelsMod.MOD_ID);
  private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

  public static final Collection<TestFunction> TEST_FUNCTIONS =
      new ArrayList<>() {
        {
          // Copper Barrel
          add(
              AdvancementTests.createTest(
                  "Obtain Copper Barrel recipe advancement by having Barrel",
                  class_1802.field_16307,
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/copper_barrel")));
          add(
              AdvancementTests.createTest(
                  "Obtain Copper Barrel recipe advancement by having Copper Ingot",
                  class_1802.field_27022,
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/copper_barrel")));

          // Iron Barrel
          add(
              AdvancementTests.createTest(
                  "Obtain Iron Barrel recipe advancement by having Copper Barrel",
                  ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/iron_barrel")));
          add(
              AdvancementTests.createTest(
                  "Obtain Iron Barrel recipe advancement by having Iron Ingot",
                  class_1802.field_8620,
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/iron_barrel")));

          // Gold Barrel
          add(
              AdvancementTests.createTest(
                  "Obtain Gold Barrel recipe advancement by having Iron Barrel",
                  ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/gold_barrel")));
          add(
              AdvancementTests.createTest(
                  "Obtain Gold Barrel recipe advancement by having Gold Ingot",
                  class_1802.field_8695,
                  class_2960.method_60655(ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/gold_barrel")));

          // Diamond Barrel
          add(
              AdvancementTests.createTest(
                  "Obtain Diamond Barrel recipe advancement by having Gold Barrel",
                  ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                  class_2960.method_60655(
                      ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/diamond_barrel")));
          add(
              AdvancementTests.createTest(
                  "Obtain Diamond Barrel recipe advancement by having Diamond Ingot",
                  class_1802.field_8477,
                  class_2960.method_60655(
                      ReinforcedBarrelsMod.MOD_ID, "recipes/decorations/diamond_barrel")));

          // Netherite Barrel
          add(
              AdvancementTests.createTest(
                  "Obtain Netherite Barrel recipe advancement by having Diamond Barrel",
                  ModItems.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                  class_2960.method_60655(
                      ReinforcedBarrelsMod.MOD_ID,
                      "recipes/decorations/netherite_barrel_smithing")));
          add(
              AdvancementTests.createTest(
                  "Obtain Netherite Barrel recipe advancement by having Netherite Ingot",
                  class_1802.field_22020,
                  class_2960.method_60655(
                      ReinforcedBarrelsMod.MOD_ID,
                      "recipes/decorations/netherite_barrel_smithing")));
        }
      };

  private static TestFunction createTest(String name, class_1792 item, class_2960 advancementId) {
    class_2960 testIdentifier =
        TestIdentifier.of(ReinforcedBarrelsMod.MOD_ID, AdvancementTests.class, name);

    return new TestFunction(
        testIdentifier,
        AdvancementTests.TEST_ENVIRONMENT_DEFAULT,
        AdvancementTests.TEST_STRUCTURE_EMPTY,
        20,
        0,
        true,
        class_2470.field_11467,
        false,
        1,
        1,
        false,
        (context) -> {
          // Arrange
          class_3222 player =
              MockServerPlayerHelper.spawn(context, class_1934.field_9215, class_243.method_24954(class_2338.field_10980));
          class_8779 entry =
              context.method_35943().method_8503().method_3851().method_12896(advancementId);
          class_167 progress = player.method_14236().method_12882(entry);

          // Act
          CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
          CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

          Map<String, Boolean> progressMap = new HashMap<String, Boolean>();
          String progressMapKeyBeforeHavingItem = "beforeHavingItem";
          String progressMapKeyAfterHavingItem = "afterHavingItem";

          long tickOrigin = 0;
          context.method_35951(
              tickOrigin,
              () -> {
                progressMap.put(progressMapKeyBeforeHavingItem, progress.method_740());

                player.method_7270(new class_1799(item));

                futurePartialAct1.complete(null);
              });

          long tickObtained = 1;
          context.method_35951(
              tickObtained,
              () -> {
                progressMap.put(progressMapKeyAfterHavingItem, progress.method_740());

                futurePartialAct2.complete(null);
              });

          // Assert
          CompletableFuture.allOf(futurePartialAct1, futurePartialAct2)
              .thenRun(
                  () -> {
                    try {
                      context.method_49994(
                          progressMap.get(progressMapKeyBeforeHavingItem),
                          class_2561.method_30163(
                              String.format(
                                  "Expected that advancement %s has not been done yet, but it has been already done.",
                                  entry)));
                      context.method_46226(
                          progressMap.get(progressMapKeyAfterHavingItem),
                          class_2561.method_30163(
                              String.format(
                                  "Expected that advancement %s has been done, but it has not been done yet.",
                                  entry)));
                    } catch (Exception e) {
                      ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                      throw e;
                    } finally {
                      MockServerPlayerHelper.destroy(context, player);
                    }

                    context.method_36036();
                  });
        });
  }
}
