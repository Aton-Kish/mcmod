package atonkish.reinfbarrel.gametest.util;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2598;
import net.minecraft.class_3222;
import net.minecraft.class_4516;
import net.minecraft.class_8792;
import com.mojang.authlib.GameProfile;
import io.netty.channel.embedded.EmbeddedChannel;

public class MockServerPlayerHelper {
  private static AtomicInteger playerId = new AtomicInteger(1);

  public static class_3222 spawn(class_4516 context, class_1934 gameMode, class_243 pos) {
    class_8792 data =
        class_8792.method_53824(
            new GameProfile(
                UUID.randomUUID(), String.format("player-%d", playerId.getAndIncrement())),
            false);
    class_3222 player =
        new class_3222(
            context.method_35943().method_8503(),
            context.method_35943(),
            data.comp_1959(),
            data.comp_1961());
    class_2535 connection = new class_2535(class_2598.field_11941);
    new EmbeddedChannel(connection);
    context.method_35943().method_8503().method_3760().method_14570(connection, player, data);

    player.method_7336(gameMode);
    player.method_33574(context.method_35978(pos));
    player.method_24830(true);

    return player;
  }

  public static void destroy(class_4516 context, class_3222 player) {
    player.method_31472();
    player.method_31548().method_5448();
    player.field_13987.method_52396(
        class_2561.method_30163(
            String.format(
                "%s (%s) left the game",
                player.method_7334().name(), player.method_5845())));
  }
}
