package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3719;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.block.ModBlocks;

public class InventoryTests {
    private static final String BATCH_ID = String.format("%s:InventoryBatch",
            ReinforcedBarrelsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            add(InventoryTests.createTest(
                    "Copper Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    45));

            // Iron Barrel
            add(InventoryTests.createTest(
                    "Iron Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    54));

            // Gold Barrel
            add(InventoryTests.createTest(
                    "Gold Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    81));

            // Diamond Barrel
            add(InventoryTests.createTest(
                    "Diamond Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    108));

            // Netherite Barrel
            add(InventoryTests.createTest(
                    "Netherite Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("netherite")),
                    108));
        }
    };

    private static class_4529 createTest(String name, class_2248 barrelBlock, int size) {
        String testName = String.format("%s %s %s",
                ReinforcedBarrelsMod.MOD_ID,
                InventoryTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                InventoryTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, barrelBlock);

                    // Act
                    class_3719 entity = (class_3719) context.method_36014(blockPos);

                    // Assert
                    try {
                        context.method_56606(entity.method_5439(), size,
                                String.format("%s inventory size", barrelBlock.method_9518().getString()));
                    } catch (Exception e) {
                        ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
