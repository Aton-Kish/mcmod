package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2601;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;

public class DispenserBehaviorTests {
    private static final String BATCH_ID = String.format("%s:DispenserBehaviorBatch",
            ReinforcedShulkerBoxesMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                    .values()) {
                add(DispenserBehaviorTests.createTest(
                        String.format("Dispense %s", block.method_9518().getString()), block));
            }

            // Iron Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                    .values()) {
                add(DispenserBehaviorTests.createTest(
                        String.format("Dispense %s", block.method_9518().getString()), block));
            }

            // Gold Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                    .values()) {
                add(DispenserBehaviorTests.createTest(
                        String.format("Dispense %s", block.method_9518().getString()), block));
            }

            // Diamond Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                    .values()) {
                add(DispenserBehaviorTests.createTest(
                        String.format("Dispense %s", block.method_9518().getString()), block));
            }

            // Netherite Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                    .values()) {
                add(DispenserBehaviorTests.createTest(
                        String.format("Dispense %s", block.method_9518().getString()), block));
            }
        }
    };

    private static class_4529 createTest(String name, class_2248 shulkerBoxBlock) {
        String testName = String.format("%s %s %s",
                ReinforcedShulkerBoxesMod.MOD_ID,
                DispenserBehaviorTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                DispenserBehaviorTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35986(blockPos, class_2246.field_10200
                            .method_9564().method_11657(class_2315.field_10918, class_2350.field_11035));

                    class_2601 entity = (class_2601) context.method_36014(blockPos);
                    entity.method_5447(0, new class_1799(shulkerBoxBlock.method_8389()));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        context.method_35981(blockPos.method_10086(1), 0);

                        futurePartialAct1.complete(null);
                    });

                    long tickShulkerBoxPlaced = 4;
                    context.method_35951(tickShulkerBoxPlaced, () -> {
                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_35972(shulkerBoxBlock, blockPos.method_10077(1));
                        } catch (Exception e) {
                            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        }

                        context.method_36036();
                    });
                });
    }
}
