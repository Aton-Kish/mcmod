package atonkish.reinfcore.screen;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;
import atonkish.reinfcore.ReinforcedCoreMod;
import atonkish.reinfcore.util.ReinforcingMaterial;

public class ModScreenHandlerType {
  public static final Map<ReinforcingMaterial, class_3917<ReinforcedStorageScreenHandler>>
      REINFORCED_SINGLE_BLOCK_MAP = new LinkedHashMap<>();
  public static final Map<ReinforcingMaterial, class_3917<ReinforcedStorageScreenHandler>>
      REINFORCED_DOUBLE_BLOCK_MAP = new LinkedHashMap<>();
  public static final Map<ReinforcingMaterial, class_3917<ReinforcedStorageScreenHandler>>
      REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();

  public static class_3917<ReinforcedStorageScreenHandler> registerMaterialSingleBlock(
      ReinforcingMaterial material) {
    if (!REINFORCED_SINGLE_BLOCK_MAP.containsKey(material)) {
      String id = "single_" + material.getName() + "_block";
      class_3917.class_3918<ReinforcedStorageScreenHandler> factory =
          createSingleBlockScreenHandlerFactory(material);
      class_3917<ReinforcedStorageScreenHandler> screenHandlerType = register(id, factory);
      REINFORCED_SINGLE_BLOCK_MAP.put(material, screenHandlerType);
    }

    return REINFORCED_SINGLE_BLOCK_MAP.get(material);
  }

  public static class_3917<ReinforcedStorageScreenHandler> registerMaterialDoubleBlock(
      ReinforcingMaterial material) {
    if (!REINFORCED_DOUBLE_BLOCK_MAP.containsKey(material)) {
      String id = "double_" + material.getName() + "_block";
      class_3917.class_3918<ReinforcedStorageScreenHandler> factory =
          createDoubleBlockScreenHandlerFactory(material);
      class_3917<ReinforcedStorageScreenHandler> screenHandlerType = register(id, factory);
      REINFORCED_DOUBLE_BLOCK_MAP.put(material, screenHandlerType);
    }

    return REINFORCED_DOUBLE_BLOCK_MAP.get(material);
  }

  public static class_3917<ReinforcedStorageScreenHandler> registerMaterialShulkerBox(
      ReinforcingMaterial material) {
    if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
      String id = material.getName() + "_shulker_box";
      class_3917.class_3918<ReinforcedStorageScreenHandler> factory =
          createShulkerBoxScreenHandlerFactory(material);
      class_3917<ReinforcedStorageScreenHandler> screenHandlerType = register(id, factory);
      REINFORCED_SHULKER_BOX_MAP.put(material, screenHandlerType);
    }

    return REINFORCED_SHULKER_BOX_MAP.get(material);
  }

  private static class_3917<ReinforcedStorageScreenHandler> register(
      String id, class_3917.class_3918<ReinforcedStorageScreenHandler> factory) {
    class_2960 identifier = class_2960.method_60655(ReinforcedCoreMod.MOD_ID, id);
    class_3917<ReinforcedStorageScreenHandler> type =
        new class_3917<ReinforcedStorageScreenHandler>(
            factory, class_7701.field_40182);
    return class_2378.method_10230(class_7923.field_41187, identifier, type);
  }

  private static class_3917.class_3918<ReinforcedStorageScreenHandler>
      createSingleBlockScreenHandlerFactory(ReinforcingMaterial material) {
    return (int syncId, class_1661 playerInventory) ->
        ReinforcedStorageScreenHandler.createShulkerBoxScreen(material, syncId, playerInventory);
  }

  private static class_3917.class_3918<ReinforcedStorageScreenHandler>
      createDoubleBlockScreenHandlerFactory(ReinforcingMaterial material) {
    return (int syncId, class_1661 playerInventory) ->
        ReinforcedStorageScreenHandler.createDoubleBlockScreen(material, syncId, playerInventory);
  }

  private static class_3917.class_3918<ReinforcedStorageScreenHandler>
      createShulkerBoxScreenHandlerFactory(ReinforcingMaterial material) {
    return (int syncId, class_1661 playerInventory) ->
        ReinforcedStorageScreenHandler.createShulkerBoxScreen(material, syncId, playerInventory);
  }
}
