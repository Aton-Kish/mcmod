package atonkish.reinfbarrel.block.entity;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfbarrel.block.ModBlocks;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedBarrelBlockEntity>> REINFORCED_BARREL_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedBarrelBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_BARREL_MAP.containsKey(material)) {
            String id = material.getName() + "_barrel";
            class_2591.class_2592<ReinforcedBarrelBlockEntity> builder = class_2591.class_2592.method_20528(
                    ModBlockEntityType.createBlockEntityTypeFactory(material),
                    ModBlocks.REINFORCED_BARREL_MAP.get(material));
            class_2591<ReinforcedBarrelBlockEntity> blockEntityType = ModBlockEntityType.create(namespace, id,
                    builder);
            REINFORCED_BARREL_MAP.put(material, blockEntityType);
        }

        return REINFORCED_BARREL_MAP.get(material);
    }

    private static class_2591<ReinforcedBarrelBlockEntity> create(String namespace, String id,
            class_2591.class_2592<ReinforcedBarrelBlockEntity> builder) {
        return class_2378.method_10230(class_7923.field_41181, new class_2960(namespace, id),
                builder.method_11034(null));
    }

    private static class_2591.class_5559<ReinforcedBarrelBlockEntity> createBlockEntityTypeFactory(
            ReinforcingMaterial material) {
        return (class_2338 blockPos, class_2680 blockState) -> new ReinforcedBarrelBlockEntity(material, blockPos,
                blockState);
    }
}
