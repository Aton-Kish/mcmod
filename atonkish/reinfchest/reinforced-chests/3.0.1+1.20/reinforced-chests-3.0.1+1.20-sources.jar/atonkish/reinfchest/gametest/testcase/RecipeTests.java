package atonkish.reinfchest.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_5455;
import net.minecraft.class_8566;
import atonkish.reinfchest.ReinforcedChestsMod;
import atonkish.reinfchest.gametest.util.VoidScreenHander;
import atonkish.reinfchest.item.ModItems;
import atonkish.reinfcore.util.ReinforcingMaterials;

public class RecipeTests {
    private static final String BATCH_ID = String.format("%s:RecipeBatch",
            ReinforcedChestsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Chest
            {
                class_1799 baseChest = new class_1799(class_1802.field_8106);
                class_1799 material = new class_1799(class_1802.field_27022);
                class_1799 chest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")));

                add(RecipeTests.createTest(
                        "Craft Copper Chest",
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseChest, material,
                                material, material, material),
                        chest));
            }

            // Iron Chest
            {
                class_1799 baseChest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper")));
                class_1799 material = new class_1799(class_1802.field_8620);
                class_1799 chest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")));

                add(RecipeTests.createTest(
                        "Craft Iron Chest",
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseChest, material,
                                material, material, material),
                        chest));
            }

            // Gold Chest
            {
                class_1799 baseChest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron")));
                class_1799 material = new class_1799(class_1802.field_8695);
                class_1799 chest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")));

                add(RecipeTests.createTest(
                        "Craft Gold Chest",
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseChest, material,
                                material, material, material),
                        chest));
            }

            // Diamond Chest
            {
                class_1799 baseChest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold")));
                class_1799 material = new class_1799(class_1802.field_8477);
                class_1799 chest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")));

                add(RecipeTests.createTest(
                        "Craft Diamond Chest",
                        class_3956.field_17545,
                        RecipeTests.create3x3CraftingInventory(
                                material, material, material,
                                material, baseChest, material,
                                material, material, material),
                        chest));
            }

            // Netherite Chest
            {
                class_1799 template = new class_1799(class_1802.field_41946);
                class_1799 baseChest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond")));
                class_1799 material = new class_1799(class_1802.field_22020);
                class_1799 chest = new class_1799(
                        ModItems.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("netherite")));

                add(RecipeTests.createTest(
                        "Smithing Netherite Chest",
                        class_3956.field_25388,
                        new class_1277(template, baseChest, material),
                        chest));
            }
        }
    };

    private static <C extends class_1263, T extends class_1860<C>> class_4529 createTest(String name, class_3956<T> type,
            C inventory, class_1799 expected) {
        String testName = String.format("%s %s %s",
                ReinforcedChestsMod.MOD_ID,
                RecipeTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                RecipeTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3218 world = context.method_35943();
                    class_1863 recipeManager = world.method_8433();
                    class_5455 registryManager = world.method_30349();
                    T recipe = recipeManager.method_8132(type, inventory, world).orElseThrow().comp_1933();

                    // Act
                    class_1799 actual = recipe.method_8116(inventory, registryManager);

                    // Assert
                    try {
                        context.method_46226(class_1799.method_7973(actual, expected),
                                "Recipe result differs from expected.");
                    } catch (Exception e) {
                        ReinforcedChestsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }

    private static class_8566 create3x3CraftingInventory(
            class_1799 stack1, class_1799 stack2, class_1799 stack3,
            class_1799 stack4, class_1799 stack5, class_1799 stack6,
            class_1799 stack7, class_1799 stack8, class_1799 stack9) {
        class_8566 inventory = new class_1715(new VoidScreenHander(), 3, 3);
        inventory.method_5447(0, stack1);
        inventory.method_5447(1, stack2);
        inventory.method_5447(2, stack3);
        inventory.method_5447(3, stack4);
        inventory.method_5447(4, stack5);
        inventory.method_5447(5, stack6);
        inventory.method_5447(6, stack7);
        inventory.method_5447(7, stack8);
        inventory.method_5447(8, stack9);
        return inventory;
    }
}
