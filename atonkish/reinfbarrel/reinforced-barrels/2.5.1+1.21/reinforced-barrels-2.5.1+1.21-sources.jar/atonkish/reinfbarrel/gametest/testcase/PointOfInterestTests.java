package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3852;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfcore.util.ReinforcingMaterials;

public class PointOfInterestTests {
    private static final String BATCH_ID = String.format("%s:PointOfInterestBatch",
            ReinforcedBarrelsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Copper Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper"))));

            // Iron Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Iron Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron"))));

            // Gold Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Gold Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold"))));

            // Diamond Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Diamond Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond"))));

            // Netherite Barrel
            add(PointOfInterestTests.createTest(
                    "Villager have a fisherman profession at Netherite Barrel",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("netherite"))));
        }
    };

    private static class_4529 createTest(String name, class_2248 barrelBlock) {
        String testName = String.format("%s %s %s",
                ReinforcedBarrelsMod.MOD_ID,
                PointOfInterestTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                PointOfInterestTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                false,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;

                    context.method_35984(blockPos.method_10077(2).method_10086(1), class_2246.field_10499);
                    context.method_35984(blockPos.method_10077(1).method_10089(1).method_10086(1), class_2246.field_10499);
                    context.method_35984(blockPos.method_10077(1).method_10086(2), class_2246.field_10499);

                    class_1646 villager = context.method_35964(class_1299.field_6077, blockPos.method_10077(1));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        context.method_35984(blockPos, barrelBlock);

                        futurePartialAct1.complete(null);
                    });

                    long tickGetProfession = 100;
                    context.method_35951(tickGetProfession, () -> {
                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_56606(villager.method_7231().method_16924(),
                                    class_3852.field_17057,
                                    "villager profession");
                        } catch (Exception e) {
                            ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        }

                        context.method_36036();
                    });
                });
    }
}
