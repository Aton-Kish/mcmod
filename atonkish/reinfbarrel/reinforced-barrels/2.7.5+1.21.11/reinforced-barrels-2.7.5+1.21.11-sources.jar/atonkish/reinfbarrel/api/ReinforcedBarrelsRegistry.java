package atonkish.reinfbarrel.api;

import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.block.entity.ModBlockEntityType;
import atonkish.reinfbarrel.block.entity.ReinforcedBarrelBlockEntity;
import atonkish.reinfbarrel.item.ModItems;
import atonkish.reinfbarrel.stat.ModStats;
import atonkish.reinfcore.util.ReinforcingMaterial;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;

public class ReinforcedBarrelsRegistry {
  public static class_2960 registerMaterialOpenStat(
      String namespace, ReinforcingMaterial material) {
    return ModStats.registerMaterialOpen(namespace, material);
  }

  public static class_2248 registerMaterialBlock(
      String namespace, ReinforcingMaterial material, class_2248.Settings settings) {
    return ModBlocks.registerMaterial(namespace, material, settings);
  }

  public static class_2591<ReinforcedBarrelBlockEntity> registerMaterialBlockEntityType(
      String namespace, ReinforcingMaterial material) {
    return ModBlockEntityType.registerMaterial(namespace, material);
  }

  public static class_1792 registerMaterialItem(
      String namespace, ReinforcingMaterial material, class_1792.class_1793 settings) {
    return ModItems.registerMaterial(material, settings);
  }

  public static void registerMaterialItemGroupIcon(String namespace, ReinforcingMaterial material) {
    ModItems.registerMaterialItemGroupIcon(material);
  }
}
