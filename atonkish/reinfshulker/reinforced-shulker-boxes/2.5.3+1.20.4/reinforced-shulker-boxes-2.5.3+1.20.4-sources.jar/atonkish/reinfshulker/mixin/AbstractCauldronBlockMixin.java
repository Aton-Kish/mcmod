package atonkish.reinfshulker.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import atonkish.reinfshulker.block.cauldron.ModCauldronBehavior;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2275;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5556;
import net.minecraft.class_5620;

@Mixin(class_2275.class)
public class AbstractCauldronBlockMixin {
    @Inject(at = @At("HEAD"), method = "onUse", cancellable = true)
    public void onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit,
            CallbackInfoReturnable<class_1269> infoReturnable) {
        Class<?> cauldronClass = this.getClass();
        if (cauldronClass == class_5556.class) {
            class_1799 itemStack = player.method_5998(hand);
            class_1792 item = itemStack.method_7909();
            if (ModCauldronBehavior.CLEAN_REINFORCED_SHULKER_BOX_MAP.containsKey(item)) {
                class_5620 cauldronBehavior = ModCauldronBehavior.CLEAN_REINFORCED_SHULKER_BOX_MAP.get(item);
                infoReturnable.setReturnValue(cauldronBehavior.interact(state, world, pos, player, hand, itemStack));
            }
        }
    }
}
