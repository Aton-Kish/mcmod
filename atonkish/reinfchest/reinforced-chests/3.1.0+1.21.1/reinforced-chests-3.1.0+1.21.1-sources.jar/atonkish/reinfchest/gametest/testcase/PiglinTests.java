package atonkish.reinfchest.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1299;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_4140;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_4836;
import atonkish.reinfchest.ReinforcedChestsMod;
import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.gametest.util.MockServerPlayerHelper;
import atonkish.reinfcore.util.ReinforcingMaterials;

public class PiglinTests {
    private static final String BATCH_ID = String.format("%s:PiglinBatch",
            ReinforcedChestsMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Chest
            add(PiglinTests.createTest(
                    "Piglin get angry after opening Copper Chest",
                    ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("copper"))));

            // Iron Chest
            add(PiglinTests.createTest(
                    "Piglin get angry after opening Iron Chest",
                    ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("iron"))));

            // Gold Chest
            add(PiglinTests.createTest(
                    "Piglin get angry after opening Gold Chest",
                    ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("gold"))));

            // Diamond Chest
            add(PiglinTests.createTest(
                    "Piglin get angry after opening Diamond Chest",
                    ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("diamond"))));

            // Netherite Chest
            add(PiglinTests.createTest(
                    "Piglin get angry after opening Netherite Chest",
                    ModBlocks.REINFORCED_CHEST_MAP.get(ReinforcingMaterials.MAP.get("netherite"))));
        }
    };

    private static class_4529 createTest(String name, class_2248 chestBlock) {
        String testName = String.format("%s %s %s",
                ReinforcedChestsMod.MOD_ID,
                PiglinTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                PiglinTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, chestBlock);

                    class_3222 player = MockServerPlayerHelper.spawn(context,
                            class_1934.field_9215, class_243.method_24954(blockPos.method_10077(4)));
                    class_1738 armor = (class_1738) class_1802.field_8678;
                    player.method_5673(armor.method_7685(), new class_1799(armor));

                    class_4836 piglin = context.method_36009(class_1299.field_22281, blockPos.method_10089(1));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    Map<String, Boolean> angryAtMap = new HashMap<String, Boolean>();
                    String angryAtMapKeyBeforeAngryAtPlayer = "beforeAngryAtPlayer";
                    String angryAtMapKeyAfterAngryAtPlayer = "afterAngryAtPlayer";

                    long tickChestOpen = 20;
                    context.method_35951(tickChestOpen, () -> {
                        angryAtMap.put(angryAtMapKeyBeforeAngryAtPlayer,
                                piglin.method_18868().method_29519(class_4140.field_22333,
                                        player.method_5667()));

                        context.method_36034(blockPos, player);

                        futurePartialAct1.complete(null);
                    });

                    long tickAngryAtPlayer = 21;
                    context.method_35951(tickAngryAtPlayer, () -> {
                        angryAtMap.put(angryAtMapKeyAfterAngryAtPlayer,
                                piglin.method_18868().method_29519(class_4140.field_22333,
                                        player.method_5667()));

                        futurePartialAct2.complete(null);
                    });

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_49994(angryAtMap.get(angryAtMapKeyBeforeAngryAtPlayer),
                                    "Expected that the piglin is not angry at player, but it has been already angry.");
                            context.method_46226(angryAtMap.get(angryAtMapKeyAfterAngryAtPlayer),
                                    "Expected that the piglin is angry at player, but it has not been angry yet.");
                        } catch (Exception e) {
                            ReinforcedChestsMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        } finally {
                            MockServerPlayerHelper.destroy(context, player);
                        }

                        context.method_36036();
                    });
                });
    }
}
