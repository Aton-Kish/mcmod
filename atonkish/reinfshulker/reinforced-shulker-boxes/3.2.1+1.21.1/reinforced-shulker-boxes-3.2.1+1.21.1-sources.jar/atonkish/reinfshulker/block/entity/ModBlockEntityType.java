package atonkish.reinfshulker.block.entity;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.mixin.BlockEntityTypeAccessor;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedShulkerBoxBlockEntity>> REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedShulkerBoxBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            String id = material.getName() + "_shulker_box";
            Collection<class_2248> blocks = ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).values();
            class_2591.class_2592<ReinforcedShulkerBoxBlockEntity> builder = class_2591.class_2592
                    .method_20528(ModBlockEntityType.createBlockEntityTypeFactory(material), blocks.toArray(new class_2248[0]));
            class_2591<ReinforcedShulkerBoxBlockEntity> blockEntityType = ModBlockEntityType
                    .create(namespace, id, builder);
            REINFORCED_SHULKER_BOX_MAP.put(material, blockEntityType);

            ((BlockEntityTypeAccessor) class_2591.field_11896).getBlocks().addAll(blocks);
        }

        return REINFORCED_SHULKER_BOX_MAP.get(material);
    }

    private static class_2591<ReinforcedShulkerBoxBlockEntity> create(String namespace, String id,
            class_2591.class_2592<ReinforcedShulkerBoxBlockEntity> builder) {
        return class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(namespace, id),
                builder.method_11034(null));
    }

    private static class_2591.class_5559<ReinforcedShulkerBoxBlockEntity> createBlockEntityTypeFactory(
            ReinforcingMaterial material) {
        return (class_2338 blockPos, class_2680 blockState) -> new ReinforcedShulkerBoxBlockEntity(material, blockPos,
                blockState);
    }
}
