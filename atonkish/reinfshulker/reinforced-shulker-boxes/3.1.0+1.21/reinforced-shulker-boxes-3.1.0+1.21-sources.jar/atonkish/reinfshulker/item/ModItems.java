package atonkish.reinfshulker.item;

import java.util.LinkedHashMap;
import java.util.Map;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import atonkish.reinfcore.item.ModItemGroup;
import atonkish.reinfcore.item.ModItemGroups;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.block.ModBlocks;

public class ModItems {
    public static final Map<ReinforcingMaterial, Map<class_1767, class_1792>> REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, Map<class_1767, class_1792.class_1793>> REINFORCED_SHULKER_BOX_SETTINGS_MAP = new LinkedHashMap<>();

    public static class_1792 registerMaterialDyeColor(ReinforcingMaterial material, class_1767 color,
            class_1792.class_1793 settings) {
        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).containsKey(color)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).put(color, settings);
        }

        if (!REINFORCED_SHULKER_BOX_MAP.get(material).containsKey(color)) {
            class_1792 item = ModItems.register(
                    new class_1747(ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(material).get(color),
                            REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).get(color)));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_41059).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(content -> content.method_45421(item));
            ItemGroupEvents.modifyEntriesEvent(ModItemGroups.REINFORCED_STORAGE).register(content -> content.method_45421(item));
            REINFORCED_SHULKER_BOX_MAP.get(material).put(color, item);
        }

        return REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
    }

    public static void registerMaterialDyeColorItemGroupIcon(ReinforcingMaterial material, class_1767 color) {
        class_1792 item = REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
        ModItemGroup.setIcon(class_7923.field_44687.method_29107(ModItemGroups.REINFORCED_STORAGE), item);
    }

    private static class_1792 register(class_1747 item) {
        return ModItems.register(item.method_7711(), (class_1792) item);
    }

    protected static class_1792 register(class_2248 block, class_1792 item) {
        return ModItems.register(class_7923.field_41175.method_10221(block), item);
    }

    private static class_1792 register(class_2960 id, class_1792 item) {
        if (item instanceof class_1747) {
            ((class_1747) item).method_7713(class_1792.field_8003, item);
        }

        return class_2378.method_10230(class_7923.field_41178, id, item);
    }
}
