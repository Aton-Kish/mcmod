package atonkish.reinfbarrel.mixin;

import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2591.class)
public interface BlockEntityTypeInvoker {
  @Invoker("create")
  public static <T extends class_2586> class_2591<T> create(
      String id,
      class_2591.class_5559<? extends T> blockEntityFactory,
      class_2248... blocks) {
    throw new AssertionError();
  }
}
