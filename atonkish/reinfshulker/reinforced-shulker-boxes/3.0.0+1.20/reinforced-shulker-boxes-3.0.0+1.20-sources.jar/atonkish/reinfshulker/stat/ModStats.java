package atonkish.reinfshulker.stat;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;

public class ModStats {
    public static final Map<ReinforcingMaterial, class_2960> CLEAN_REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, class_2960> OPEN_REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();

    public static class_2960 registerMaterialClean(String namespace, ReinforcingMaterial material) {
        if (!CLEAN_REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            String id = "clean_" + material.getName() + "_shulker_box";
            class_2960 identifier = register(namespace, id, class_3446.field_16975);
            CLEAN_REINFORCED_SHULKER_BOX_MAP.put(material, identifier);
        }

        return CLEAN_REINFORCED_SHULKER_BOX_MAP.get(material);
    }

    public static class_2960 registerMaterialOpen(String namespace, ReinforcingMaterial material) {
        if (!OPEN_REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            String id = "open_" + material.getName() + "_shulker_box";
            class_2960 identifier = register(namespace, id, class_3446.field_16975);
            OPEN_REINFORCED_SHULKER_BOX_MAP.put(material, identifier);
        }

        return OPEN_REINFORCED_SHULKER_BOX_MAP.get(material);
    }

    private static class_2960 register(String namespace, String id, class_3446 formatter) {
        class_2960 identifier = new class_2960(namespace, id);
        class_2378.method_10226(class_7923.field_41183, id, identifier);
        class_3468.field_15419.method_14955(identifier, formatter);
        return identifier;
    }
}
