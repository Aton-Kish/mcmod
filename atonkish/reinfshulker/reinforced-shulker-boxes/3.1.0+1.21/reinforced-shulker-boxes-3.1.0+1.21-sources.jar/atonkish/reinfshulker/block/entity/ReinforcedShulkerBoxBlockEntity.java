package atonkish.reinfshulker.block.entity;

import java.util.stream.IntStream;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import atonkish.reinfcore.screen.ReinforcedStorageScreenHandler;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.mixin.BlockEntityAccessor;

public class ReinforcedShulkerBoxBlockEntity extends class_2627 {
    private final ReinforcingMaterial cachedMaterial;

    public ReinforcedShulkerBoxBlockEntity(ReinforcingMaterial material, @Nullable class_1767 color, class_2338 pos,
            class_2680 state) {
        super(color, pos, state);
        ((BlockEntityAccessor) this).setType(ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(material));
        this.method_11281(class_2371.method_10213(material.getSize(), class_1799.field_8037));
        this.cachedMaterial = material;
    }

    public ReinforcedShulkerBoxBlockEntity(ReinforcingMaterial material, class_2338 pos, class_2680 state) {
        super(pos, state);
        ((BlockEntityAccessor) this).setType(ModBlockEntityType.REINFORCED_SHULKER_BOX_MAP.get(material));
        this.method_11281(class_2371.method_10213(material.getSize(), class_1799.field_8037));
        this.cachedMaterial = material;
    }

    @Override
    protected class_2561 method_17823() {
        String namespace = class_2591.method_11033(this.method_11017()).method_12836();
        return class_2561.method_43471("container." + namespace + "." + this.cachedMaterial.getName() + "ShulkerBox");
    }

    @Override
    public int[] method_5494(class_2350 side) {
        return IntStream.range(0, this.method_5439()).toArray();
    }

    public ReinforcingMaterial getMaterial() {
        return this.cachedMaterial;
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return ReinforcedStorageScreenHandler.createShulkerBoxScreen(this.cachedMaterial, syncId, playerInventory,
                this);
    }
}
