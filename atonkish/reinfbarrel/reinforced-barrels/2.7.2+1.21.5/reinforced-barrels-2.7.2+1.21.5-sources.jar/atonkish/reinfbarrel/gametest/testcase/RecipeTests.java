package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_9694;
import net.minecraft.class_9695;
import net.minecraft.class_9697;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.gametest.util.TestIdentifier;
import atonkish.reinfbarrel.item.ModItems;

public class RecipeTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:recipe/default",
            ReinforcedBarrelsMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            {
                class_1799 baseBarrel = new class_1799(class_1802.field_16307);
                class_1799 material = new class_1799(class_1802.field_27022);
                class_1799 barrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("copper")));

                add(RecipeTests.createTest(
                        "Craft Copper Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Iron Barrel
            {
                class_1799 baseBarrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("copper")));
                class_1799 material = new class_1799(class_1802.field_8620);
                class_1799 barrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("iron")));

                add(RecipeTests.createTest(
                        "Craft Iron Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Gold Barrel
            {
                class_1799 baseBarrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("iron")));
                class_1799 material = new class_1799(class_1802.field_8695);
                class_1799 barrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("gold")));

                add(RecipeTests.createTest(
                        "Craft Gold Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Diamond Barrel
            {
                class_1799 baseBarrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("gold")));
                class_1799 material = new class_1799(class_1802.field_8477);
                class_1799 barrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("diamond")));

                add(RecipeTests.createTest(
                        "Craft Diamond Barrel",
                        class_3956.field_17545,
                        class_9694.method_59986(3, 3, List.of(
                                material, material, material,
                                material, baseBarrel, material,
                                material, material, material)),
                        barrel));
            }

            // Netherite Barrel
            {
                class_1799 template = new class_1799(class_1802.field_41946);
                class_1799 baseBarrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("diamond")));
                class_1799 material = new class_1799(class_1802.field_22020);
                class_1799 barrel = new class_1799(ModItems.REINFORCED_BARREL_MAP
                        .get(ReinforcingMaterials.MAP.get("netherite")));

                add(RecipeTests.createTest(
                        "Smithing Netherite Barrel",
                        class_3956.field_25388,
                        new class_9697(template, baseBarrel, material),
                        barrel));
            }
        }
    };

    private static <I extends class_9695, T extends class_1860<I>> TestFunction createTest(String name,
            class_3956<T> type, I input, class_1799 expected) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedBarrelsMod.MOD_ID,
                RecipeTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                RecipeTests.TEST_ENVIRONMENT_DEFAULT,
                RecipeTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_3218 world = context.method_35943();
                    class_1863 recipeManager = world.method_64577();
                    class_5455 registryManager = world.method_30349();
                    T recipe = recipeManager.method_8132(type, input, world).orElseThrow().comp_1933();

                    // Act
                    class_1799 actual = recipe.method_8116(input, registryManager);

                    // Assert
                    try {
                        context.method_46226(class_1799.method_7973(actual, expected),
                                class_2561.method_30163("Recipe result differs from expected."));
                    } catch (Exception e) {
                        ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
