package atonkish.reinfshulker.block;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import atonkish.reinfcore.util.ReinforcingMaterial;

public class ModBlocks {
    public static final Map<ReinforcingMaterial, Map<class_1767, class_2248>> REINFORCED_SHULKER_BOX_MAP = new LinkedHashMap<>();
    public static final Map<ReinforcingMaterial, Map<class_1767, class_2248.Settings>> REINFORCED_SHULKER_BOX_SETTINGS_MAP = new LinkedHashMap<>();

    public static class_2248 registerMaterialDyeColor(String namespace, ReinforcingMaterial material, class_1767 color,
            class_2248.Settings settings) {
        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
            REINFORCED_SHULKER_BOX_MAP.put(material, new LinkedHashMap<>());
        }

        if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).containsKey(color)) {
            REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).put(color, settings);
        }

        if (!REINFORCED_SHULKER_BOX_MAP.get(material).containsKey(color)) {
            String id = color == null
                    ? material.getName() + "_shulker_box"
                    : color.method_7792() + "_" + material.getName() + "_shulker_box";
            class_2248 block = ModBlocks.register(namespace, id, new ReinforcedShulkerBoxBlock(material, color, settings));
            REINFORCED_SHULKER_BOX_MAP.get(material).put(color, block);
        }

        return REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
    }

    private static class_2248 register(String namespace, String id, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(namespace, id), block);
    }
}
