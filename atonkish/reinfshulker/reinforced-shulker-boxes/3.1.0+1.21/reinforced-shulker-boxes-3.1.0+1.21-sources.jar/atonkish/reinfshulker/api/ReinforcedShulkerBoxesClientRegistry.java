package atonkish.reinfshulker.api;

import java.util.List;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfshulker.client.render.ModTexturedRenderLayers;

@Environment(EnvType.CLIENT)
public class ReinforcedShulkerBoxesClientRegistry {
    @Deprecated
    public static class_2960 registerMaterialAtlasTexture(String namespace, ReinforcingMaterial material) {
        return class_4722.field_21704;
    }

    @Deprecated
    public static class_1921 registerMaterialRenderLayer(String namespace, ReinforcingMaterial material) {
        return class_4722.method_24070();
    }

    public static class_4730 registerMaterialDefaultSprite(String namespace, ReinforcingMaterial material) {
        return ModTexturedRenderLayers.registerMaterialDefaultSprite(namespace, material);
    }

    public static List<class_4730> registerMaterialColoringSprites(String namespace,
            ReinforcingMaterial material) {
        return ModTexturedRenderLayers.registerMaterialColoringSprites(namespace, material);
    }
}
