package atonkish.reinfcore.item;

import atonkish.reinfcore.mixin.ItemGroupAccessor;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1935;

public class ModItemGroup {
  public static void setIcon(class_1761 itemGroup, class_1935 item) {
    class_1799 itemStack = new class_1799(item);
    ((ItemGroupAccessor) itemGroup).setIcon(itemStack);
  }
}
