package atonkish.reinfchest.block.entity;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import atonkish.reinfcore.util.ReinforcingMaterial;

import atonkish.reinfchest.block.ModBlocks;
import atonkish.reinfchest.mixin.BlockEntityTypeAccessor;
import atonkish.reinfchest.mixin.BlockEntityTypeInvoker;

public class ModBlockEntityType {
    public static final Map<ReinforcingMaterial, class_2591<ReinforcedChestBlockEntity>> REINFORCED_CHEST_MAP = new LinkedHashMap<>();

    public static class_2591<ReinforcedChestBlockEntity> registerMaterial(String namespace,
            ReinforcingMaterial material) {
        if (!REINFORCED_CHEST_MAP.containsKey(material)) {
            String id = material.getName() + "_chest";
            class_2248 block = ModBlocks.REINFORCED_CHEST_MAP.get(material);
            class_2591<ReinforcedChestBlockEntity> blockEntityType = BlockEntityTypeInvoker.create(
                    class_2960.method_60655(namespace, id).toString(),
                    (blockPos, blockState) -> new ReinforcedChestBlockEntity(material, blockPos, blockState),
                    block);
            REINFORCED_CHEST_MAP.put(material, blockEntityType);

            ((BlockEntityTypeAccessor) class_2591.field_11914).getBlocks().add(block);
        }

        return REINFORCED_CHEST_MAP.get(material);
    }
}
