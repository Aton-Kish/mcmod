package atonkish.reinfshulker.block.dispenser;

import java.util.Map;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2315;
import net.minecraft.class_2970;
import atonkish.reinfshulker.item.ModItems;

public interface ModDispenserBehavior {
  public static void init() {
    for (Map<class_1767, class_1792> materialShulkerBoxMap : ModItems.REINFORCED_SHULKER_BOX_MAP.values()) {
      for (class_1792 item : materialShulkerBoxMap.values()) {
        class_2315.method_10009(item, new class_2970());
      }
    }
  }
}
