package atonkish.reinfbarrel.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3719;
import atonkish.reinfcore.gametest.TestFunction;
import atonkish.reinfcore.util.ReinforcingMaterials;

import atonkish.reinfbarrel.ReinforcedBarrelsMod;
import atonkish.reinfbarrel.block.ModBlocks;
import atonkish.reinfbarrel.gametest.util.TestIdentifier;

public class InventoryTests {
    private static final String TEST_ENVIRONMENT_DEFAULT = String.format("%s:inventory/default",
            ReinforcedBarrelsMod.MOD_ID);
    private static final String TEST_STRUCTURE_EMPTY = "fabric-gametest-api-v1:empty";

    public static final Collection<TestFunction> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Barrel
            add(InventoryTests.createTest(
                    "Copper Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("copper")),
                    45));

            // Iron Barrel
            add(InventoryTests.createTest(
                    "Iron Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("iron")),
                    54));

            // Gold Barrel
            add(InventoryTests.createTest(
                    "Gold Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("gold")),
                    81));

            // Diamond Barrel
            add(InventoryTests.createTest(
                    "Diamond Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("diamond")),
                    108));

            // Netherite Barrel
            add(InventoryTests.createTest(
                    "Netherite Barrel inventory size",
                    ModBlocks.REINFORCED_BARREL_MAP.get(ReinforcingMaterials.MAP.get("netherite")),
                    108));
        }
    };

    private static TestFunction createTest(String name, class_2248 barrelBlock, int size) {
        class_2960 testIdentifier = TestIdentifier.of(ReinforcedBarrelsMod.MOD_ID,
                InventoryTests.class,
                name);

        return new TestFunction(
                testIdentifier,
                InventoryTests.TEST_ENVIRONMENT_DEFAULT,
                InventoryTests.TEST_STRUCTURE_EMPTY,
                20,
                0,
                true,
                class_2470.field_11467,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, barrelBlock);

                    // Act
                    class_3719 entity = context.method_36014(blockPos, class_3719.class);

                    // Assert
                    try {
                        context.method_56606(entity.method_5439(), size,
                                class_2561.method_30163(String.format("%s inventory size", barrelBlock.method_9518().getString())));
                    } catch (Exception e) {
                        ReinforcedBarrelsMod.LOGGER.error("[{}] {}", testIdentifier, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
