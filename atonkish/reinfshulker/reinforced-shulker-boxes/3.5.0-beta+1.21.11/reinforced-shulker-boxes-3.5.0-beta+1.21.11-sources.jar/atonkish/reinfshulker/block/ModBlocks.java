package atonkish.reinfshulker.block;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import atonkish.reinfcore.util.ReinforcingMaterial;

public class ModBlocks {
  public static final Map<ReinforcingMaterial, Map<class_1767, class_2248>> REINFORCED_SHULKER_BOX_MAP =
      new LinkedHashMap<>();
  public static final Map<ReinforcingMaterial, Map<class_1767, class_2248.Settings>>
      REINFORCED_SHULKER_BOX_SETTINGS_MAP = new LinkedHashMap<>();

  public static class_2248 registerMaterialDyeColor(
      String namespace, ReinforcingMaterial material, class_1767 color, class_2248.Settings settings) {
    if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.containsKey(material)) {
      REINFORCED_SHULKER_BOX_SETTINGS_MAP.put(material, new LinkedHashMap<>());
    }

    if (!REINFORCED_SHULKER_BOX_MAP.containsKey(material)) {
      REINFORCED_SHULKER_BOX_MAP.put(material, new LinkedHashMap<>());
    }

    if (!REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).containsKey(color)) {
      REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).put(color, settings);
    }

    if (!REINFORCED_SHULKER_BOX_MAP.get(material).containsKey(color)) {
      String id =
          color == null
              ? material.getName() + "_shulker_box"
              : color.method_7792() + "_" + material.getName() + "_shulker_box";
      class_2248 block =
          ModBlocks.register(
              class_2960.method_60655(namespace, id),
              (abstractBlockSettings) ->
                  new ReinforcedShulkerBoxBlock(material, color, abstractBlockSettings),
              REINFORCED_SHULKER_BOX_SETTINGS_MAP.get(material).get(color));
      REINFORCED_SHULKER_BOX_MAP.get(material).put(color, block);
    }

    return REINFORCED_SHULKER_BOX_MAP.get(material).get(color);
  }

  private static class_2248 register(
      class_5321<class_2248> key,
      Function<class_4970.class_2251, class_2248> factory,
      class_4970.class_2251 settings) {
    class_2248 block = factory.apply(settings.method_63500(key));
    return class_2378.method_39197(class_7923.field_41175, key, block);
  }

  private static class_2248 register(
      class_2960 id,
      Function<class_4970.class_2251, class_2248> factory,
      class_4970.class_2251 settings) {
    return register(keyOf(id), factory, settings);
  }

  private static class_5321<class_2248> keyOf(class_2960 id) {
    return class_5321.method_29179(class_7924.field_41254, id);
  }
}
