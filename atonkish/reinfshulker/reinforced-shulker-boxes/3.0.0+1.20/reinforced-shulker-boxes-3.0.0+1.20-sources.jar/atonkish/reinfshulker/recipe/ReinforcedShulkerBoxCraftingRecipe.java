package atonkish.reinfshulker.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.class_8957;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class ReinforcedShulkerBoxCraftingRecipe extends class_1869 {
    final class_8957 raw;

    public ReinforcedShulkerBoxCraftingRecipe(String group, class_7710 category, class_8957 raw,
            class_1799 result, boolean showNotification) {
        super(group, category, raw, result, showNotification);
        this.raw = raw;
    }

    public ReinforcedShulkerBoxCraftingRecipe(String group, class_7710 category, class_8957 raw,
            class_1799 result) {
        this(group, category, raw, result, true);
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializer.REINFORCED_SHULKER_BOX;
    }

    private class_8957 getRaw() {
        return this.raw;
    }

    @Override
    public class_1799 method_17727(class_8566 recipeInputInventory, class_7225.class_7874 wrapperLookup) {
        class_1792 item = this.method_8110(wrapperLookup).method_7972().method_7909();
        class_1799 itemStack = recipeInputInventory.method_5438(4);
        return itemStack.method_56701(item, 1);
    }

    public static class Serializer implements class_1865<ReinforcedShulkerBoxCraftingRecipe> {
        public static final MapCodec<ReinforcedShulkerBoxCraftingRecipe> CODEC = RecordCodecBuilder
                .mapCodec((instance) -> {
                    return instance
                            .group(Codec.STRING.optionalFieldOf("group", "").forGetter((recipe) -> {
                                return recipe.method_8112();
                            }), class_7710.field_40252.fieldOf("category").orElse(class_7710.field_40251)
                                    .forGetter((recipe) -> {
                                        return recipe.method_45441();
                                    }), class_8957.field_47321.forGetter((recipe) -> {
                                        return recipe.getRaw();
                                    }), class_1799.field_51397.fieldOf("result").forGetter((recipe) -> {
                                        return recipe.method_8110(null);
                                    }), Codec.BOOL.optionalFieldOf("show_notification", true)
                                            .forGetter((recipe) -> {
                                                return recipe.method_49188();
                                            }))
                            .apply(instance, ReinforcedShulkerBoxCraftingRecipe::new);
                });
        public static final class_9139<class_9129, ReinforcedShulkerBoxCraftingRecipe> PACKET_CODEC = class_9139
                .method_56437(Serializer::write, Serializer::read);

        public Serializer() {
        }

        public MapCodec<ReinforcedShulkerBoxCraftingRecipe> method_53736() {
            return CODEC;
        }

        public class_9139<class_9129, ReinforcedShulkerBoxCraftingRecipe> method_56104() {
            return PACKET_CODEC;
        }

        public static ReinforcedShulkerBoxCraftingRecipe read(class_9129 buf) {
            String string = buf.method_19772();
            class_7710 craftingRecipeCategory = (class_7710) buf
                    .method_10818(class_7710.class);
            class_8957 rawShapedRecipe = class_8957.field_48359.decode(buf);
            class_1799 itemStack = class_1799.field_48349.decode(buf);
            boolean bl = buf.readBoolean();
            return new ReinforcedShulkerBoxCraftingRecipe(string, craftingRecipeCategory, rawShapedRecipe, itemStack,
                    bl);
        }

        public static void write(class_9129 buf, ReinforcedShulkerBoxCraftingRecipe recipe) {
            buf.method_10814(recipe.method_8112());
            buf.method_10817(recipe.method_45441());
            class_8957.field_48359.encode(buf, recipe.getRaw());
            class_1799.field_48349.encode(buf, recipe.method_8110(null));
            buf.method_52964(recipe.method_49188());
        }
    }
}
