package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2627;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;

public class InventoryTests {
    private static final String BATCH_ID = String.format("%s:InventoryBatch",
            ReinforcedShulkerBoxesMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                    .values()) {
                add(InventoryTests.createTest(
                        String.format("%s inventory size", block.method_9518().getString()),
                        block,
                        45));
            }

            // Iron Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                    .values()) {
                add(InventoryTests.createTest(
                        String.format("%s inventory size", block.method_9518().getString()),
                        block,
                        54));
            }

            // Gold Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                    .values()) {
                add(InventoryTests.createTest(
                        String.format("%s inventory size", block.method_9518().getString()),
                        block,
                        81));
            }

            // Diamond Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                    .values()) {
                add(InventoryTests.createTest(
                        String.format("%s inventory size", block.method_9518().getString()),
                        block,
                        108));
            }

            // Netherite Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                    .values()) {
                add(InventoryTests.createTest(
                        String.format("%s inventory size", block.method_9518().getString()),
                        block,
                        108));
            }
        }
    };

    private static class_4529 createTest(String name, class_2248 shulkerBoxBlock, int size) {
        String testName = String.format("%s %s %s",
                ReinforcedShulkerBoxesMod.MOD_ID,
                InventoryTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                InventoryTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                100,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, shulkerBoxBlock);

                    // Act
                    class_2627 entity = (class_2627) context.method_36014(blockPos);

                    // Assert
                    try {
                        context.method_56606(entity.method_5439(), size,
                                String.format("%s inventory size", shulkerBoxBlock.method_9518().getString()));
                    } catch (Exception e) {
                        ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                        throw e;
                    }

                    context.method_36036();
                });
    }
}
