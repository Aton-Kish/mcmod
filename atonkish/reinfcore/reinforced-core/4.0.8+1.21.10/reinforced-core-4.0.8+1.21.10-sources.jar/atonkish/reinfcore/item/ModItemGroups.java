package atonkish.reinfcore.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import atonkish.reinfcore.ReinforcedCoreMod;

public class ModItemGroups {
    public static final class_5321<class_1761> REINFORCED_STORAGE;

    public static void init() {
        class_2378.method_39197(class_7923.field_44687, ModItemGroups.REINFORCED_STORAGE, FabricItemGroup
                .builder()
                .method_47321(class_2561.method_43471(String.format("itemGroup.%s.%s", ReinforcedCoreMod.MOD_ID,
                        ModItemGroups.REINFORCED_STORAGE.method_29177().method_12832())))
                .method_47324());
    }

    private static class_5321<class_1761> register(String id) {
        return class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(ReinforcedCoreMod.MOD_ID, id));
    }

    static {
        REINFORCED_STORAGE = ModItemGroups.register("reinforced_storage");
    }
}
