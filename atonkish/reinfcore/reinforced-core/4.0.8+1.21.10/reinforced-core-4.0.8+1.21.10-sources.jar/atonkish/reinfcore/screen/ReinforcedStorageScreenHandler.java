package atonkish.reinfcore.screen;

import atonkish.reinfcore.ReinforcedCoreMod;
import atonkish.reinfcore.mixin.SlotAccessor;
import atonkish.reinfcore.util.ReinforcedStorageScreenModel;
import atonkish.reinfcore.util.ReinforcedStorageScreenModels;
import atonkish.reinfcore.util.ReinforcedStorageScreenType;
import atonkish.reinfcore.util.ReinforcingMaterial;
import atonkish.reinfcore.util.math.Point2i;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1736;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

public class ReinforcedStorageScreenHandler extends class_1703 {
    private static final int SLOT_SIZE = 18;
    private static final int GAP_BETWEEN_PLAYER_INVENTORY_STORAGE_AND_PLAYER_INVENTORY_HOTBAR = 4;

    private static final int SCROLL_SCREEN_COLS = 9;

    private final class_1263 inventory;
    private final ReinforcingMaterial material;
    private final boolean isDoubleBlock;
    private final boolean isShulkerBox;
    private final int cols;
    private final int rows;
    private final ReinforcedStorageScreenModel screenModel;

    public ReinforcedStorageScreenHandler(class_3917<?> type, ReinforcingMaterial material,
            boolean isDoubleBlock, boolean isShulkerBox, int syncId, class_1661 playerInventory,
            class_1263 inventory) {
        super(type, syncId);
        this.inventory = inventory;
        this.material = material;
        this.isDoubleBlock = isDoubleBlock;
        this.isShulkerBox = isShulkerBox;
        inventory.method_5435(playerInventory.field_7546);

        int size = inventory.method_5439();
        this.cols = ReinforcedStorageScreenModel.getContainerInventoryColumns(size);
        this.rows = ReinforcedStorageScreenModel.getContainerInventoryRows(size, this.cols);

        this.screenModel = this.isDoubleBlock
                ? ReinforcedStorageScreenModels.DOUBLE_MAP.get(this.material)
                : ReinforcedStorageScreenModels.SINGLE_MAP.get(this.material);

        this.addSlots(playerInventory);
    }

    public static ReinforcedStorageScreenHandler createSingleBlockScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory, class_1263 inventory) {
        return new ReinforcedStorageScreenHandler(ModScreenHandlerType.REINFORCED_SINGLE_BLOCK_MAP.get(material),
                material, false, false, syncId, playerInventory, inventory);
    }

    public static ReinforcedStorageScreenHandler createSingleBlockScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory) {
        int size = ReinforcedStorageScreenModel.getContainerInventorySize(material, false);
        class_1263 inventory = new class_1277(size);
        return createSingleBlockScreen(material, syncId, playerInventory, inventory);
    }

    public static ReinforcedStorageScreenHandler createDoubleBlockScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory, class_1263 inventory) {
        return new ReinforcedStorageScreenHandler(ModScreenHandlerType.REINFORCED_DOUBLE_BLOCK_MAP.get(material),
                material, true, false, syncId, playerInventory, inventory);
    }

    public static ReinforcedStorageScreenHandler createDoubleBlockScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory) {
        int size = ReinforcedStorageScreenModel.getContainerInventorySize(material, true);
        class_1263 inventory = new class_1277(size);
        return createDoubleBlockScreen(material, syncId, playerInventory, inventory);
    }

    public static ReinforcedStorageScreenHandler createShulkerBoxScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory, class_1263 inventory) {
        return new ReinforcedStorageScreenHandler(ModScreenHandlerType.REINFORCED_SHULKER_BOX_MAP.get(material),
                material, false, true, syncId, playerInventory, inventory);
    }

    public static ReinforcedStorageScreenHandler createShulkerBoxScreen(ReinforcingMaterial material, int syncId,
            class_1661 playerInventory) {
        int size = ReinforcedStorageScreenModel.getContainerInventorySize(material, false);
        class_1263 inventory = new class_1277(size);
        return createShulkerBoxScreen(material, syncId, playerInventory, inventory);
    }

    private void addSlots(class_1661 playerInventory) {
        Point2i containerInventoryPoint = this.screenModel.getContainerInventoryPoint();
        Point2i playerInventoryPoint = this.screenModel.getPlayerInventoryPoint();

        for (int index = 0; index < this.inventory.method_5439(); ++index) {
            int col = index % this.cols;
            int row = (index - col) / this.cols;

            int x = containerInventoryPoint.getX() + col * SLOT_SIZE + 1;
            int y = containerInventoryPoint.getY() + row * SLOT_SIZE + 1;

            if (ReinforcedCoreMod.CONFIG.screenType == ReinforcedStorageScreenType.SCROLL
                    && row >= ReinforcedCoreMod.CONFIG.scrollScreen.rows) {
                // HACK: slot position far away outside if scroll screen type
                x = Integer.MIN_VALUE;
                y = Integer.MIN_VALUE;
            }

            class_1735 slot = this.isShulkerBox
                    ? new class_1736(this.inventory, index, x, y)
                    : new class_1735(this.inventory, index, x, y);
            this.method_7621(slot);
        }

        for (int index = 9; index < 36; ++index) {
            int col = (index - 9) % 9;
            int row = (index - col - 9) / 9;

            int x = playerInventoryPoint.getX() + col * SLOT_SIZE + 1;
            int y = playerInventoryPoint.getY() + row * SLOT_SIZE + 1;

            class_1735 slot = new class_1735(playerInventory, index, x, y);
            this.method_7621(slot);
        }

        for (int index = 0; index < 9; ++index) {
            int col = index;

            int x = playerInventoryPoint.getX() + col * SLOT_SIZE + 1;
            int y = playerInventoryPoint.getY() + 3 * SLOT_SIZE
                    + GAP_BETWEEN_PLAYER_INVENTORY_STORAGE_AND_PLAYER_INVENTORY_HOTBAR + 1;

            class_1735 slot = new class_1735(playerInventory, index, x, y);
            this.method_7621(slot);
        }
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return this.inventory.method_5443(player);
    }

    public void scrollItems(float position) {
        if (ReinforcedCoreMod.CONFIG.screenType != ReinforcedStorageScreenType.SCROLL) {
            return;
        }

        int i = (this.inventory.method_5439() + SCROLL_SCREEN_COLS - 1) / SCROLL_SCREEN_COLS
                - ReinforcedCoreMod.CONFIG.scrollScreen.rows;
        int srow = (int) ((double) (position * (float) i) + 0.5);
        if (srow < 0) {
            srow = 0;
        }

        Point2i containerInventoryPoint = this.screenModel.getContainerInventoryPoint();

        for (int index = 0; index < this.inventory.method_5439(); ++index) {
            int col = index % this.cols;
            int row = (index - col) / this.cols;

            int x = containerInventoryPoint.getX() + col * SLOT_SIZE + 1;
            int y = containerInventoryPoint.getY() + (row - srow) * SLOT_SIZE + 1;

            if (row < srow || row >= srow + ReinforcedCoreMod.CONFIG.scrollScreen.rows) {
                // HACK: slot position far away outside if scroll screen type
                x = Integer.MIN_VALUE;
                y = Integer.MIN_VALUE;
            }

            class_1735 slot = this.method_7611(index);
            ((SlotAccessor) slot).setX(x);
            ((SlotAccessor) slot).setY(y);
        }
    }

    public boolean shouldShowScrollbar() {
        return ReinforcedCoreMod.CONFIG.screenType == ReinforcedStorageScreenType.SCROLL
                && this.inventory.method_5439() > SCROLL_SCREEN_COLS * ReinforcedCoreMod.CONFIG.scrollScreen.rows;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        class_1799 itemStack = class_1799.field_8037;
        class_1735 slot2 = (class_1735) this.field_7761.get(slot);
        if (slot2 != null && slot2.method_7681()) {
            class_1799 itemStack2 = slot2.method_7677();
            itemStack = itemStack2.method_7972();
            if (slot < this.inventory.method_5439()
                    ? !this.method_7616(itemStack2, this.inventory.method_5439(), this.field_7761.size(), true)
                    : !this.method_7616(itemStack2, 0, this.inventory.method_5439(), false)) {
                return class_1799.field_8037;
            }
            if (itemStack2.method_7960()) {
                slot2.method_53512(class_1799.field_8037);
            } else {
                slot2.method_7668();
            }
        }
        return itemStack;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        this.inventory.method_5432(player);
    }

    public class_1263 getInventory() {
        return this.inventory;
    }

    public ReinforcingMaterial getMaterial() {
        return this.material;
    }

    public boolean getIsDoubleBlock() {
        return this.isDoubleBlock;
    }

    public boolean getIsShulkerBox() {
        return this.isShulkerBox;
    }

    public int getColumns() {
        return this.cols;
    }

    public int getRows() {
        return this.rows;
    }
}
