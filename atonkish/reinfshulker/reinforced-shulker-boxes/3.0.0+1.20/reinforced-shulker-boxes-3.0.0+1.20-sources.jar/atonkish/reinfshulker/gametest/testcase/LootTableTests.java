package atonkish.reinfshulker.gametest.testcase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import atonkish.reinfcore.util.ReinforcingMaterials;
import atonkish.reinfshulker.ReinforcedShulkerBoxesMod;
import atonkish.reinfshulker.block.ModBlocks;
import atonkish.reinfshulker.gametest.util.MockServerPlayerHelper;

public class LootTableTests {
    private static final String BATCH_ID = String.format("%s:LootTableBatch",
            ReinforcedShulkerBoxesMod.MOD_ID);

    public static final Collection<class_4529> TEST_FUNCTIONS = new ArrayList<>() {
        {
            // Copper Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("copper"))
                    .values()) {
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                        block,
                        class_1802.field_22024,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                        block,
                        class_1802.field_22025,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s without tools", block.method_9518().getString()),
                        block,
                        class_1802.field_8162,
                        true));
            }

            // Iron Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("iron"))
                    .values()) {
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                        block,
                        class_1802.field_22024,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                        block,
                        class_1802.field_22025,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s without tools", block.method_9518().getString()),
                        block,
                        class_1802.field_8162,
                        true));
            }

            // Gold Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("gold"))
                    .values()) {
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                        block,
                        class_1802.field_22024,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                        block,
                        class_1802.field_22025,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s without tools", block.method_9518().getString()),
                        block,
                        class_1802.field_8162,
                        true));
            }

            // Diamond Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("diamond"))
                    .values()) {
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                        block,
                        class_1802.field_22024,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                        block,
                        class_1802.field_22025,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s without tools", block.method_9518().getString()),
                        block,
                        class_1802.field_8162,
                        true));
            }

            // Netherite Shulker Box
            for (class_2248 block : ModBlocks.REINFORCED_SHULKER_BOX_MAP.get(ReinforcingMaterials.MAP.get("netherite"))
                    .values()) {
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Pickaxe", block.method_9518().getString()),
                        block,
                        class_1802.field_22024,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s with Netherite Axe", block.method_9518().getString()),
                        block,
                        class_1802.field_22025,
                        true));
                add(LootTableTests.createTest(
                        String.format("Break %s without tools", block.method_9518().getString()),
                        block,
                        class_1802.field_8162,
                        true));
            }
        }
    };

    private static class_4529 createTest(String name, class_2248 shulkerBoxBlock, class_1792 tool, boolean shouldDrop) {
        String testName = String.format("%s %s %s",
                ReinforcedShulkerBoxesMod.MOD_ID,
                LootTableTests.class.getSimpleName(),
                name)
                .replace(" ", "_");

        return new class_4529(
                LootTableTests.BATCH_ID,
                testName,
                FabricGameTest.EMPTY_STRUCTURE,
                class_4525.method_29408(0),
                1000,
                0L,
                true,
                false,
                1,
                1,
                false,
                (context) -> {
                    // Arrange
                    class_2338 blockPos = class_2338.field_10980;
                    context.method_35984(blockPos, shulkerBoxBlock);

                    class_3222 player = MockServerPlayerHelper.spawn(context,
                            class_1934.field_9215, class_243.method_24954(blockPos.method_10077(4)));
                    player.method_6122(class_1268.field_5808, new class_1799(tool));

                    // Act
                    CompletableFuture<Void> futurePartialAct1 = new CompletableFuture<>();
                    CompletableFuture<Void> futurePartialAct2 = new CompletableFuture<>();

                    long tickOrigin = 0;
                    context.method_35951(tickOrigin, () -> {
                        player.field_13974.method_14263(
                                context.method_36052(blockPos), class_2846.class_2847.field_12968,
                                class_2350.field_11043, context.method_35943().method_31600(), 0);

                        futurePartialAct1.complete(null);
                    });

                    long tickBlockBreaking = (long) Math.ceil(
                            1.0D / context.method_35980(blockPos).method_26165(player,
                                    context.method_35943(), blockPos));
                    context.method_35951(tickBlockBreaking, () -> {
                        player.field_13974.method_14263(
                                context.method_36052(blockPos),
                                class_2846.class_2847.field_12973,
                                class_2350.field_11043, context.method_35943().method_31600(), 0);

                        futurePartialAct2.complete(null);
                    });

                    ReinforcedShulkerBoxesMod.LOGGER.info("[{}] {} can be mined in {} ticks by {}",
                            testName,
                            shulkerBoxBlock.method_9518().getString(),
                            tickBlockBreaking,
                            tool.method_7848().getString());

                    // Assert
                    CompletableFuture.allOf(futurePartialAct1, futurePartialAct2).thenRun(() -> {
                        try {
                            context.method_35972(class_2246.field_10124, blockPos);
                            context.method_44606(class_1299.field_6052, blockPos, shouldDrop ? 1 : 0, 1);
                        } catch (Exception e) {
                            ReinforcedShulkerBoxesMod.LOGGER.error("[{}] {}", testName, e.getMessage());
                            throw e;
                        } finally {
                            MockServerPlayerHelper.destroy(context, player);
                        }

                        context.method_36036();
                    });
                });
    }
}
